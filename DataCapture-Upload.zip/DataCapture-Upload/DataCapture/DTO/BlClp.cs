﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace DataCapture.DTO
{
    [DataContract]
    [Serializable]
    public class BlClp
    {
        [DataMember]
        public decimal SiUid { get; set; }

        [DataMember]
        public int RevNo { get; set; }

        [DataMember]
        public int ClpSeq { get; set; }

        [DataMember]
        public int PkgSeq { get; set; }

        [DataMember]
        public string EqpNo { get; set; }

        [DataMember]
        public decimal PkgCount { get; set; }

        [DataMember]
        public string PkgType { get; set; }

        [DataMember]
        public decimal ClpWgt { get; set; }

        [DataMember]
        public string ClpWgtUm { get; set; }

        [DataMember]
        public decimal ClpMsr { get; set; }

        [DataMember]
        public string ClpMsrUm { get; set; }

        [DataMember]
        public decimal ClpNetWgt { get; set; }

        [DataMember]
        public string ClpNetWgtUm { get; set; }

        [DataMember]
        public decimal ClpNetMsr { get; set; }

        [DataMember]
        public string ClpNetMsrUm { get; set; }
    }
}
