﻿//using Mol.Infra.Common;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace DataCapture.DTO
{

    [DataContract]
    [Serializable]
    public class CapturedData
    {       
        

        public CapturedData()
        {                     
        }
    }
}
