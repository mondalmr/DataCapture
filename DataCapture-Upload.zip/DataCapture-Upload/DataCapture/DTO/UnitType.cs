﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture.DTO
{
    public enum UnitType
    {
        PackageType = 0,
        Weight = 1,
        Measure = 2
    }
}
