﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace DataCapture.DTO
{

    [DataContract]
    [Serializable]
    public class BlMain
    {
        [DataMember]
        public decimal Uid
        {
            get;
            set;
        }

        [DataMember]
        public int RevNo
        {
            get;
            set;
        }

        [DataMember]
        public string BlNo
        {
            get;
            set;
        }

        [DataMember]
        public string BlSfx
        {
            get;
            set;
        }

        [DataMember]
        public string PrimaryBkgNo
        {
            get;
            set;
        }

        [DataMember]
        public string AdditionalBkgNos
        {
            get;
            set;
        }

        [DataMember]
        public string Containers
        {
            get;
            set;
        }

        [DataMember]
        public string BlTextBody
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr1
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr2
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr3
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr4
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr5
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr6
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr7
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr8
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr9
        {
            get;
            set;
        }

        [DataMember]
        public string Anpxr10
        {
            get;
            set;
        }

        [DataMember]
        public string SvcContNo
        {
            get;
            set;
        }

        [DataMember]
        public string SvcContRefNo
        {
            get;
            set;
        }

        [DataMember]
        public string PreCarriage
        {
            get;
            set;
        }

        [DataMember]
        public string PreCarriageBkg
        {
            get;
            set;
        }

        [DataMember]
        public string PlaceReceipt
        {
            get;
            set;
        }

        [DataMember]
        public string PlaceReceiptBkg
        {
            get;
            set;
        }

        [DataMember]
        public string OceanVessel
        {
            get;
            set;
        }

        [DataMember]
        public string OceanVesselBkg
        {
            get;
            set;
        }

        [DataMember]
        public string OceanVoyage
        {
            get;
            set;
        }

        [DataMember]
        public string OceanVoyageBkg
        {
            get;
            set;
        }

        [DataMember]
        public string PortLoading
        {
            get;
            set;
        }

        [DataMember]
        public string PortLoadingBkg
        {
            get;
            set;
        }

        [DataMember]
        public string PortDischarge
        {
            get;
            set;
        }

        [DataMember]
        public string PortDischargeBkg
        {
            get;
            set;
        }

        [DataMember]
        public string PlaceDelivery
        {
            get;
            set;
        }

        [DataMember]
        public string PlaceDeliveryBkg
        {
            get;
            set;
        }

        [DataMember]
        public string OrglUser
        {
            get;
            set;
        }

        [DataMember]
        public DateTime OrglStamp
        {
            get;
            set;
        }

        [DataMember]
        public decimal BlNoUid
        {
            get;
            set;
        }

        //****************************************
        [DataMember]
        public string SkipIfSimulation
        {
            get;
            set;
        }

        [DataMember]
        public string SkipMemo
        {
            get;
            set;
        }

        [DataMember]
        public string SkipHitchment
        {
            get;
            set;
        }

        [DataMember]
        public string SkipIFTMINReceived
        {
            get;
            set;
        }

        [DataMember]
        public string SkipIfMultiplePDs
        {
            get;
            set;
        }

        [DataMember]
        public string SkipIfDifferentBLOffice
        {
            get;
            set;
        }
        
        [DataMember]
        public string SkipIfPartLot
        {
            get;
            set;
        }
        //**************************************
                
        [DataMember]
        public string ExpRef01
        {
            get;
            set;
        }
        [DataMember]
        public string ExpRef02
        {
            get;
            set;
        }
        [DataMember]
        public string ExpRef03
        {
            get;
            set;
        }
        [DataMember]
        public string ExpRef04
        {
            get;
            set;
        }

        [DataMember]
        public string AESNo
        {
            get;
            set;
        }
        [DataMember]
        public string Por
        {
            get;
            set;
        }
        [DataMember]
        public string Pori
        {
            get;
            set;
        }

        [DataMember]
        public string PorType
        {
            get;
            set;
        }

        [DataMember]
        public string OriginPlace
        {
            get;
            set;
        }

        [DataMember]
        public string OriginPlaceBkg
        {
            get;
            set;
        }

        [DataMember]
        public string FinalDestination
        {
            get;
            set;
        }

        [DataMember]
        public string FinalDestinationBkg
        {
            get;
            set;
        }        
        
        [DataMember]
        public string SkipSealNoValidation
        {
            get;
            set;
        }

        public BlMain() {
            BlSfx = "A";
        }
    }
}
