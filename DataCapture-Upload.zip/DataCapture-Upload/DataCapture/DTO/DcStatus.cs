﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace DataCapture.DTO
{

    [DataContract]
    [Serializable]
    public class DcStatus
    {
        [DataMember]
        public string ErrorMsg
        {
            get;
            set;
        }

        [DataMember]
        public string Message
        {
            get;
            set;
        }
        
    }
}
