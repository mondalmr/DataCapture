﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DataCapture.DTO
{
    [Serializable]
    [DataContract]
    public class UnitInfo
    {
        [DataMember]
        public decimal DUnitType
        {
            get;
            set;
        }

        public UnitType UnitType
        {
            get
            {
                return (UnitType)this.DUnitType;
            }
            set
            {
                this.DUnitType = (decimal)value;
            }
        }

        [DataMember]
        public string UnitCode
        {
            get;
            set;
        }

        [DataMember]
        public string AltCode
        {
            get;
            set;
        }

        [DataMember]
        public string MappedValue
        {
            get;
            set;
        }

        [DataMember]
        public string Description
        {
            get;
            set;
        }

        [DataMember]
        public DateTime LastUpdated
        {
            get;
            set;
        }

        public bool IsMappedValue
        {
            get
            {
                return !string.IsNullOrWhiteSpace(MappedValue);
            }
        }

        public string Text
        {
            get
            {
                var sb = new StringBuilder();
                sb.Append(Description);
                sb.Append(", ");
                sb.Append(UnitCode);
                if (!string.IsNullOrWhiteSpace(MappedValue))
                {
                    sb.Append(" (");
                    sb.Append(MappedValue);
                    sb.Append(")");
                }
                else if (!string.IsNullOrWhiteSpace(AltCode))
                {
                    sb.Append("/");
                    sb.Append(AltCode);
                }
                return sb.ToString();
            }
        }

        /// <summary>
        /// Returns comparison for description
        /// </summary>
        /// <param name="dscr"></param>
        /// <returns>0 - no match, 1 - case insensitive match, 2 - case insensitive and contains, 3 - case insensitive and alphanumeric match, 10 - exact match</returns>
        public int DescriptionCompare(string dscr)
        {
            if (!string.IsNullOrEmpty(Description) && !string.IsNullOrEmpty(dscr))
            {
                if (Description.Equals(dscr))
                {
                    return 10;
                }
                if (Description.Equals(dscr, StringComparison.InvariantCultureIgnoreCase))
                {
                    return 1;
                }
                if (Description.ToUpper().Contains(dscr.ToUpper()))
                {
                    return 2;
                }
                var exp = new Regex("[^a-zA-Z0-9]");
                if (exp.Replace(Description, "").Equals(exp.Replace(dscr, "")))
                {
                    return 3;
                }
            }
            return 0;
        }
    }
}
