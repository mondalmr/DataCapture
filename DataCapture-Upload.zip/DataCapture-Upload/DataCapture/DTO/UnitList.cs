﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture.DTO
{
    [Serializable]
    [DataContract]
    public class UnitList
    {
        [DataMember]
        public DateTime LastUpdated
        {
            get;
            set;
        }

        [DataMember]
        public IList<UnitInfo> Units
        {
            get;
            set;
        }
    }
}
