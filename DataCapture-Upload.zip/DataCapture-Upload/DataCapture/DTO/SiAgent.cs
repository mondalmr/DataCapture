﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture.DTO
{
    [DataContract]
    public class SiAgent
    {
        [DataMember]
        public decimal AgentUid
        {
            get;
            set;
        }

        [DataMember]
        public string AgentName
        {
            get;
            set;
        }

        [DataMember]
        public bool IsDefault
        {
            get;
            set;
        }
    }
}
