﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace DataCapture.DTO
{
    [DataContract]
    [Serializable]
    public class BlPkg
    {
        [DataMember]
        public decimal Uid
        {
            get;
            set;
        }

        [DataMember]
        public int RevNo
        {
            get;
            set;
        }

        [DataMember]
        public int Seq
        {
            get;
            set;
        }

        [DataMember]
        public string GoodsDescription
        {
            get;
            set;
        }

        [DataMember]
        public Decimal PackageCount
        {
            get;
            set;
        }

        [DataMember]
        public string PackageType
        {
            get;
            set;
        }

        [DataMember]
        public decimal PackageWeight
        {
            get;
            set;
        }

        [DataMember]
        public string PackageWeightUM
        {
            get;
            set;
        }

        [DataMember]
        public decimal PackageMeasure
        {
            get;
            set;
        }

        [DataMember]
        public string PackageMeasureUM
        {
            get;
            set;
        }

        [DataMember]
        public decimal PackageNetWeight
        {
            get;
            set;
        }

        [DataMember]
        public string PackageNetWeightUM
        {
            get;
            set;
        }

        [DataMember]
        public decimal PackageNetMeasure
        {
            get;
            set;
        }

        [DataMember]
        public string PackageNetMeasureUM
        {
            get;
            set;
        }

        [DataMember]
        public string UnHsCmdCode
        {
            get;
            set;
        }
    }
}