﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace DataCapture.DTO
{
    [DataContract]
    [Serializable]
    public class BlMksNo 
    {
        [DataMember]
        public decimal Uid
        {
            get;
            set;
        }

        [DataMember]
        public int RevNo
        {
            get;
            set;
        }

        [DataMember]
        public int Seq
        {
            get;
            set;
        }

        [DataMember]
        public string MarksNo
        {
            get;
            set;
        }
    }
}