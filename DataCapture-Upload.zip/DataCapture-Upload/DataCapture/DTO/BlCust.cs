﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace DataCapture.DTO
{

    [DataContract]
    [Serializable]
    public class BlCust
    {
        [DataMember]
        public decimal Uid
        {
            get;
            set;
        }

        [DataMember]
        public int RevNo
        {
            get;
            set;
        }

        [DataMember]
        public string Type
        {
            get;
            set;
        }

        [DataMember]
        public string Name
        {
            get;
            set;
        }

        [DataMember]
        public string Addr1
        {
            get;
            set;
        }

        [DataMember]
        public string Addr2
        {
            get;
            set;
        }

        [DataMember]
        public string Addr3
        {
            get;
            set;
        }

        [DataMember]
        public string Addr4
        {
            get;
            set;
        }
        
        [DataMember]
        public string Addr5
        {
            get;
            set;
        }

        [DataMember]
        public string NameRcvd
        {
            get;
            set;
        }
    }
}
