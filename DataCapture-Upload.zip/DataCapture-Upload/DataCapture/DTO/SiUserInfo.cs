﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture.DTO
{
    [DataContract]
    public class SiUserInfo
    {
        [DataMember]
        public string ErrorMsg
        {
            get;
            set;
        }

        [DataMember]
        public decimal UserUid
        {
            get;
            set;
        }

        [DataMember]
        public string UserName
        {
            get;
            set;
        }

        [DataMember]
        public string Token
        {
            get;
            set;
        }

        [DataMember]
        public IEnumerable<SiAgent> UserAgents
        {
            get;
            set;
        }
    }
}
