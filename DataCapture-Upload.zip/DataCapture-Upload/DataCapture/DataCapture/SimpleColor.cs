﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public struct SimpleColor
    {
        public static SimpleColor FromRGB(byte red, byte green, byte blue)
        {
            var sc = new SimpleColor();
            sc.Red = red;
            sc.Green = green;
            sc.Blue = blue;
            return sc;
        }

        public byte Red
        {
            get;
            set;
        }

        public byte Green
        {
            get;
            set;
        }

        public byte Blue
        {
            get;
            set;
        }

        public double Luminence
        {
            get
            {
                return (Red * 0.299) + (Green * 0.587) + (Blue * 0.114);
            }
        }

        public Color Color
        {
            get
            {
                return Color.FromArgb(Red, Green, Blue);
            }
        }

        public bool IsBlack
        {
            get
            {
                return Luminence < 140;
            }
        }
    }
}
