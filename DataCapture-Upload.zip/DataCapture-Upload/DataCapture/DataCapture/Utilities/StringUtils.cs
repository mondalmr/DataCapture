﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DataCapture
{
    public static class StringUtils
    {
        public static Size StringSize(this string text, string fontFamily, bool isBold, double fontSize, CultureInfo cultureInfo = null)
        {
            var typeFace = new Typeface(new FontFamily(fontFamily), FontStyles.Normal, isBold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal);
            return StringSize(text, typeFace, fontSize, cultureInfo);
        }

        public static Size StringSize(this string text, Typeface typeface, double fontSize, CultureInfo cultureInfo = null)
        {
            if (cultureInfo == null)
            {
                cultureInfo = CultureInfo.CurrentUICulture;
            }
            var rendered = new FormattedText(text, cultureInfo, FlowDirection.LeftToRight, typeface, fontSize, Brushes.Black);
            return new Size(rendered.WidthIncludingTrailingWhitespace, rendered.Height);
        }

        public static Size StringSize(this string text, TextBlock tb, CultureInfo cultureInfo = null)
        {
            var typeface = new Typeface(tb.FontFamily, tb.FontStyle, tb.FontWeight, tb.FontStretch);
            return text.StringSize(typeface, tb.FontSize, cultureInfo);
        }

        public static Size SpaceSize(this TextBlock tb, CultureInfo cultureInfo = null)
        {
            var size1 = ".".StringSize(tb, cultureInfo);
            var size2 = ". .".StringSize(tb, cultureInfo);
            return new Size(size2.Width - (size1.Width * 2), size2.Height);
        }

        public static string RemoveSpaces(this string text)
        {
            if (string.IsNullOrEmpty(text)) return text;

            return text.ReplaceAndTrim(" ", "");
        }

        public static string ReplaceTexts(this IEnumerable<ReplaceInfo> replacements, string text)
        {
            if (replacements != null && !string.IsNullOrWhiteSpace(text))
            {
                foreach (var replace in replacements)
                {
                    if (replace != null && !string.IsNullOrEmpty(replace.SearchText))
                    {
                        var replaceWith = replace.ReplaceText;
                        if (replaceWith == null)
                        {
                            replaceWith = "";
                        }
                        if (replace.IgnoreCase)
                        {
                            text = Regex.Replace(text, Regex.Escape(replace.SearchText), replaceWith, RegexOptions.IgnoreCase);
                        }
                        else
                        {
                            text = text.Replace(replace.SearchText, replaceWith);
                        }
                    }
                }
            }
            return text;
        }

        public static string ToAlphaNumeric(this string text)
        {
            Regex exp = new Regex("[^a-zA-Z0-9_ ]");            
            return exp.Replace(text, "");
        }

        public static string ToNumber(this string text, bool european)
        {
            string str = @"[^0-9.]";
            if (european)
            {
                str = @"[^0-9,]";
            }
            Regex exp = new Regex(str);
            var tmp = exp.Replace(text, "");
            tmp = tmp.Replace(",", ".");
            var texts = tmp.Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries);
            if (texts.Length > 2)
            {
                tmp = texts[0] + "." + texts[1];
            }
            return tmp;
        }

        public static bool ContainsValue(this string text)
        {
            double value;
            return text.ContainsValueDouble(out value);
        }

        public static bool ContainsValueDouble(this string text, out double value)
        {
            value = 0;
            if (!string.IsNullOrWhiteSpace(text))
            {
                return Double.TryParse(text, out value);
            }
            return false;
        }

        public static bool ContainsValueInt(this string text, out int value)
        {
            value = 0;
            if (!string.IsNullOrWhiteSpace(text))
            {
                return Int32.TryParse(text, out value);
            }
            return false;
        }

        /// <summary>
        /// Returns an array of words from a string including punctuations.
        /// The punctuations are stored as single character words
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string[] ToWords(this string text)
        {
            var seps = new char[] { ' ', ',', ';', ':', '.', '-', '(', ')', '+', '=', '/', '&', '*', '^', (char)10, (char)13, (char)9 };
            List<string> words = new List<string>();
            if (!string.IsNullOrWhiteSpace(text))
            {
                string lastWord = null;
                var isSep = false;
                var chars = text.ToCharArray();
                for (int i = 0; i < chars.Length; i++)
                {
                    isSep =false;
                    for (int j = 0; j < seps.Length; j++)
                    {
                        if (chars[i] == seps[j])
                        {
                            if (lastWord != null)
                            {
                                words.Add(lastWord);
                            }
                            words.Add("" + chars[i]);
                            lastWord = null;
                            isSep = true;
                            break;
                        }
                    }
                    if (!isSep)
                    {
                        if (lastWord == null)
                        {
                            lastWord = "";
                        }
                        lastWord = lastWord + chars[i];
                    }
                }
                if (lastWord != null)
                {
                    words.Add(lastWord);
                }
            }
            return words.ToArray();
        }

        public static string ConvertUmlautAccents(this string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return text;
            }
            var source = "àèìòùÀÈÌÒÙäëïöüÄËÏÖÜâêîôûÂÊÎÔÛáéíóúÁÉÍÓÚðÐýÝãñõÃÑÕšŠžŽçÇåÅøØƒ¡ªºΘ".ToCharArray();
            var target = "aeiouAEIOUaeiouAEIOUaeiouAEIOUaeiouAEIOUdDyYanoANOsSzZcCaAoOfiao0".ToCharArray();
            for (int i = 0; i < source.Length; i++)
            {
                text = text.Replace(source[i], target[i]);
            }
            return text;
        }
       
        public static string RemoveExtendedCharacters(this string text)
        {
            StringBuilder sb = new StringBuilder();
            //text=text.Replace("\r\n\r\n", "\r\n");
            if (!string.IsNullOrWhiteSpace(text))
            {
                var chars = text.ToCharArray();
                for (int i = 0; i < chars.Length; i++)
                {
                    if ((chars[i] >= (char)32 && chars[i] <= (char)126) )// regular character                        
                    {
                        sb.Append(chars[i]);
                    }
                    else if (DataCaptureConfiguration.IsValidChar(chars[i])) {
                        sb.Append(chars[i]);
                    }
                    else if (DataCaptureConfiguration.IsValidReplaceableChar(chars[i]))
                    {
                        sb.Append(DataCaptureConfiguration.ReplaceWithValidChar(chars[i]));
                    }                    
                }
            }
            return sb.ToString();
        }


        public static string[] Trim(this string[] texts)
        {
            if (texts != null && texts.Length > 0)
            {
                for (int i = 0; i < texts.Length; i++)
                {
                    texts[i] = texts[i].Trim();
                }
            }
            return texts;
        }

        public static string ToUnixNewLine(this string text)
        {
            if (!string.IsNullOrWhiteSpace(text))
            {
                string nl = new string((char)13, 1);
                text = text.Replace(nl, "");
            }
            return text;
        }

        public static string ReplaceAlphabetsbyNumbers(this string text)
        {
            if (string.IsNullOrEmpty(text)) return text;

            text = text.Trim().ToLower();
            return text.Replace("l", "1").Replace("o", "0").Replace("i", "1").Replace("q", "0").ToNumber(false);
        }

        public static string ReplaceNumbersbyAlphabets(this string text)
        {
            if (string.IsNullOrEmpty(text)) return text;

            text = text.Trim().ToLower();
            return text.Replace("1", "l").Replace("0", "o").Replace("1", "l").Replace("0", "q");
        }


        //=================
        //Levenshtein distance
        /*
         Informally, the Levenshtein distance between two words is the minimum number 
         of single-character edits (i.e. insertions, deletions or substitutions) 
         required to change one word into the other.
         */
        public static int ComputeLevenshteinDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];

            // Step 1
            if (n == 0)
            {
                return m;
            }

            if (m == 0)
            {
                return n;
            }

            // Step 2
            for (int i = 0; i <= n; d[i, 0] = i++)
            {
            }

            for (int j = 0; j <= m; d[0, j] = j++)
            {
            }

            // Step 3
            for (int i = 1; i <= n; i++)
            {
                //Step 4
                for (int j = 1; j <= m; j++)
                {
                    // Step 5
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;

                    // Step 6
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            // Step 7
            return d[n, m];
        }

    }
}