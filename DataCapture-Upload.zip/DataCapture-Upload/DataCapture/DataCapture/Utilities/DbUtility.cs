﻿using DataCapture.DbContext;
using DataCapture.DbContext.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class DbUtility
    {
        public string SaveInDatabase(DataCaptureInfo dc,DataTable dt)
        {
            var saveChallan = "0";
            var saveCertificate = "0";

            if (dt.Rows.Count > 0)
                saveChallan=  SaveChallan(dt);
            if (dc != null)
                saveCertificate =  SaveCertificate(dc);

            return "";//$"{saveChallan},{saveCertificate}";
        }

        public string SaveChallan(DataTable dt)
        {
            var challans = new List<tblStageChallanDetails>();

            foreach(DataRow dr in dt.Rows)
            {
                var sc = Convert.ToString(dr["Section"]);

                if (!sc.Equals("195"))
                {
                    sc = sc.ReplaceAndTrim(" ", "");
                    //sc = sc.Length >= 3 ? $"1{sc.Substring(0, 2)} {sc.Substring(2)}" : "";
                }
                    

                if (dr["ChallanNo"] != null)
                    challans.Add(new tblStageChallanDetails()
                    {
                        ChallanSerialNo = Convert.ToString(dr["ChallanNo"]),
                        CorpNonCopr = "NC",
                        SectionCode = sc,
                        TANofdeductor = dr["Tan"] == null ? "" : Convert.ToString(dr["Tan"]),
                        AssessmentYear = dr["AssessmentYear"] == null ? "" : Convert.ToString(dr["AssessmentYear"]),

                        TDS =Convert.ToString(dr["TDS"]) == "" ? 0 : Convert.ToDecimal(dr["TDS"]),
                        Surcharge_ = Convert.ToString(dr["Surcharge"]) == "" ? 0 : Convert.ToDecimal(dr["Surcharge"]),
                        EducationCess_ = Convert.ToString(dr["Ecess"]) == "" ? 0 : Convert.ToDecimal(dr["Ecess"]),
                        Interest = Convert.ToString(dr["Interest"]) == "" ? 0 : Convert.ToDecimal(dr["Interest"]),
                        Fee = Convert.ToString(dr["Fee(234E)"]) == "" ? 0 : Convert.ToDecimal(dr["Fee(234E)"]),
                        Others = "0",
                        OtherAmtAllocated = Convert.ToString(dr["Others"]) == "" ? 0 : Convert.ToDecimal(dr["Others"]),
                        TotalTaxDeposited = Convert.ToString(dr["TotalTax"]) == "" ? 0 : Convert.ToDecimal(dr["TotalTax"]),

                        WhetherTDSDepositedbyBookEntry = "N",
                        BankBranchCode = dr["BranchCode"] == null ? "" : Convert.ToString(dr["BranchCode"]),
                        BankName = dr["BankName"] == null ? "" : Convert.ToString(dr["BankName"]),

                        DateonWhichTaxDeposited = Convert.ToString(dr["DepositeDate"]) == "" ? DateTime.Today.ToShortDateString() : Convert.ToString(dr["DepositeDate"]),

                        MinorHead = dr["MinorHead"] == null ? "" : Convert.ToString(dr["MinorHead"]),
                        InterestAllocated = "0",
                        NILChallanIndicator = null,
                        Remarks = null,
                        NatureofPayment = dr["Section"] == null ? "" : Convert.ToString(dr["Section"]),
                        TypeofPayment = dr["MinorHead"] == null ? "" : Convert.ToString(dr["MinorHead"])
                    });
            }

            using (var ctxt = new DataCaptureDbContext())
            {
                ctxt.tblStageChallanDetails.AddRange(challans);
                ctxt.SaveChanges();

                SqlParameter legalEntity = new SqlParameter("@LegalEntity", SqlDbType.NVarChar, 500);
                legalEntity.Value = "Hindustan Coca-Cola Beverages Private Limited";
                legalEntity.Direction = ParameterDirection.Input;

                SqlParameter division = new SqlParameter("@Division", SqlDbType.NVarChar, 500);
                division.Value = "Division 1";
                division.Direction = ParameterDirection.Input;

                ctxt.Database.ExecuteSqlCommand("USP_InsertChallanStageToMaster @LegalEntity,@Division", legalEntity, division);                
            }

            return "1";
        }

        public string SaveCertificate(DataCaptureInfo dc)
        {
            var certs = new List<tblVendorCerificateDetail>();

            using(var ctxt = new DataCaptureDbContext())
            {
                var vendor = ctxt.tblVendorMasters.FirstOrDefault(m => m.VendorName.ToUpper().Contains(dc.CertName.ToUpper()) && m.PAN == dc.PANNo);
                if(vendor == null)
                {
                    vendor = ctxt.tblVendorMasters.FirstOrDefault(m => m.PAN == dc.PANNo);
                }

                if (vendor == null)
                {                    
                    return "-1";
                }

                foreach (var itm in dc.PackageList)
                {

                    if (!itm.Nature.Equals("195"))
                    {
                        itm.Nature = itm.Nature.ReplaceAndTrim(" ", "");
                        //itm.Nature = itm.Nature.Length >= 3 ? $"1{itm.Nature.Substring(0, 2)} {itm.Nature.Substring(2)}" : "";
                    }

                    if (!string.IsNullOrEmpty(itm.CertificateNo))
                        certs.Add(new tblVendorCerificateDetail()
                        {
                            VendorCertificateID = Guid.NewGuid(),
                            VendorID = vendor.VendorID,
                            VendorIdERP = vendor.VendorIdERP,
                            VendorSiteId = vendor.VendorSiteId,
                            WHCertStartDate = Convert.ToDateTime(itm.FromDate),
                            WHCertEndDate = Convert.ToDateTime(itm.ToDate),
                            CertificateAmount = Convert.ToDecimal(itm.CertificateAmt),
                            Form15G15HApplicable = null,
                            Form15G15HAvailable = null,
                            Rate = Convert.ToDecimal(itm.PrescribedRate),
                            AcknowledgementFormNo15CA = dc.CertAckNo,
                            Nature = itm.Nature,
                            CertificateNo = itm.CertificateNo,
                            NonOrLowerDeductionReason = null,
                            CreatedBy = Guid.Parse("04B80252-15F2-43EE-8342-7CC0DF7027F5"),
                            CreatedDate = DateTime.Now,
                            IsActive = true,
                            IsDeleted = false,
                            FinancialYear = "2018-19",
                            DateoffurnishingTaxDeduction = Convert.ToDateTime(dc.CertDate),
                        });
                }


                ctxt.tblVendorCerificateDetails.AddRange(certs);
                ctxt.SaveChanges();

                return "1";
            }
        }
    }
}
