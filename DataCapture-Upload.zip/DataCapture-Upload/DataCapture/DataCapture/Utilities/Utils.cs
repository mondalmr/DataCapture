﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public static class Utils
    {
        public static string ReplaceAndTrim(this string text, string searchFor, string replaceWith)
        {
            if (!string.IsNullOrWhiteSpace(text))
            {
                StringBuilder sb = new StringBuilder();
                var texts = text.Split(new string[]{searchFor}, StringSplitOptions.RemoveEmptyEntries);
                if (texts != null && text.Length > 0)
                {
                    for (int i = 0; i < texts.Length; i++)
                    {
                        if (!string.IsNullOrWhiteSpace(texts[i]))
                        {
                            if (sb.Length > 0)
                            {
                                sb.Append(replaceWith);
                            }
                            sb.Append(texts[i]);
                        }
                    }
                    return sb.ToString();
                }
            }
            return text;
        }

        public static string[] SeparateValueAndUM(this string text, bool euroFormat)
        {
            if (!string.IsNullOrWhiteSpace(text))
            {
                var tmp = text.ToUpper().Replace(" ", "");
                var chars = tmp.ToCharArray();
                if (chars != null && chars.Length > 0)
                {
                    bool spaceAdded = false;
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < chars.Length; i++)
                    {
                        if (!spaceAdded && chars[i] != ',' && chars[i] != '.' && !Char.IsNumber(chars[i]))
                        {
                            spaceAdded = true;
                            sb.Append(" ");
                        }
                        sb.Append(chars[i]);
                    }
                    var valueUM = sb.ToString().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    if (valueUM != null && valueUM.Length > 0)
                    {
                        if (valueUM[0] != null)
                        {
                            valueUM[0] = valueUM[0].ToNumber(euroFormat);
                        }
                        if (valueUM.Length > 1 && !string.IsNullOrWhiteSpace(valueUM[1]))
                        {
                            var umchars = valueUM[1].Where(p => char.IsLetterOrDigit(p)).ToArray();
                            valueUM[1] = new string(umchars);
                        }
                    }
                    return valueUM.Trim();
                }
            }
            return null;
        }

        public static void Swap(ref double first, ref double second)
        {
            var tmp = first;
            first = second;
            second = tmp;
        }
    }
}
