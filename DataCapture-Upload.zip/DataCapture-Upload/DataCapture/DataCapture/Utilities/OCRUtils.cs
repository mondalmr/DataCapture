﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using IronOcr;

namespace DataCapture
{
    public static class OCRUtils
    {
        private static bool DelFile(string filename)
        {
            bool success = true;
            if (File.Exists(filename))
            {
                try
                {
                    File.Delete(filename);
                }
                catch
                {
                    success = false;
                }
            }
            return success;
        }

        public static string GetTextFromOCRTif(out double accuracy, string characterList, string imageFile, string textFile, int rounds)
        {
            accuracy = 100;
            string text = "";
            if (File.Exists(imageFile))
            {
                if (DelFile(textFile))
                {
                    using (var img = new System.Drawing.Bitmap(imageFile))
                    {
                        var ocr = new Tesseract.TesseractEngine("./tessdata", "eng", Tesseract.EngineMode.TesseractAndCube);
                        ocr.DefaultPageSegMode = Tesseract.PageSegMode.AutoOsd;
                        var xx = ocr.GetType();                        
                        var page = ocr.Process(img);
                        text = page.GetText();
                        accuracy = page.GetMeanConfidence();
                        page.Dispose();
                    }


                    //var Ocr = new AdvancedOcr()
                    //{
                    //    CleanBackgroundNoise = true,
                    //    EnhanceContrast = true,
                    //    EnhanceResolution = true,
                    //    Language = IronOcr.Languages.English.OcrLanguagePack,
                    //    Strategy = IronOcr.AdvancedOcr.OcrStrategy.Advanced,
                    //    ColorSpace = AdvancedOcr.OcrColorSpace.Color,
                    //    DetectWhiteTextOnDarkBackgrounds = false,
                    //    InputImageType = AdvancedOcr.InputTypes.AutoDetect,
                    //    RotateAndStraighten = true,
                    //    ReadBarCodes = false,
                    //    ColorDepth = 8
                    //};
                    ////var testImage = @"C:\path\to\scan.tiff";
                    //var Results = Ocr.Read(imageFile);
                    //text = Results.Text;

                    DelFile(textFile);
                    DelFile(imageFile);
                    //}
                }
            }
            return text;
        }

        public static string GetText(string filePath)
        {
            return GetTextUsingTesseract(filePath);
        }

        public static string GetTextUsingTesseract(string filePath)
        {
            FileInfo fileInfo;
            string textFilePrefix = "ocr_" + DateTime.Now.Day;
            string textFile = "";
            int max = 1000;
            for (int i = 0; i <= 1000; i++)
            {
                textFile = textFilePrefix + "_" + i;
                fileInfo = new FileInfo(textFile + ".txt");
                if (fileInfo.Exists)
                {
                    try
                    {
                        fileInfo.Delete();
                        break;
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                        if (i == max)
                        {
                            return null;
                        }
                    }
                }
                else
                {
                    break;
                }
            }
            string text = null;
            string commandParams = " \"" + filePath + "\" " + textFile + "";
            RunProcess("tesseract", commandParams);

            textFile = textFile + ".txt";

            if (File.Exists(textFile))
            {
                text = File.ReadAllText(textFile);
                try
                {
                    File.Delete(textFile);
                }
                catch (Exception e)
                {
                    e.LogException();
                    return null;
                }
            }
            if (text == null)
            {
                text = "";
            }
            else
            {
                text = text.Replace("\n", "\r\n");
            }
            return text;
        }

        public static void RunProcess(string commandPath, string args)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = commandPath;
            startInfo.Arguments = args;
            startInfo.RedirectStandardOutput = true;
            startInfo.RedirectStandardError = true;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;

            Process process = new Process();
            process.StartInfo = startInfo;
            process.EnableRaisingEvents = true;
            process.Start();
            process.WaitForExit();

            try
            {
                process.Start();
            }
            catch (Exception e)
            {
                e.LogException();
            }
        }
    }
}