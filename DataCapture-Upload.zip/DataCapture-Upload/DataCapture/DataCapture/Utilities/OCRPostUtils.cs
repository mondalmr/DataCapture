﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace DataCapture
{
    public static class OCRPostUtils
    {
        /// <summary>
        /// store all system rules
        /// </summary>
        static OCRPostInfo[] _rules;

        /// <summary>
        /// Mutliple OCR fix menu items. Each time a custom rule menu item
        /// is created it is mainted so that it can be updated.
        /// </summary>
        static List<MenuItem> _userRuleMenuItems = new List<MenuItem>();

        /// <summary>
        /// Collection of user defined replacement rules
        /// </summary>
        static ObservableCollection<OCRPostInfo> _userRules = new ObservableCollection<OCRPostInfo>();

        /// <summary>
        /// System defined words
        /// </summary>
        static string _wordCutTextSystem = "FREIGHT\nPREPAID\nCOLLECT\nCNTR\nSTC\nSAID\nTO\nCONTAIN\nCY\nCFS\nDOOR\nLADEN\nBILL\nFOB\nCIF\n";

        /// <summary>
        /// Word Short Cuts Text is a full text string. Each line is a separate item
        /// </summary>
        static string _wordCutText = _wordCutTextSystem;

        /// <summary>
        /// List of Context Menus for Word Cuts. This list is mainted so that it
        /// can be updated whenever user wants to change it.
        /// </summary>
        static List<ContextMenu> _wordCutContextMenus = new List<ContextMenu>();

        public static void UpdateUserReplacements(IEnumerable<ReplaceInfo> replacements)
        {
            _userRules.Clear();
            var userReplaces = replacements.Where(p => p.OCRFix).ToArray();
            if (userReplaces != null)
            {
                foreach (var rule in userReplaces)
                {
                    if (rule != null)
                    {
                        _userRules.Add(new OCRPostInfo(rule));
                    }
                }
            }

            if (_userRuleMenuItems != null)
            {
                foreach (var item in _userRuleMenuItems)
                {
                    UpdateUserReplacementMenuItem(item);
                }
            }
        }


        public static void UpdateWordCuts(string wordCutText)
        {
            _wordCutText = _wordCutTextSystem + wordCutText;
            if (_wordCutContextMenus != null)
            {
                foreach (var item in _wordCutContextMenus)
                {
                    UpdateWordCutContextMenu(item);
                }
            }
        }


        static void UpdateUserReplacementMenuItem(MenuItem menuItem)
        {
            if (menuItem != null)
            {
                menuItem.Items.Clear();
                if (_userRules != null)
                {
                    foreach (var rule in _userRules)
                    {
                        if (rule != null && !rule.SkipInMenu)
                        {
                            var subMenuItem = new MenuItem();
                            subMenuItem.Padding = new Thickness(1);
                            subMenuItem.Margin = new Thickness(3, 0, 0, 0);
                            subMenuItem.Height = 17;
                            subMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                            subMenuItem.Header = rule.Description;
                            subMenuItem.FontSize = 10;
                            subMenuItem.Tag = rule;
                            subMenuItem.StaysOpenOnClick = true;
                            subMenuItem.Click += subMenuItem_Click;

                            menuItem.Items.Add(subMenuItem);
                        }
                    }
                }
            }
        }

        public static ObservableCollection<OCRPostInfo> GetUserRules()
        {
            return _userRules;
        }

        public static OCRPostInfo[] GetRules()
        {
            if (_rules == null)
            {
                var rules = new List<OCRPostInfo>();
                rules.Add(new OCRPostInfo(new OCRPostNumberRule()));
                rules.Add(new OCRPostInfo(new OCRPostAlphabetRule()));
                rules.Add(new OCRPostInfo(new OCRPostRemoveRule("Remove Numbers", "0123456789")));
                rules.Add(new OCRPostInfo(new OCRPostRemoveRule("Remove Alphabets", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")));
                rules.Add(new OCRPostInfo(new OCRPostRemoveRule("Remove Special Characters", "`~!@#$%^&*()_-+={[}]|\\:;\"',<>.?/£¥")));
                rules.Add(new OCRPostInfo(new ReplaceInfo(" ", "")));
                rules.Add(new OCRPostInfo(new ReplaceInfo(Environment.NewLine, "")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("'|'", "T")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("/-\\", "A")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("I-I", "H")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("l-l", "H")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("|-|", "H")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("~", "-")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("..", ".,")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("/£", "4")));
                rules.Add(new OCRPostInfo(new ReplaceInfo("$", "S")));

                _rules = rules.ToArray();
            }
            return _rules;
        }

        public static void SetupWordCuts(ContextMenu contextMenu)
        {
            if (_wordCutContextMenus == null)
            {
                _wordCutContextMenus = new List<ContextMenu>();
            }
            if (!_wordCutContextMenus.Contains(contextMenu))
            {
                _wordCutContextMenus.Add(contextMenu);
            }
            UpdateWordCutContextMenu(contextMenu);
        }

        private static void UpdateWordCutContextMenu(ContextMenu contextMenu)
        {
            if (contextMenu != null)
            {

                var words = (_wordCutText ?? string.Empty).Split(new string[] { Environment.NewLine, "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.TrimEnd()).Where(p => !string.IsNullOrWhiteSpace(p)).Distinct().OrderBy(p => p).ToArray();
                contextMenu.Items.Clear();
                foreach (string word in words)
                {
                    if (!string.IsNullOrEmpty(word))
                    {
                        var wordCutMenuItem = new MenuItem();
                        wordCutMenuItem.Padding = new Thickness(1);
                        wordCutMenuItem.Margin = new Thickness(3, 0, 0, 0);
                        wordCutMenuItem.Height = 17;
                        wordCutMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                        wordCutMenuItem.Header = word;
                        wordCutMenuItem.FontSize = 10;
                        wordCutMenuItem.Tag = new OCRPostInfo(new WordCutRule() { Description = word, Text = word });
                        wordCutMenuItem.Click += wordCutMenuItem_Click;
                        contextMenu.Items.Add(wordCutMenuItem);
                    }
                }
            }
        }

        public static void SetupContextMenu(ContextMenu cm)
        {
            if (cm != null && cm.Items != null)
            {
                ItemCollection items = null;
                if (cm.Items.Count == 0)
                {
                    items = cm.Items;
                }
                else
                {
                    foreach (var item in cm.Items)
                    {
                        var menuItem = item as MenuItem;
                        if (menuItem != null)
                        {
                            if (menuItem.Header != null)
                            {
                                var headerText = menuItem.Header.ToString().ToUpper();
                                if (headerText.Contains("QUICK FIX"))
                                {
                                    if (menuItem.Items != null && menuItem.Items.Count == 0)
                                    {
                                        cm.Opened += cm_Opened;
                                        menuItem.SubmenuOpened += menuItem_SubmenuOpened;
                                        items = menuItem.Items;
                                    }
                                }
                            }
                        }
                    }
                }
                if (items != null)
                {
                    var rules = GetRules();
                    if (rules != null)
                    {
                        var subMenuItem = new MenuItem();
                        subMenuItem.Padding = new Thickness(1);
                        subMenuItem.Margin = new Thickness(3, 0, 0, 0);
                        subMenuItem.Height = 17;
                        subMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                        subMenuItem.FontSize = 10;
                        subMenuItem.Header = "Close";
                        items.Add(subMenuItem);

                        var customMenuItem = new MenuItem();
                        customMenuItem.Padding = new Thickness(1);
                        customMenuItem.Margin = new Thickness(3, 0, 0, 0);
                        customMenuItem.Height = 17;
                        customMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                        customMenuItem.FontSize = 10;
                        customMenuItem.Header = "Custom";

                        if (_userRuleMenuItems == null)
                        {
                            _userRuleMenuItems = new List<MenuItem>();
                        }
                        _userRuleMenuItems.Add(customMenuItem);

                        UpdateUserReplacementMenuItem(customMenuItem);

                        items.Add(customMenuItem);

                        items.Add(new Separator());
                        foreach (var rule in rules)
                        {
                            if (rule != null && !rule.SkipInMenu)
                            {
                                subMenuItem = new MenuItem();

                                subMenuItem.Padding = new Thickness(1);
                                subMenuItem.Margin = new Thickness(3, 0, 0, 0);
                                subMenuItem.Height = 17;
                                subMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                                subMenuItem.Header = rule.Description;
                                subMenuItem.FontSize = 10;
                                subMenuItem.Tag = rule;
                                subMenuItem.StaysOpenOnClick = true;
                                subMenuItem.Click += subMenuItem_Click;

                                items.Add(subMenuItem);
                            }
                        }

                        //items.Add(new Separator());
                    }
                }
            }
        }

        static void cm_Opened(object sender, RoutedEventArgs e)
        {
            var cm = sender as ContextMenu;
            if (cm != null && cm.Items != null && cm.Items.Count > 0)
            {
                var tb = cm.PlacementTarget as TextBox;
                if (tb != null)
                {
                    var enabled = tb.IsEnabled && !tb.IsReadOnly;
                    foreach (var item in cm.Items)
                    {
                        var menuItem = item as MenuItem;
                        if (menuItem != null && menuItem.Header != null && menuItem.Header is string)
                        {
                            var header = menuItem.Header.ToString().ToUpper();
                            if (header != null && header.Contains("OCR"))
                            {
                                menuItem.IsEnabled = enabled;
                            }
                        }
                    }
                }
            }
        }

        static void menuItem_SubmenuOpened(object sender, RoutedEventArgs e)
        {
            var menuItem = sender as MenuItem;
            if (menuItem != null && menuItem.Items != null)
            {
                foreach (var item in menuItem.Items)
                {
                    if (item is MenuItem)
                    {
                        ((MenuItem)item).Foreground = Brushes.Black;
                    }
                }
            }
        }

        static void wordCutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (ExecuteOCRFix(sender as MenuItem, MainWindow.Current))
            {
                e.Handled = true;
            }
        }

        static void subMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (ExecuteOCRFix(sender as MenuItem, MainWindow.Current))
            {
                e.Handled = true;
            }
        }

        public static bool ExecuteOCRFix(this MenuItem menuItem, Window window)
        {
            var success = false;
            if (menuItem != null)
            {
                var ctx = menuItem.GetContextMenu();
                if (ctx != null)
                {
                    OCRPostInfo rule = menuItem.Tag as OCRPostInfo;
                    DataCaptureInfo blInfo = null;
                    bool euroFormat = false;
                    if (window is MainWindow)
                    {
                        euroFormat = false;
                        blInfo = ((MainWindow)window).DCInfo;
                    }
                    int selectionStart = -1;
                    int selectionLength = 0;
                    string original = "";
                    DataCaptureElement blElement = null;
                    var tb = ctx.PlacementTarget as TextBox;
                    var dgc = ctx.PlacementTarget as DataGridCell;
                    var rb = ctx.PlacementTarget as RadioButton;
                    var multiline = false;
                    TextBlock tbdgc = null;
                    if (tb != null)
                    {
                        if (rule != null && rule.Rule is ReplaceInfo && tb.SelectionLength == 0)
                        {
                            if (tb.Text.Length > 0)
                            {
                                tb.SelectionStart = 0;
                                tb.SelectionLength = tb.Text.Length;
                            }
                        }
                        selectionStart = tb.SelectionStart;
                        selectionLength = tb.SelectionLength;

                        original = tb.SelectedText;
                        multiline = tb.AcceptsReturn;
                    }
                    else if (dgc != null)
                    {
                        multiline = true;
                        original = "";
                        tbdgc = dgc.Content as TextBlock;
                        if (tbdgc != null)
                        {
                            original = tbdgc.Text;
                        }
                    }
                    else if (rb != null)
                    {
                        // Update binding for current textbox if applicable
                        var currentTB = FocusManager.GetFocusedElement(window) as TextBox;
                        if (currentTB != null)
                        {
                            var binding = currentTB.GetBindingExpression(TextBox.TextProperty);
                            if (binding != null)
                            {
                                binding.UpdateSource();
                            }
                        }

                        blElement = rb.Tag as DataCaptureElement;
                        if (blInfo == null || blElement == null || blElement.DCElementType == DataCaptureElementType.PackageGrid || blElement.DCElementType == DataCaptureElementType.General)
                        {
                            MessageBox.Show("This option is not available for the selected element.");
                            return success;
                        }
                        original = blInfo.GetElementValue(blElement.DCElementType);
                        switch (blElement.DCElementType)
                        {
                            //case DataCaptureElementType.AlsoNotifyExportReference:
                            //case DataCaptureElementType.BLTextBody:
                            //case DataCaptureElementType.Consignee:
                            //case DataCaptureElementType.Containers:
                            //case DataCaptureElementType.Forwarder:
                            //case DataCaptureElementType.GoodsDescription:
                            //case DataCaptureElementType.MarksNos:
                            //case DataCaptureElementType.NotifyParty:
                            //case DataCaptureElementType.NotifyParty2:
                            //case DataCaptureElementType.NotifyParty3:
                            case DataCaptureElementType.MultilineElement1:
                                multiline = true;
                                break;
                        }
                    }
                    if (tb != null || dgc != null || rb != null)
                    {
                        if (rule != null && rule.Rule is ReplaceInfo && string.IsNullOrWhiteSpace(original))
                        {
                            MessageBox.Show("Please select text you want to fix and try again.");
                            return success;
                        }

                        var proceed = rule != null;
                        string text = null;
                        if (proceed)
                        {
                            if (rule.Rule != null)
                            {
                                text = rule.Rule.Apply(original);
                            }
                        }
                        else
                        {
                            var task = new OCRPostTask();
                            task.Original = original;
                            task.Fixed = original;

                            var fixer = new OCRFixer();
                            fixer.DataContext = task;
                            fixer.Owner = window;
                            fixer.AcceptsReturn = multiline;

                            if (fixer.ShowDialog() == true)
                            {
                                proceed = true;
                                text = task.Fixed;
                            }
                        }
                        if (proceed && text != null)
                        {
                            if (rb != null)
                            {
                                if (string.IsNullOrWhiteSpace(blInfo.ApplyElement(blElement.DCElementType, -1, text, euroFormat)))
                                {
                                    success = true;
                                }
                            }
                            else if (tb != null)
                            {
                                tb.SelectionStart = selectionStart;
                                tb.SelectionLength = selectionLength;
                                tb.SelectedText = text;
                                tb.SelectionStart = selectionStart;
                                tb.SelectionLength = text.Length;
                                success = true;
                            }
                            else if (tbdgc != null)
                            {
                                var drv = tbdgc.DataContext as DataRowView;
                                if (drv != null && drv.Row != null && drv.Row.Table != null && drv.Row.Table.Columns != null)
                                {
                                    var bindingExpression = tbdgc.GetBindingExpression(TextBlock.TextProperty);
                                    if (bindingExpression != null)
                                    {
                                        var binding = bindingExpression.ParentBinding;
                                        if (binding != null && binding.Path != null && !string.IsNullOrWhiteSpace(binding.Path.Path))
                                        {
                                            if (drv.Row.Table.Columns.Contains(binding.Path.Path))
                                            {
                                                drv[binding.Path.Path] = text;
                                                success = true;
                                            }
                                        }
                                    }
                                }
                            }
                            if (success && rule != null)
                            {
                                menuItem.Foreground = Brushes.DarkGray;
                            }
                        }
                    }
                }
            }
            return success;
        }

        public static void ShowOCRFixContext(object sender, KeyEventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                var window = sender as Window;
                if (window != null)
                {
                    string cm = "";
                    if (e.Key == Key.K)//if (e.Key == Key.OemPeriod)
                    {
                        cm = "CMCtrlK";//cm = "CMCtrlDot";
                    }
                    else if (e.Key == Key.Q || e.Key == Key.Add)//else if (e.Key == Key.OemPlus || e.Key == Key.Add)
                    {
                        cm = "CMCtrlQ";//cm = "CMCtrlPlus";
                    }
                    if (!string.IsNullOrWhiteSpace(cm))
                    {
                        OpenOCRFixContextMenu(window, cm);
                    }
                }
            }
        }

        public static void OpenOCRFixContextMenu(Window window, string cmName)
        {
            if (window != null && !string.IsNullOrWhiteSpace(cmName))
            {
                ContextMenu cm = window.FindResource(cmName) as ContextMenu;
                if (cm != null && cm.Items != null)
                {
                    var tb = Keyboard.FocusedElement as TextBox;
                    if (tb == null)
                    {
                        tb = FocusManager.GetFocusedElement(window) as TextBox;

                    }
                    if (tb != null && tb.IsEnabled && !tb.IsReadOnly)
                    {
                        foreach (var item in cm.Items)
                        {
                            if (item is MenuItem)
                            {
                                ((MenuItem)item).Foreground = Brushes.Black;
                            }
                        }
                        cm.Placement = PlacementMode.Bottom;
                        cm.PlacementTarget = tb;
                        if (tb.AcceptsReturn)
                        {
                            var rect = tb.GetRectFromCharacterIndex(tb.CaretIndex);
                            cm.HorizontalOffset = rect.Right;
                            cm.VerticalOffset = rect.Bottom;
                            cm.Placement = PlacementMode.RelativePoint;
                        }
                        else
                        {
                        }
                        cm.IsOpen = true;
                    }
                }
            }
        }



    }
}