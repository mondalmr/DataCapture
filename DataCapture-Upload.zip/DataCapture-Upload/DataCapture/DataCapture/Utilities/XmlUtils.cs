﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace DataCapture
{
    public static class XmlUtils
    {
        public static void SaveFile(string filePath, object element)
        {
            if (element != null)
            {
                TextWriter writer = new StreamWriter(filePath);
                XmlSerializer serializer = new XmlSerializer(element.GetType());
                serializer.Serialize(writer, element);
                writer.Close();
            }
        }

        public static T LoadFile<T>(string filePath)
        {
            FileStream reader = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            object data = serializer.Deserialize(reader);
            return (T)data;
        }

        public static DCTemplate CreateSITemplate(DataCaptureElement[] elements, MainWindow siCapture)
        {
            if (elements != null && elements.Length > 0)
            {
                DCTemplate template = new DCTemplate();

                template.WordCuts = siCapture.WordCutText;
                template.Replacements = siCapture.Replacements;
                template.OCRSize = siCapture.OCRSize.SelectedValue.ToString();

                //template.DefaultPkgCode = siCapture.TBDefPkgType.Text;
                //template.DefaultGWUM = siCapture.TBDefGWUM.Text;
                //template.DefaultNWUM = siCapture.TBDefNWUM.Text;
                //template.DefaultGMUM = siCapture.TBDefGMUM.Text;
                //template.DefaultNMUM = siCapture.TBDefNMUM.Text;

                List<DCTemplateElement> templateElements = new List<DCTemplateElement>();
                foreach (DataCaptureElement element in elements)
                {
                    var rectangles = element._Rectangles;
                    if (rectangles != null)
                    {
                        for (int i = 0; i < rectangles.Count(); i++)
                        {
                            var rectangle = rectangles[i];
                            if (rectangle != null)
                            {
                                DCTemplateElement templateElement = new DCTemplateElement();
                                templateElement.ElementType = element.DCElementType;
                                templateElement.Left = Canvas.GetLeft(rectangle);
                                templateElement.Top = Canvas.GetTop(rectangle);
                                templateElement.Width = rectangle.ActualWidth;
                                templateElement.Height = rectangle.ActualHeight;
                                templateElement.PageNo = i;
                                templateElement.Visible = (rectangle.Visibility == Visibility.Visible);
                                Grid packageGrid = rectangle as Grid;
                                if (packageGrid != null)
                                {
                                    templateElement.Rows = packageGrid.SerializeRows;
                                    templateElement.RowsEnd = packageGrid.SerializeRowsEnd;
                                    templateElement.RowsPkg = packageGrid.SerializeRowsPkg;
                                    //templateElement.RowsMks = packageGrid.SerializeRowsMks;
                                    //templateElement.RowsGds = packageGrid.SerializeRowsGds;
                                    templateElement.Columns = packageGrid.SerializeColumns;
                                    templateElement.ColumnContents = packageGrid.SerializeColumnContents;
                                }
                                templateElements.Add(templateElement);
                            }
                        }
                    }

                }
                template.TemplateElements = templateElements.ToArray();
                return template;
            }
            return null;
        }

        public static void ReadFromTemplate(MainWindow window, DCTemplate template, DataCaptureElement[] elements, DataCaptureInfo blInfo,bool automate = false)
        {
            if (template != null && template.TemplateElements != null)
            {
                window.WordCutText = template.WordCuts;
                window.Replacements = template.Replacements;

                if (!string.IsNullOrWhiteSpace(template.OCRSize))
                {
                    window.OCRSize.SelectedValue = template.OCRSize;
                }

                blInfo.DefaultPkgCode = template.DefaultPkgCode ?? string.Empty;
                blInfo.DefaultGWUM = template.DefaultGWUM ?? string.Empty;
                blInfo.DefaultNWUM = template.DefaultNWUM ?? string.Empty;
                blInfo.DefaultGMUM = template.DefaultGMUM ?? string.Empty;
                blInfo.DefaultNMUM = template.DefaultNMUM ?? string.Empty;

                foreach (DCTemplateElement templateElement in template.TemplateElements)
                {
                    foreach (DataCaptureElement element in elements)
                    {
                        if (templateElement.ElementType == element.DCElementType)
                        {
                            var rectangles = element._Rectangles;
                            if (rectangles != null)
                            {
                                //Rectangle rectangle = null;
                                FrameworkElement rectangle = null;
                                int count = rectangles.Count();
                                if (count <= templateElement.PageNo)
                                {
                                    for (int i = count; i <= templateElement.PageNo; i++)
                                    {
                                        rectangle = window.CreateRectangleForBLElement(element);
                                        element.SetRectangle(i, rectangle);
                                    }
                                }
                                if (rectangles[templateElement.PageNo] == null)
                                {
                                    rectangles[templateElement.PageNo] = new Rectangle();
                                }
                                rectangle = rectangles[templateElement.PageNo];
                                rectangle.Width = templateElement.Width;
                                rectangle.Height = templateElement.Height;

                                var packageGrid = rectangle as Grid;
                                if (packageGrid != null)
                                {
                                    packageGrid.SetupProperties();
                                    packageGrid.SerializeRows = templateElement.Rows;
                                    packageGrid.SerializeRowsEnd = templateElement.RowsEnd;
                                    packageGrid.SerializeRowsPkg = templateElement.RowsPkg;
                                    //packageGrid.SerializeRowsMks = templateElement.RowsMks;
                                    //packageGrid.SerializeRowsGds = templateElement.RowsGds;
                                    packageGrid.SerializeColumns = templateElement.Columns;
                                    packageGrid.SerializeColumnContents = templateElement.ColumnContents;
                                    packageGrid.SetupAvailableColumns();
                                }

                                Canvas.SetLeft(rectangle, templateElement.Left);
                                Canvas.SetTop(rectangle, templateElement.Top);
                                window.HighlightAdorner(rectangle, false);
                                if (templateElement.Visible && !automate)
                                {
                                    rectangle.Visibility = Visibility.Visible;
                                    rectangle.SetPositionInToolTip();
                                }
                                else
                                {
                                    rectangle.Visibility = Visibility.Collapsed;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }

        public static void LoadTemplate(MainWindow window, string filePath, DataCaptureElement[] elements, DataCaptureInfo blInfo)
        {
            if (elements != null && elements.Length > 0)
            {
                DCTemplate template = LoadFile<DCTemplate>(filePath);
                ReadFromTemplate(window, template, elements, blInfo);
            }
        }

        public static void SaveTemplate(string filePath, DataCaptureElement[] elements, MainWindow siCapture)
        {
            DCTemplate template = CreateSITemplate(elements, siCapture);
            if (template != null)
            {
                SaveFile(filePath, template);
            }
        }                

        public static void SaveWorkFile(string filePath, string siPath, DataCaptureElement[] elements, DataCaptureInfo blInfo, MainWindow siCapture)
        {
            if (blInfo != null)
            {
                DCTemplate template = CreateSITemplate(elements, siCapture);
                if (template != null)
                {
                    try
                    {
                        WorkFile wFile = new WorkFile();
                        wFile.SITemplate = template;
                        wFile.BLInfo = blInfo;
                        wFile.SIPath = siPath;
                        wFile.SIData = FileToBase64(siPath);
                        wFile.ImageActions = siCapture.ImageActions;
                        SaveFile(filePath, wFile);
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show("Error occurred could not save work file." + Environment.NewLine + e.Message, "Error");
                        e.LogException();
                    }
                }
            }
        }

        public static string FileToBase64(string filePath)
        {
            if (!string.IsNullOrWhiteSpace(filePath))
            {
                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException();
                }
                byte[] fileBytes = File.ReadAllBytes(filePath);
                if (fileBytes != null)
                {
                    string base64 = Convert.ToBase64String(fileBytes);
                    return base64;
                }
            }
            return null;
        }

        public static bool Base64ToFile(string filePath, string base64String)
        {
            if (!string.IsNullOrWhiteSpace(filePath) && !string.IsNullOrWhiteSpace(base64String))
            {
                if (!File.Exists(filePath))
                {
                    byte[] fileBytes = Convert.FromBase64String(base64String);
                    File.WriteAllBytes(filePath, fileBytes);
                    return true;
                }
            }
            return false;
        }
    }
}
