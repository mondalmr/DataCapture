﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public static class ImageUtils
    {

        public static PixelFormat DefaultPixelFormat
        {
            get
            {
                return PixelFormat.Format24bppRgb;
            }
        }

        public static int DefaultPixelFormatByteLength
        {
            get
            {
                return (int)Math.Ceiling((double)Image.GetPixelFormatSize(DefaultPixelFormat) / 8);
            }
        }

        /// <summary>
        /// Paint inset section white
        /// </summary>
        /// <param name="image"></param>
        /// <returns></returns>
        public static Bitmap WhiteOutInset(Bitmap image, HighlightRegion region)
        {
            var rect = region.GetInsetRect();
            if (rect.Width > 0 && rect.Height > 0)
            {
                Bitmap bmp = new Bitmap(image.Width, image.Height);
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    graphics.DrawImage(image, 0, 0, image.Width, image.Height);
                    graphics.FillRectangle(new SolidBrush(Color.White), (float)rect.Left, (float)rect.Top, (float)rect.Width, (float)rect.Height);
                }
                return bmp;
            }
            return image;
        }

        /// <summary>
        /// Add whitespace to the image
        /// </summary>
        /// <param name="image"></param>
        /// <param name="padWidth">new width. ignored if less than image width</param>
        /// <param name="padHeight">new height ignored if less than image height</param>
        /// <returns></returns>
        public static Bitmap PaddedImage(Bitmap image, int padWidth, int padHeight)
        {

            int width = image.Width;
            int height = image.Height;

            if (width > padWidth && height > padHeight)
            {
                return image;
            }
            else
            {
                PixelFormat pf = image.PixelFormat;
                if (pf == PixelFormat.Format1bppIndexed)
                {
                    pf = PixelFormat.Format32bppArgb;
                }
                int nWidth = Math.Max(padWidth, width);
                int nHeight = Math.Max(padHeight, height);
                Bitmap bmp = new Bitmap(nWidth, nHeight, pf);
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    graphics.FillRectangle(new SolidBrush(Color.White), 0, 0, nWidth, nHeight);
                    graphics.DrawImage(image, 0, 0, width, height);
                }
                if (image.PixelFormat == PixelFormat.Format1bppIndexed)
                {
                    var tmp = BlackAndWhite(bmp);
                    if (tmp != bmp)
                    {
                        bmp.Dispose();
                        GC.Collect();
                    }
                    bmp = tmp;
                }
                return bmp;
            }
        }

        public static Bitmap ResizeImage(Bitmap image, double ratio)
        {

            int width = (int)(image.Width * ratio);
            int height = (int)(image.Height * ratio);
            PixelFormat pf = image.PixelFormat;
            if (pf == PixelFormat.Format1bppIndexed)
            {
                pf = PixelFormat.Format32bppArgb;
            }

            Bitmap bmp = new Bitmap(width, height, pf);

            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                if (image.PixelFormat == PixelFormat.Format1bppIndexed)
                {
                    graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
                }
                else
                {
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                }
                graphics.DrawImage(image, 0, 0, width, height);
            }
            if (image.PixelFormat == PixelFormat.Format1bppIndexed)
            {
                var tmp = BlackAndWhite(bmp);
                if (tmp != bmp)
                {
                    bmp.Dispose();
                    GC.Collect();
                }
                bmp = tmp;
            }

            return bmp;
        }


        public static Bitmap ResizeImage(Bitmap image, double targetWidth, double targetHeight, bool skipBW = false)
        {
            PixelFormat pf = image.PixelFormat;
            if (pf == PixelFormat.Format1bppIndexed)
            {
                pf = PixelFormat.Format32bppArgb;
                pf = DefaultPixelFormat;
            }

            Bitmap bmp = new Bitmap((int)targetWidth, (int)targetHeight, pf);

            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                if (!skipBW && image.PixelFormat == PixelFormat.Format1bppIndexed)
                {
                    graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
                }
                else
                {
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                }
                graphics.DrawImage(image, 0, 0, (int)targetWidth, (int)targetHeight);
            }
            if (!skipBW && image.PixelFormat == PixelFormat.Format1bppIndexed)
            {
                var tmp = BlackAndWhite(bmp);
                if (tmp != bmp)
                {
                    bmp.Dispose();
                    GC.Collect();
                }
                bmp = tmp;
            }
            return bmp;

        }

        /// <summary>
        /// Flips an image in a direction
        /// </summary>
        /// <param name="image"></param>
        /// <param name="flip">string version of enum type RotateFlipType</param>
        /// <returns>true if width and height gets swapped. this is the case when you rotate 90 or 270 degreees</returns>
        internal static bool Flip(Bitmap image, string flip)
        {
            if (!string.IsNullOrWhiteSpace(flip))
            {
                var flipType = (RotateFlipType)Enum.Parse(typeof(RotateFlipType), flip, true);
                if (flipType != RotateFlipType.RotateNoneFlipNone)
                {
                    image.RotateFlip(flipType);
                    switch (flipType)
                    {
                        case RotateFlipType.Rotate90FlipNone:
                        case RotateFlipType.Rotate90FlipX:
                        case RotateFlipType.Rotate90FlipXY:
                        case RotateFlipType.Rotate90FlipY:
                            return true;
                    }

                    switch (flipType)
                    {
                        case RotateFlipType.Rotate270FlipNone:
                        case RotateFlipType.Rotate270FlipX:
                        case RotateFlipType.Rotate270FlipXY:
                        case RotateFlipType.Rotate270FlipY:
                            return true;
                    }
                }
            }
            return false;
        }

        public static ImageColorInfo GetImageColorInfo(this Image image)
        {
            var colorInfo = ImageColorInfo.AllWhite;
            if (image != null)
            {
                int width = image.Width;
                int height = image.Height;
                int stride = 0;
                int byteSize = 0;
                byte[] buffer = null;
                var pf = PixelFormat.Format32bppArgb;
                using (var bmp = new Bitmap(width, height, pf))
                {
                    using (var graphics = Graphics.FromImage(bmp))
                    {
                        graphics.DrawImage(image, 0, 0);
                    }
                    var data = bmp.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, pf);
                    stride = data.Stride;
                    byteSize = stride * height;
                    buffer = new byte[byteSize];
                    Marshal.Copy(data.Scan0, buffer, 0, byteSize);
                    bmp.UnlockBits(data);
                }
                GC.Collect();
                int idx;
                int offset;
                for (int i = 0; i < height; i++)
                {
                    offset = i * stride;
                    for (int j = 0; j < width; j++)
                    {
                        idx = offset + (j * 4);
                        if (colorInfo != ImageColorInfo.Grayscale && buffer[idx + 2] == buffer[idx + 1] && buffer[idx + 2] == buffer[idx]) // check for greyscale or black
                        {
                            if (buffer[idx] == 0) // check for black
                            {
                                colorInfo = ImageColorInfo.BlackWhite;
                            }
                            else if(buffer[idx]<250)
                            {
                                colorInfo = ImageColorInfo.Grayscale;
                            }
                        }
                        if (buffer[idx + 2] != buffer[idx + 1] || buffer[idx + 2] != buffer[idx] || buffer[idx + 1] != buffer[idx])
                        {
                            return ImageColorInfo.Colored;
                        }
                    }
                }
            }
            return colorInfo;
        }

        public static ImageAction[] DeSkewImageInBlocks(Bitmap image, CustomDeskewInfo deskewInfo, int pageNo, ImageAction[] pageActions)
        {
            var tmpImage = image;
            List<ImageAction> actions = new List<ImageAction>();

            if (deskewInfo != null && deskewInfo.Width > 0 && deskewInfo.Height > 0)
            {
                if (pageActions != null)
                {
                    var nonCustomActions = pageActions.Where(p => p.Page == pageNo && p.IsCustom == false).ToArray();
                    if (nonCustomActions != null & nonCustomActions.Length > 0)
                    {
                        tmpImage = ApplyImageAction(image, nonCustomActions);
                    }
                }
                var bw = new BitmapWorker(tmpImage);
                var bwRects = bw.GetBlocks(deskewInfo);

                if (tmpImage != image)
                {
                    tmpImage.Dispose();
                    GC.Collect();
                    tmpImage = image;
                }

                foreach (var rect in bwRects)
                {
                    if (rect != null)
                    {
                        var action = new ImageAction();
                        action.Left = rect.Left;
                        action.Top = rect.Top;
                        action.Width = rect.Width;
                        action.Height = rect.Height;
                        action.Operation = ImageOperation.Deskew;
                        action.IsCustom = true;
                        action.Page = pageNo;

                        if (pageActions != null)
                        {
                            if (pageActions.Where(p => p.Equals(action) && (p.Skip || !p.IsCustom)).FirstOrDefault() != null)
                            {
                                action = null;
                            }
                        }

                        if (action != null)
                        {
                            actions.Add(action);
                        }
                    }
                }
            }

            return actions.ToArray();
        }

        public static Bitmap DeSkewImage(Bitmap image, out double skewAngle, bool full = false, bool sans = false)
        {
            double unskewAngle = 0;
            var helper = new DeskewHelper(image, full);
            skewAngle = helper.GetSkewAngle();
            if (skewAngle != 0)
            {
                unskewAngle = (double)skewAngle * -1;
            }
            if (unskewAngle != 0)
            {
                if (sans)
                {
                    return RotateImageSansClipping(image, (float)unskewAngle);
                }
                else
                {
                    return RotateAndReSize(image, (float)unskewAngle, image.Width, image.Height);
                }
                
            }
            return image;
        }

        public static Bitmap RotateImageSansClipping(Bitmap image, float angle)
        {
            if (angle != 0)
            {
                int width = image.Width;
                int height = image.Height;
                double an = angle * Math.PI / 180;
                double cos = Math.Abs(Math.Cos(an));
                double sin = Math.Abs(Math.Sin(an));
                int nl = (int)(width * cos + height * sin);
                int nh = (int)(width * sin + height * cos);
                Bitmap bmp = new Bitmap(nl, nh);
                Graphics g = Graphics.FromImage(bmp);

                g.TranslateTransform((float)(nl - width) / 2, (float)(nh - height) / 2);
                g.TranslateTransform((float)image.Width / 2, (float)image.Height / 2);
                g.RotateTransform(angle);
                g.TranslateTransform(-(float)image.Width / 2, -(float)image.Height / 2);
                g.Clear(Color.White);
                g.DrawImage(image, new Point(0, 0));
                return bmp;
            }
            return image;
        }

        public static Bitmap ResizeAndDeSkewImage(Bitmap image, bool unskewImage, int  imageColor, float width, float height, bool fulldeskew = false)
        {
            if (image != null)
            {
                double unskewAngle = 0;
                if (unskewImage)
                {
                    var helper = new DeskewHelper(image, fulldeskew);
                    var skewAngle = helper.GetSkewAngle();
                    if (skewAngle != 0)
                    {
                        unskewAngle = (double)skewAngle * -1;
                    }
                }
                Bitmap tmp1 = null;
                var tmp = RotateAndReSize(image, (float)unskewAngle, width, height);
                if (imageColor == 0) // Black and White
                {
                    //CleanUpImage(image);
                    tmp1 = BlackAndWhite(tmp);
                }
                else if (imageColor == 1) // Grayscale
                {
                    tmp1 = Grayscale(tmp);
                }
                if (tmp1 != null)
                {
                    tmp.Dispose();
                    tmp = tmp1;
                }
                return tmp;
            }
            return image;
        }

        public static void SaveAsTiff(this Bitmap image, string path)
        {
            image.Save(path, ImageFormat.Tiff);
        }

        public static Bitmap CropImage(this Bitmap image, int left, int top, int width, int height)
        {
            if (image.Width >= (left + width) && image.Height >= (top + height))
            {
                return image.Clone(new Rectangle(left, top, width, height), image.PixelFormat);
            }
            return null;
        }

        public static Bitmap CropImage(this Bitmap image, HighlightRegion highlightRegion)
        {
            var croppedImage = image.CropImage((int)highlightRegion.Left, (int)highlightRegion.Top, (int)highlightRegion.Width, (int)highlightRegion.Height);
            croppedImage = WhiteOutInset(croppedImage, highlightRegion);
            return croppedImage;
        }

        public static Bitmap MergeImages(this IEnumerable<PDFImageCtm> ctms, int rotation, double pageHeight, bool clearImage, ref double scaleWidth, ref double scaleHeight)
        {
            if (ctms != null && ctms.Count() > 0)
            {
                scaleWidth = 0;
                scaleHeight = 0;
                var maxXFactor = ctms.Max(c => c.XFactor);
                var maxYFactor = ctms.Max(c => c.YFactor);
                var maxScaleX = ctms.Max(c => (c.X + Math.Abs(c.ScaleWidth)));
                var maxScaleY = ctms.Max(c => (c.Y + Math.Abs(c.ScaleHeight)));
                var imageWidth = maxXFactor * maxScaleX;
                var imageHeight = maxYFactor * maxScaleY;
                int maxWidth = 0;
                int maxHeight = 0;
                int idx = 0;
                foreach (var ctm in ctms)
                {
                    double scaleX = (ctm.X + Math.Abs(ctm.ScaleWidth));
                    if (ctm.ScaleWidth == 0)
                    {
                        scaleX = ctm.X + ctm.ActualWidth;
                    }
                    //double xwidth = scaleX * ctm.XFactor;
                    double xwidth = scaleX * maxXFactor;
                    if (maxWidth < (int)xwidth)
                    {
                        maxWidth = (int)xwidth;
                    }
                    if (scaleWidth < scaleX)
                    {
                        scaleWidth = scaleX;
                    }

                    double y = pageHeight - ctm.Y - ctm.ScaleHeight;
                    if (rotation == 90 || rotation == 270)
                    {
                        y = ctm.Y;
                    }
                    double scaleY = (y + Math.Abs(ctm.ScaleHeight));
                    if (ctm.ScaleHeight == 0)
                    {
                        scaleY = ctm.Y + ctm.ActualHeight;
                    }
                    //double xheight = scaleY * ctm.YFactor;
                    double xheight = scaleY * maxYFactor;
                    if (maxHeight < (int)xheight)
                    {
                        maxHeight = (int)xheight;
                    }
                    if (scaleHeight < scaleY)
                    {
                        scaleHeight = scaleY;
                    }
                }

                var useScale = false;
                if (maxWidth > 10000 || maxHeight > 10000)
                {
                    maxWidth = (int)scaleWidth;
                    maxHeight = (int)scaleHeight;
                    useScale = true;
                }

                Bitmap bmp = new Bitmap(maxWidth, maxHeight, DefaultPixelFormat);
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    try
                    {
                        var ctmX = 0d;
                        var ctmY = 0d;
                        var ctmWidth = 0d;
                        var ctmHeight = 0d;

                        graphics.Clear(Color.White);
                        foreach (var ctm in ctms)
                        {
                            double ynew = 0;
                            if (rotation == 90 || rotation == 270)
                            {
                                ynew = useScale ? ctm.AdjustedY : ctm.Y;
                            }
                            else
                            {
                                //ynew = (double)height - ctm.AdjustedY - ctm.ActualHeight;
                                if (useScale)
                                {
                                    if (ctm.Y == 0)
                                    {
                                        ynew = 0;
                                    }
                                    else
                                    {
                                        if (ctm.ScaleHeight < 0)
                                        {
                                            ynew = (pageHeight - ctm.Y);
                                            ynew = (pageHeight - ctm.Y - ctm.ScaleHeight);
                                        }
                                        else
                                        {
                                            ynew = (pageHeight - ctm.Y - ctm.ScaleHeight);
                                        }
                                    }
                                }
                                else
                                {
                                    if (ctm.AdjustedY == 0)
                                    {
                                        ynew = 0;
                                    }
                                    else
                                    {
                                        ynew = (pageHeight - ctm.Y - ctm.ScaleHeight) * ctm.YFactor;
                                    }
                                }
                            }
                            if (ynew < 0)
                            {
                                ynew = 0;
                            }
                            var img = ctm.Image;
                            if (img is Bitmap)
                            {
                                try
                                {
                                    ((Bitmap)img).MakeTransparent();
                                }
                                catch
                                {
                                }
                            }
                            if (useScale)
                            {
                                ctmX = ctm.X;
                            }
                            else
                            {
                                ctmX = ctm.AdjustedX;
                            }
                            ctmY = ynew;
                            if (scaleWidth == (ctm.X + ctm.ScaleWidth))
                            {
                                ctmWidth = maxWidth - ctmX;
                            }
                            else
                            {
                                if (useScale)
                                {
                                    ctmWidth = Math.Abs(ctm.ScaleWidth);
                                    ctmWidth = ctm.ScaleWidth;
                                }
                                else
                                {
                                    ctmWidth = ctm.ActualWidth;
                                }
                            }
                            if (scaleHeight == (ctm.Y + ctm.ScaleHeight))
                            {
                                ctmHeight = maxHeight - ctmY;
                            }
                            else
                            {
                                if (useScale)
                                {
                                    ctmHeight = Math.Abs(ctm.ScaleHeight);
                                    ctmHeight = ctm.ScaleHeight;
                                }
                                else
                                {
                                    ctmHeight = ctm.ActualHeight;
                                }
                            }

                            idx++;
                            //img.Save(@"img_" + idx + "_" + ((int)ctmY) + "_" + ((int)ctmX) + "_" + ((int)ctmHeight) + "_" + ((int)ctmWidth) + ".png");

                            if (useScale)
                            {
                                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            }

                            if (ctm.SkewX != 0 || ctm.SkewY != 0)
                            {
                                // skew TODO
                                /*
                                double angleX = Math.Atan(ctm.SkewX) * 180 / Math.PI;
                                double angleY = Math.Atan(ctm.SkewX) * 180 / Math.PI;
                                graphics.DrawImage(img, SkewRectangle(ctm.AdjustedX, ynew, ctm.ActualWidth, ctm.ActualHeight, angleX, angleY));
                                */
                                graphics.DrawImage(img, (float)ctmX, (float)ctmY, (float)ctmWidth, (float)ctmHeight);
                            }
                            else
                            {
                                graphics.DrawImage(img, (float)ctmX, (float)ctmY, (float)ctmWidth, (float)ctmHeight);
                            }
                            if (clearImage)
                            {
                                img.Dispose();
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                    }
                    finally
                    {
                        graphics.Dispose();
                    }
                }
                if (rotation == 90)
                {
                    bmp.RotateFlip(RotateFlipType.Rotate90FlipNone);
                }
                else if (rotation == 270)
                {
                    bmp.RotateFlip(RotateFlipType.Rotate270FlipNone);
                }
                //bmp.Save(@"bmp.png");
                return bmp;
            }
            return null;
        }


        public static Bitmap MergeImages(this IEnumerable<PDFImageCtm> ctms, int width, int height, int rotation, double pageHeight)
        {
            if (ctms != null && ctms.Count() > 0 && width > 0 && height > 0)
            {
                Bitmap bmp = new Bitmap(width, height, DefaultPixelFormat);
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    try
                    {
                        graphics.Clear(Color.White);
                        foreach (var ctm in ctms)
                        {
                            double ynew = 0;
                            if (rotation == 90 || rotation == 270)
                            {
                                ynew = ctm.AdjustedY;
                            }
                            else
                            {
                                if (ctm.AdjustedY == 0)
                                {
                                    ynew = 0;
                                }
                                else
                                {
                                    ynew = ((pageHeight * ctm.YFactor) - ctm.AdjustedY) / ctm.YFactor;
                                    ynew = ((pageHeight * ctm.YFactor) - ctm.AdjustedY);
                                }
                            }
                            if (ynew < 0)
                            {
                                ynew = 0;
                            }
                            var img = ctm.Image;
                            if (ctm.SkewX != 0 || ctm.SkewY != 0)
                            {
                                // skew TODO
                                
                                //double angleX = Math.Atan(ctm.SkewX) * 180 / Math.PI;
                                //double angleY = Math.Atan(ctm.SkewX) * 180 / Math.PI;
                                //graphics.DrawImage(img, SkewRectangle(ctm.AdjustedX, ynew, ctm.ActualWidth, ctm.ActualHeight, angleX, angleY));
                                graphics.DrawImage(img, (float)ctm.AdjustedX, (float)ynew, (float)ctm.ActualWidth, (float)ctm.ActualHeight);

                            }
                            else
                            {
                                graphics.DrawImage(img, (float)ctm.AdjustedX, (float)ynew, (float)ctm.ActualWidth, (float)ctm.ActualHeight);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                    }
                    finally
                    {
                        graphics.Dispose();
                    }
                }
                return bmp;
            }
            return null;
        }

        public static Point ToDrawingPoint(this System.Windows.Point point)
        {
            return new Point((int)point.X, (int)point.Y);
        }

        public static Point[] SkewRectangle(double left, double top, double width, double height, double angleX, double angleY)
        {
            Point[] points = new Point[3];
            var st = new System.Windows.Media.SkewTransform(angleX, angleY);
            points[0] = st.Transform(new System.Windows.Point(left, top)).ToDrawingPoint();
            points[1] = st.Transform(new System.Windows.Point(left + width, top)).ToDrawingPoint();
            points[2] = st.Transform(new System.Windows.Point(left, top + height)).ToDrawingPoint();
            return points;
        }

        public static Image SkewImage(Image image, double left, double top, double width, double height, double angleX, double angleY)
        {
            Image img = image;
            Point[] skewPoints = SkewRectangle(left, top, width, height, angleX, angleY);
            int bmpWidth = (int)width;
            int bmpHeight = (int)height;
            for (int i = 0; i < skewPoints.Length; i++)
            {
                if (skewPoints[i].X > bmpWidth)
                {
                    bmpWidth = skewPoints[i].X;
                }
                if (skewPoints[i].Y > bmpHeight)
                {
                    bmpHeight = skewPoints[i].Y;
                }
            }
            Bitmap bmp = new Bitmap(bmpWidth, bmpHeight, DefaultPixelFormat);
            bmp.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                try
                {
                    graphics.Clear(Color.Transparent);
                    graphics.DrawImage(image, skewPoints);
                }
                catch (Exception e)
                {
                    e.LogException();
                }
                finally
                {
                    graphics.Dispose();
                }
                img = bmp;
            }
            return img;
        }

        public static Bitmap RotateAndReSize(Bitmap image, float angle, float width, float height)
        {
            Bitmap bmp = new Bitmap((int)width, (int)height, DefaultPixelFormat);
            //bmp.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                try
                {
                    graphics.FillRectangle(Brushes.White, 0, 0, width, height);
                    if (angle != 0)
                    {
                        graphics.RotateTransform(angle);
                    }
                    graphics.DrawImage(image, 0, 0, width, height);
                }
                catch (Exception e)
                {
                    e.LogException();
                    bmp = image;
                }
                finally
                {
                    graphics.Dispose();
                }
            }
            return bmp;
        }

        public static Bitmap ImageFromPBM(byte[] pixels, int width, int height)
        {
            //Remember that pixels is simply a string of "0"s and 
            //"1"s. Width and Height are integers.


            //Create our bitmap
            Bitmap bitmap = new Bitmap(width, height);
            int x = 0;
            int y = 0;
            //Current X,Y co-ordinates of the Bitmap object

            //Loop through all of the bits
            for (int i = 0; i < pixels.Length; i++)
            {
                //Below, we're comparing the value with "0". 
                //If it is a zero, then we change the pixel white, 
                //else make it black.

                for (int j = 0; j < 8; j++)
                {
                    var bit = (pixels[i] & (1 << j)) != 0;
                    if (bit && x < width)
                    {
                        bitmap.SetPixel(x, y, Color.Black);
                    }
                    x += 1;//Move along the right
                }


                //If we're passed the right boundry, 
                //reset the X and move the Y to the next line

                if (x >= width)
                {
                    x = 0;//reset
                    y += 1;//Add another row
                    if (y >= height)
                    {
                        break;
                    }
                }

            }
            return bitmap;
        }


        public static System.Windows.Media.Imaging.BitmapImage BMPFromPBM(byte[] pixels, int width, int height)
        {
            //Remember that pixels is simply a string of "0"s and 
            //"1"s. Width and Height are integers.

            int Width = width;
            int Height = height;

            //Create our bitmap
            using (Bitmap B = new Bitmap(Width, Height))
            {
                int X = 0;
                int Y = 0;
                //Current X,Y co-ordinates of the Bitmap object

                //Loop through all of the bits
                for (int i = 0; i < pixels.Length; i++)
                {
                    //Below, we're comparing the value with "0". 
                    //If it is a zero, then we change the pixel white, 
                    //else make it black.

                    B.SetPixel(X, Y, pixels[i] == '0' ?
                         System.Drawing.Color.White :
                         System.Drawing.Color.Red);

                    //Increment our X position

                    X += 1;//Move along the right

                    //If we're passed the right boundry, 
                    //reset the X and move the Y to the next line

                    if (X >= Width)
                    {
                        X = 0;//reset
                        Y += 1;//Add another row
                    }
                }

                System.IO.MemoryStream ms = new System.IO.MemoryStream();
                B.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                ms.Position = 0;
                System.Windows.Media.Imaging.BitmapImage bi =
                   new System.Windows.Media.Imaging.BitmapImage();
                bi.BeginInit();
                bi.StreamSource = ms;
                bi.EndInit();

                return bi;
            }
        }

        public static System.Windows.Media.ImageSource CanvasToImage(this System.Windows.Controls.Canvas canvas)
        {
            if (canvas == null)
            {
                return null;
            }
            System.Windows.Rect box = new System.Windows.Rect(canvas.DesiredSize);
            if (box.Width == 0 || box.Height == 0)
            {
                return null;
            }
            System.Windows.Media.Imaging.RenderTargetBitmap targetBitmap = new System.Windows.Media.Imaging.RenderTargetBitmap((int)box.Right, (int)box.Bottom, 96d, 96d, System.Windows.Media.PixelFormats.Default);
            targetBitmap.Render(canvas);
            System.Windows.Media.Imaging.BitmapEncoder pngEncoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
            pngEncoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(targetBitmap));

            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            pngEncoder.Save(ms);
            ms.Close();
            System.IO.File.WriteAllBytes(@"c:\canvas.png", ms.ToArray());
            return targetBitmap;
        }

        public static System.Windows.Media.ImageSource ToWPFImageSource(this Bitmap bitmap)
        {
            if (bitmap != null)
            {
                int width = bitmap.Width;
                int height = bitmap.Height;

                bitmap.SetResolution(96, 96);
                System.Windows.Media.Imaging.BitmapImage bmp = new System.Windows.Media.Imaging.BitmapImage();

                MemoryStream ms = new MemoryStream();
                bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                ms.Seek(0, SeekOrigin.Begin);

                bmp.BeginInit();
                bmp.DecodePixelWidth = width;
                bmp.DecodePixelHeight = height;
                bmp.StreamSource = ms;
                bmp.EndInit();

                return bmp;
            }
            return null;
        }


        public static System.Windows.Media.ImageSource ToWPFImageSource(this System.Drawing.Image image, bool unskew, int imageColor)
        {
            if (image != null)
            {
                int width = image.Width;
                int height = image.Height;

                var bitmap = new System.Drawing.Bitmap(image);
                //bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
                bitmap.SetResolution(96, 96);
                image = ResizeAndDeSkewImage(bitmap, unskew, imageColor, width, height);

                MemoryStream ms = new MemoryStream();
                image.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                ms.Seek(0, SeekOrigin.Begin);

                System.Windows.Media.Imaging.BitmapImage bmp = new System.Windows.Media.Imaging.BitmapImage();
                bmp.BeginInit();
                bmp.DecodePixelWidth = width;
                bmp.DecodePixelHeight = height;
                bmp.StreamSource = ms;
                bmp.EndInit();

                return bmp;
            }
            return null;
        }

        public static void SaveAsPng(this System.Windows.Media.ImageSource imageSource, string filePath)
        {
            System.Windows.Controls.Image fileImage = new System.Windows.Controls.Image();
            fileImage.Source = imageSource;
            fileImage.Arrange(new System.Windows.Rect(0, 0, imageSource.Width, imageSource.Height));

            if (imageSource.Width > 0 && imageSource.Height > 0)
            {
                System.Windows.Media.Imaging.RenderTargetBitmap bmp = new System.Windows.Media.Imaging.RenderTargetBitmap((int)imageSource.Width, (int)imageSource.Height, 96d, 96d, System.Windows.Media.PixelFormats.Default);
                bmp.Render(fileImage);

                System.Windows.Media.Imaging.PngBitmapEncoder pngEncoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                pngEncoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bmp));
                using (Stream stm = File.Create(filePath))
                {
                    pngEncoder.Save(stm);
                }
            }
        }

        public static System.Windows.Media.Imaging.BitmapImage ToBitmapImage(this System.Windows.Media.ImageSource imageSource, double scaleX, double scaleY)
        {
            System.Windows.Controls.Image fileImage = new System.Windows.Controls.Image();
            fileImage.Source = imageSource;
            fileImage.Arrange(new System.Windows.Rect(0, 0, imageSource.Width, imageSource.Height));
            if (imageSource.Width > 0 && imageSource.Height > 0)
            {
                var dpiX = (double)imageSource.Width / scaleX * 100;
                var dpiY = (double)imageSource.Height / scaleY * 100;
                dpiX = 96;
                dpiY = 96;
                var bmp = new System.Windows.Media.Imaging.RenderTargetBitmap((int)imageSource.Width, (int)imageSource.Height, dpiX, dpiY, System.Windows.Media.PixelFormats.Default);
                bmp.Render(fileImage);

                var bmpEncoder = new System.Windows.Media.Imaging.BmpBitmapEncoder();
                bmpEncoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bmp));
                MemoryStream ms = new MemoryStream();
                bmpEncoder.Save(ms);
                ms.Seek(0, SeekOrigin.Begin);

                var bmpImage = new System.Windows.Media.Imaging.BitmapImage();
                bmpImage.BeginInit();
                //bmpImage.DecodePixelWidth = (int)imageSource.Width;
                //bmpImage.DecodePixelHeight = (int)imageSource.Height;
                bmpImage.StreamSource = ms;
                bmpImage.EndInit();


                return bmpImage;
            }

            return null;
        }

        public static Bitmap Grayscale(Bitmap bitmap)
        {
            int width = bitmap.Width;
            int height = bitmap.Height;
            Bitmap grayscaleImage = new Bitmap(width, height);
            grayscaleImage.SetResolution(bitmap.HorizontalResolution, bitmap.VerticalResolution);
            using (Graphics graphics = Graphics.FromImage(grayscaleImage))
            {
                try
                {
                    ColorMatrix colorMatrix = new ColorMatrix(
                        new float[][]
                        {
                            new float[] {.3f, .3f, .3f, 0, 0},
                            new float[] {.59f, .59f, .59f, 0, 0},
                            new float[] {.11f, .11f, .11f, 0, 0},
                            new float[] {0, 0, 0, 1, 0},
                            new float[] {0, 0, 0, 0, 1}
                        }
                    );

                    ImageAttributes imageAttributes = new ImageAttributes();
                    imageAttributes.SetColorMatrix(colorMatrix);
                    graphics.DrawImage(bitmap, new Rectangle(0, 0, width, height), 0, 0, width, height, GraphicsUnit.Pixel, imageAttributes);
                }
                catch
                {
                }
            }
            return grayscaleImage;
        }

        public static Bitmap ApplyEnhancements(Bitmap bitmap, ImageOptions options)
        {
            if (options == null || !options.HasValue)
            {
                return bitmap;
            }
            int value;
            var worker = new BitmapWorker(bitmap);

            if (options.SmoothEdges == true)
            {
                worker.SmoothEdges(true, true);
                worker.Apply();
            }

            if (options.HMax.ContainsValueInt(out value))
            {
                worker.RemoveStraightLines(value, false);
            }
            if (options.VMax.ContainsValueInt(out value))
            {
                worker.RemoveStraightLines(value, true);
            }
            int sw = 0;
            int sh = 0;
            int ww = 0;
            int wh = 0;
            if (
                options.SpeckleWidth.ContainsValueInt(out sw) &&
                options.SpeckleHeight.ContainsValueInt(out sh) &&
                options.WhitespaceWidth.ContainsValueInt(out ww) &&
                options.WhitespaceHeight.ContainsValueInt(out wh)
               )
            {
                worker.RemoveSpeckles(sw, sh, ww, sh);
            }
            return worker.Apply();
        }


        public static Bitmap BlackAndWhite(Bitmap original)
        {
            Bitmap source = null;
            int skip = DefaultPixelFormatByteLength;

            // If original bitmap is not already in 32 BPP, ARGB format, then convert
            if (original.PixelFormat != DefaultPixelFormat)
            {
                var odepth = Image.GetPixelFormatSize(original.PixelFormat);
                var ddepth = Image.GetPixelFormatSize(DefaultPixelFormat);
                if (odepth > ddepth)
                {
                    source = original;
                }
                else
                {
                    source = new Bitmap(original.Width, original.Height, DefaultPixelFormat);
                    source.SetResolution(original.HorizontalResolution, original.VerticalResolution);
                    using (Graphics g = Graphics.FromImage(source))
                    {
                        g.DrawImageUnscaled(original, 0, 0);
                    }
                }
            }
            else
            {
                source = original;
            }

            // Lock source bitmap in memory
            BitmapData sourceData = source.LockBits(new Rectangle(0, 0, source.Width, source.Height), ImageLockMode.ReadOnly, DefaultPixelFormat);

            // Copy image data to binary array
            int imageSize = sourceData.Stride * sourceData.Height;
            byte[] sourceBuffer = new byte[imageSize];
            Marshal.Copy(sourceData.Scan0, sourceBuffer, 0, imageSize);

            // Unlock source bitmap
            source.UnlockBits(sourceData);

            // Create destination bitmap
            Bitmap destination = new Bitmap(source.Width, source.Height, PixelFormat.Format1bppIndexed);
            destination.SetResolution(original.HorizontalResolution, original.VerticalResolution);

            // Lock destination bitmap in memory
            BitmapData destinationData = destination.LockBits(new Rectangle(0, 0, destination.Width, destination.Height), ImageLockMode.WriteOnly, PixelFormat.Format1bppIndexed);

            // Create destination buffer
            imageSize = destinationData.Stride * destinationData.Height;
            byte[] destinationBuffer = new byte[imageSize];

            int sourceIndex = 0;
            int destinationIndex = 0;
            int pixelTotal = 0;
            byte destinationValue = 0;
            int pixelValue = 128;
            int height = source.Height;
            int width = source.Width;
            int threshold = 500;

            // Iterate lines
            for (int y = 0; y < height; y++)
            {
                sourceIndex = y * sourceData.Stride;
                destinationIndex = y * destinationData.Stride;
                destinationValue = 0;
                pixelValue = 128;

                // Iterate pixels
                for (int x = 0; x < width; x++)
                {
                    // Compute pixel brightness (i.e. total of Red, Green, and Blue values) - Thanks murx
                    //                           B                             G                              R
                    pixelTotal = sourceBuffer[sourceIndex] + sourceBuffer[sourceIndex + 1] + sourceBuffer[sourceIndex + 2];
                    if (pixelTotal > threshold)
                    {
                        destinationValue += (byte)pixelValue;
                    }
                    if (pixelValue == 1)
                    {
                        destinationBuffer[destinationIndex] = destinationValue;
                        destinationIndex++;
                        destinationValue = 0;
                        pixelValue = 128;
                    }
                    else
                    {
                        pixelValue >>= 1;
                    }
                    //sourceIndex += 4;
                    //sourceIndex += 3;
                    sourceIndex += skip; // bytes per pixel for current image format
                }
                if (pixelValue != 128)
                {
                    destinationBuffer[destinationIndex] = destinationValue;
                }
            }

            // Copy binary image data to destination bitmap
            Marshal.Copy(destinationBuffer, 0, destinationData.Scan0, imageSize);

            // Unlock destination bitmap
            destination.UnlockBits(destinationData);

            // Dispose of source if not originally supplied bitmap
            if (source != original)
            {
                source.Dispose();
            }

            // Return
            return destination;
        }

        public static Bitmap RGBImage(Image original)
        {
            Bitmap newImage = new Bitmap(original.Width, original.Height, DefaultPixelFormat);
            newImage.SetResolution(original.HorizontalResolution, original.VerticalResolution);
            using (Graphics g = Graphics.FromImage(newImage))
            {
                g.DrawImageUnscaled(original, 0, 0);
            }
            return newImage;
        }

        public static Bitmap CaptureScreenSection(int left, int top, int width, int height)
        {
            Bitmap bmp = new Bitmap(width, height);
            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                try
                {
                    graphics.CopyFromScreen(left, top, 0, 0, new Size(width, height));
                }
                catch
                {
                }
            }
            return bmp;
        }

        public static Bitmap ApplyImageAction(Bitmap image, params ImageAction[] actions)
        {
            if (actions == null || actions.Length == 0)
            {
                return image;
            }
            var bmp = new Bitmap(image.Width, image.Height, DefaultPixelFormat);
            bmp.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                try
                {
                    graphics.Clear(Color.White);
                    graphics.DrawImageUnscaled(image, 0, 0);
                    Bitmap croppedImage = null;
                    Bitmap deskewedImage = null;
                    foreach (var action in actions)
                    {
                        croppedImage = null;
                        deskewedImage = null;
                        if (action != null && action.Width > 0 && action.Height > 0 && !action.Skip)
                        {
                            if (image.Width < (action.Left + action.Width) || image.Height < (action.Top + action.Height))
                            {
                                continue;
                            }
                            if (action.Operation == ImageOperation.Deskew || action.Operation == ImageOperation.Rotate)
                            {
                                croppedImage = image.CropImage((int)action.Left, (int)action.Top, (int)action.Width, (int)action.Height);
                                if (action.Operation == ImageOperation.Deskew)
                                {
                                    double skewAngle = 0;
                                    deskewedImage = DeSkewImage(croppedImage, out skewAngle, true, true);
                                    action.Rotation = (float)skewAngle;
                                }
                                else
                                {
                                    deskewedImage = RotateImageSansClipping(croppedImage, action.Rotation);
                                }
                                if (croppedImage != deskewedImage)
                                {
                                    croppedImage.Dispose();
                                    GC.Collect();
                                }
                                deskewedImage.MakeTransparent();
                            }
                            graphics.FillRectangle(new SolidBrush(Color.White), (float)action.Left, (float)action.Top, (float)action.Width, (float)action.Height);
                            if (deskewedImage != null)
                            {
                                graphics.DrawImage(deskewedImage, (int)action.Left, (int)action.Top);
                                deskewedImage.Dispose();
                                GC.Collect();
                            }
                        }
                    }

                }
                catch(Exception e)
                {
                    e.LogException();
                    bmp = image;
                }
                finally
                {
                    graphics.Dispose();
                }
            }
            if (image.PixelFormat == PixelFormat.Format1bppIndexed)
            {
                var tmp = BlackAndWhite(bmp);
                if (tmp != bmp)
                {
                    bmp.Dispose();
                    GC.Collect();
                }
                bmp = tmp;
            }
            return bmp;
        }

        public static Bitmap WhiteBackground(double width, double height)
        {
            var bmp = new Bitmap((int)width, (int)height, DefaultPixelFormat);
            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                try
                {
                    graphics.Clear(Color.White);
                }
                catch (Exception e)
                {
                    e.LogException();
                }
                finally
                {
                    graphics.Dispose();
                }
            }
            return bmp;
        }

        public static Bitmap BuildTextImage(double width, double height, string colorName, IEnumerable<DrawingPath> paths, IEnumerable<PDFTextRect> textCollection, Bitmap backgroundImage)
        {
            int bmpWidth = (int)width;
            int bmpHeight = (int)height;
            if (backgroundImage != null)
            {
                if (backgroundImage.Width > bmpWidth)
                {
                    bmpWidth = backgroundImage.Width;
                }
                if (backgroundImage.Height > bmpHeight)
                {
                    bmpHeight = backgroundImage.Height;
                }
            }
            var bmp = new Bitmap(bmpWidth, bmpHeight, DefaultPixelFormat);
            if (textCollection != null || textCollection.Count() > 0)
            {
                var color = Color.Black;
                var useDefaultColor = string.IsNullOrWhiteSpace(colorName);
                if (!useDefaultColor)
                {
                    color = Color.FromName(colorName);
                }
                var brush = new SolidBrush(color);
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    try
                    {
                        graphics.Clear(Color.White);
                        graphics.InterpolationMode = InterpolationMode.High;
                        graphics.SmoothingMode = SmoothingMode.HighQuality;
                        graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                        graphics.CompositingQuality = CompositingQuality.HighQuality;
                        graphics.TextContrast = 0;
                        if (backgroundImage != null)
                        {
                            graphics.DrawImage(backgroundImage, new Point(0, 0));
                        }
                        if (paths != null)
                        {
                            foreach (var path in paths)
                            {
                                if (path != null)
                                {
                                    if (path.IsFill)
                                    {
                                        graphics.FillPath(path.FillBrush, path.Path);
                                    }
                                    if(path.IsStroke)
                                    {
                                        graphics.DrawPath(path.Pen, path.Path);
                                    }
                                }
                            }
                        }
                        foreach (var text in textCollection)
                        {
                            if (text != null)
                            {
                                Brush textBrush = brush;
                                if (useDefaultColor && text.Stroke != null)
                                {
                                    textBrush = new SolidBrush(text.Stroke);
                                }
                                var bold = text.IsBold ? FontStyle.Bold : FontStyle.Regular;
                                var font = new Font(text.FontFamily, (float)text.FontSize , bold, GraphicsUnit.Pixel);
                                var top = text.Top;
                                if (text.ActualTop > 0)
                                {
                                    top = text.ActualTop;
                                }
                                if (text.TextRotation > 0)
                                {
                                    var size = graphics.MeasureString(text.Text, font);
                                    var img = text.TextImage(textBrush, size.Width, size.Height);
                                    if (img != null)
                                    {
                                        if (text.TextRotation == 90)
                                        {
                                            img.RotateFlip(RotateFlipType.Rotate90FlipNone);
                                        }
                                        else if (text.TextRotation == 180)
                                        {
                                            img.RotateFlip(RotateFlipType.Rotate180FlipNone);
                                        }
                                        else if (text.TextRotation == 270)
                                        {
                                            img.RotateFlip(RotateFlipType.Rotate270FlipNone);
                                        }
                                        graphics.DrawImage(img, (float)text.Left, (float)text.Top);
                                        img.Dispose();
                                        GC.Collect();
                                    }
                                }
                                else
                                {
                                    if (useDefaultColor)
                                    {
                                        DrawStringUsingGraphicsPath(graphics, text, (float)text.Left, (float)text.Top, text.TextMode, font);
                                    }
                                    else if (text.TextMode != TextRenderingMode.NoFillNoStroke)
                                    {
                                        graphics.DrawString(text.Text, font, textBrush, (float)text.Left, (float)text.Top);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                    }
                    finally
                    {
                        graphics.Dispose();
                    }
                }
            }
            return bmp;
        }

        public static void DrawStringUsingGraphicsPath(Graphics graphics, PDFTextRect textRect, float left, float top, TextRenderingMode textMode, Font font)
        {
            if (textMode == TextRenderingMode.FillThenStroke)
            {
                var strFormat = new StringFormat();
                strFormat.Alignment = StringAlignment.Center;
                strFormat.LineAlignment = StringAlignment.Center;
                var path = new GraphicsPath();
                path.AddString(textRect.Text, new FontFamily(textRect.FontFamily), 0, (float)textRect.FontSize, new PointF(left, top), strFormat);
                if (textMode == TextRenderingMode.Fill || textMode == TextRenderingMode.FillAndClip || textMode == TextRenderingMode.FillThenStroke)
                {
                    graphics.FillPath(new SolidBrush(textRect.Fill), path);
                }
                if (textMode == TextRenderingMode.FillThenStroke || textMode == TextRenderingMode.Stroke || textMode == TextRenderingMode.StrokeAndClip)
                {
                    graphics.DrawPath(new Pen(textRect.Stroke, 0.1f), path);
                }
            }
            else
            {
                Brush brush = null;
                if (textMode == TextRenderingMode.Fill || textMode == TextRenderingMode.FillAndClip)
                {
                    brush = new SolidBrush(textRect.Fill);
                }
                else if (textMode == TextRenderingMode.Stroke || textMode == TextRenderingMode.StrokeAndClip)
                {
                    brush = new SolidBrush(textRect.Stroke);
                }
                if (brush != null)
                {
                    graphics.DrawString(textRect.Text, font, brush, left, top);
                }
            }
        }

        public static Bitmap MergeBitmaps(params Bitmap[] bitmaps)
        {
            if (bitmaps != null)
            {
                var width = 0;
                var height = 0;
                foreach (var bmp in bitmaps)
                {
                    if (bmp != null)
                    {
                        if (bmp.Width > width)
                        {
                            width = bmp.Width;
                        }
                        if (bmp.Height > height)
                        {
                            height = bmp.Height;
                        }
                    }
                }
                if (width > 0 && height > 0)
                {
                    var image = new Bitmap(width, height);
                    using (Graphics graphics = Graphics.FromImage(image))
                    {
                        try
                        {
                            graphics.Clear(Color.White);
                            foreach (var bmp in bitmaps)
                            {
                                if (bmp != null)
                                {
                                    graphics.DrawImage(bmp, new Point(0, 0));
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            e.LogException();
                        }
                        finally
                        {
                            graphics.Dispose();
                        }
                    }
                    return image;
                }
            }
            return null;
        }



        //===========================

        #region CropUnwantedBackground
        public static Bitmap CropUnwantedBackground(Bitmap bmp)
        {
            var backColor = GetMatchedBackColor(bmp);
            if (backColor.HasValue)
            {
                var bounds = GetImageBounds(bmp, backColor);
                var diffX = bounds[1].X - bounds[0].X + 1;
                var diffY = bounds[1].Y - bounds[0].Y + 1;
                var croppedBmp = new Bitmap(diffX, diffY);
                var g = Graphics.FromImage(croppedBmp);
                var destRect = new Rectangle(0, 0, croppedBmp.Width, croppedBmp.Height);
                var srcRect = new Rectangle(bounds[0].X, bounds[0].Y, diffX, diffY);
                g.DrawImage(bmp, destRect, srcRect, GraphicsUnit.Pixel);
                return croppedBmp;
            }
            else
            {
                return null;
            }
        }
        #endregion
        #region Private Methods

        #region GetImageBounds
        private static Point[] GetImageBounds(Bitmap bmp, Color? backColor)
        {
            //--------------------------------------------------------------------
            // Finding the Bounds of Crop Area bu using Unsafe Code and Image Proccesing
            Color c;
            int width = bmp.Width, height = bmp.Height;
            bool upperLeftPointFounded = false;
            var bounds = new Point[2];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    c = bmp.GetPixel(x, y);
                    bool sameAsBackColor = ((c.R <= backColor.Value.R * 1.1 && c.R >= backColor.Value.R * 0.9) &&
                                            (c.G <= backColor.Value.G * 1.1 && c.G >= backColor.Value.G * 0.9) &&
                                            (c.B <= backColor.Value.B * 1.1 && c.B >= backColor.Value.B * 0.9));
                    if (!sameAsBackColor)
                    {
                        if (!upperLeftPointFounded)
                        {
                            bounds[0] = new Point(x, y);
                            bounds[1] = new Point(x, y);
                            upperLeftPointFounded = true;
                        }
                        else
                        {
                            if (x > bounds[1].X)
                                bounds[1].X = x;
                            else if (x < bounds[0].X)
                                bounds[0].X = x;
                            if (y >= bounds[1].Y)
                                bounds[1].Y = y;
                        }
                    }
                }
            }
            return bounds;
        }
        #endregion

        #region GetMatchedBackColor
        private static Color? GetMatchedBackColor(Bitmap bmp)
        {
            // Getting The Background Color by checking Corners of Original Image
            var corners = new Point[]{
            new Point(0, 0),
            new Point(0, bmp.Height - 1),
            new Point(bmp.Width - 1, 0),
            new Point(bmp.Width - 1, bmp.Height - 1)
        }; // four corners (Top, Left), (Top, Right), (Bottom, Left), (Bottom, Right)
            for (int i = 0; i < 4; i++)
            {
                var cornerMatched = 0;
                var backColor = bmp.GetPixel(corners[i].X, corners[i].Y);
                for (int j = 0; j < 4; j++)
                {
                    var cornerColor = bmp.GetPixel(corners[j].X, corners[j].Y);// Check RGB with some offset
                    if ((cornerColor.R <= backColor.R * 1.1 && cornerColor.R >= backColor.R * 0.9) &&
                        (cornerColor.G <= backColor.G * 1.1 && cornerColor.G >= backColor.G * 0.9) &&
                        (cornerColor.B <= backColor.B * 1.1 && cornerColor.B >= backColor.B * 0.9))
                    {
                        cornerMatched++;
                    }
                }
                if (cornerMatched > 2)
                {
                    return backColor;
                }
            }
            return null;
        }
        #endregion

        #endregion
        //===========================
    }
}
