﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace DataCapture
{
    public class PDFUtils
    {
        public static void ParsePage(PdfReader reader, int pageNo)
        {
            for (int i = 0; i < reader.XrefSize; i++)
            {
                var obj = reader.GetPdfObject(i);
                if (obj != null && obj.IsStream())
                {
                    PRStream stream = (PRStream)obj;

                    byte[] bytes = PdfReader.GetStreamBytesRaw(stream);

                    try
                    {
                        iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(bytes);
                        File.WriteAllBytes(@"c:\testimage0.png", bytes);
                        File.WriteAllBytes(@"c:\testimage1.png", img.OriginalData);
                        File.WriteAllBytes(@"c:\testimage2.png", img.RawData);
                        PdfImageObject image = new PdfImageObject(stream);
                        if (image != null)
                        {
                            bytes = image.GetImageAsBytes();
                            File.WriteAllBytes(@"c:\image.png", bytes);
                        }
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                    }

                }
            }
            byte[] data = reader.GetPageContent(pageNo);
            PRTokeniser tokeniser = new PRTokeniser(new RandomAccessFileOrArray(data));
            while (tokeniser.NextToken())
            {
                if (tokeniser.TokenType == PRTokeniser.TokType.STRING)
                {
                }
            }
        }

        public static void ExtractImagesFromPDF(string sourcePdf, string outputPath)
        {
            PdfReader pdf = new PdfReader(sourcePdf);

            try
            {
                for (int pageNumber = 1; pageNumber <= pdf.NumberOfPages; pageNumber++)
                {
                    PdfDictionary pg = pdf.GetPageN(pageNumber);

                    var pageImages = new List<byte[]>();

                    getAllImages(pg, pageImages, pdf);

                    if ((pageImages != null))
                    {
                        int imgNum = 1;
                        foreach (byte[] bytes in pageImages)
                        {

                            if (!System.IO.Directory.Exists(outputPath))
                                System.IO.Directory.CreateDirectory(outputPath);

                            string path = System.IO.Path.Combine(outputPath, String.Format(@"Page_{0}_Image_{1}.png", pageNumber, imgNum));

                            File.WriteAllBytes(path, bytes);
                            using (System.IO.MemoryStream memStream = new System.IO.MemoryStream(bytes))
                            {
                                // must save the file while stream is open. 

                                memStream.Position = 0;
                                System.Drawing.Image img = System.Drawing.Image.FromStream(memStream);

                                System.Drawing.Imaging.EncoderParameters parms = new System.Drawing.Imaging.EncoderParameters(1);
                                parms.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Compression, 0);
                                // GetImageEncoder is found below this method 
                                System.Drawing.Imaging.ImageCodecInfo jpegEncoder = GetImageEncoder("PNG");
                                img.Save(path, jpegEncoder, parms);
                            }
                            imgNum++;
                        }
                    }
                }
            }
            catch
            {
                //throw;
            }
            finally
            {
                pdf.Close();
            }
        }

        public static System.Drawing.Imaging.ImageCodecInfo GetImageEncoder(string imageType)
        {
            imageType = imageType.ToUpperInvariant();

            foreach (ImageCodecInfo info in ImageCodecInfo.GetImageEncoders())
            {
                if (info.FormatDescription == imageType)
                {
                    return info;
                }
            }
            return null;
        }

        private static void getAllImages(PdfDictionary dict, List<byte[]> images, PdfReader doc)
        {
            PdfDictionary res = (PdfDictionary)PdfReader.GetPdfObject(dict.Get(PdfName.RESOURCES));
            PdfDictionary xobj = (PdfDictionary)PdfReader.GetPdfObject(res.Get(PdfName.XOBJECT));

            if (xobj != null)
            {
                foreach (PdfName name in xobj.Keys)
                {
                    PdfObject obj = xobj.Get(name);
                    if ((obj.IsIndirect()))
                    {
                        PdfDictionary tg = (PdfDictionary)PdfReader.GetPdfObject(obj);
                        var oob = tg.Get(PdfName.COLORSPACE);
                        PdfName subtype = (PdfName)PdfReader.GetPdfObject(tg.Get(PdfName.SUBTYPE));
                        if (PdfName.IMAGE.Equals(subtype))
                        {
                            int xrefIdx = ((PRIndirectReference)obj).Number;
                            PdfObject pdfObj = doc.GetPdfObject(xrefIdx);
                            PdfStream str = (PdfStream)pdfObj;
                            byte[] bytes = PdfReader.GetStreamBytesRaw((PRStream)str);
                            PdfImageObject pio = new PdfImageObject((PRStream)str);
                            if (pio != null)
                            {
                                bytes = pio.GetImageAsBytes();
                            }

                            string filter = tg.Get(PdfName.FILTER).ToString();
                            string width = tg.Get(PdfName.WIDTH).ToString();
                            string height = tg.Get(PdfName.HEIGHT).ToString();
                            string bpp = tg.Get(PdfName.BITSPERCOMPONENT).ToString();

                            if (filter == "/FlateDecode")
                            {
                                bytes = PdfReader.FlateDecode(bytes, true);
                                System.Drawing.Imaging.PixelFormat pixelFormat = default(System.Drawing.Imaging.PixelFormat);
                                switch (int.Parse(bpp))
                                {
                                    case 1:
                                        pixelFormat = System.Drawing.Imaging.PixelFormat.Format1bppIndexed;
                                        break;
                                    case 8:
                                        pixelFormat = System.Drawing.Imaging.PixelFormat.Format8bppIndexed;
                                        break;
                                    case 16:
                                        pixelFormat = System.Drawing.Imaging.PixelFormat.Format16bppArgb1555;
                                        break;
                                    case 24:
                                        pixelFormat = System.Drawing.Imaging.PixelFormat.Format24bppRgb;
                                        break;
                                    case 48:
                                        pixelFormat = System.Drawing.Imaging.PixelFormat.Format48bppRgb;
                                        break;
                                    default:
                                        throw new Exception("Unknown pixel format " + bpp);
                                }
                                System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(Int32.Parse(width), Int32.Parse(height), pixelFormat);
                                System.Drawing.Imaging.BitmapData bmd = bmp.LockBits(new System.Drawing.Rectangle(0, 0, Int32.Parse(width), Int32.Parse(height)), System.Drawing.Imaging.ImageLockMode.WriteOnly, pixelFormat);
                                System.Runtime.InteropServices.Marshal.Copy(bytes, 0, bmd.Scan0, bytes.Length);
                                bmp.UnlockBits(bmd);
                                using (var ms = new System.IO.MemoryStream())
                                {
                                    bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                                    bytes = ms.GetBuffer();
                                }
                            }
                            images.Add(bytes);
                        }
                        else if (PdfName.FORM.Equals(subtype) | PdfName.GROUP.Equals(subtype))
                        {
                            getAllImages(tg, images, doc);
                        }
                    }
                }
            }
        }

        public static void SaveBmp(PdfImageObject imgObj, byte[] streamBytes, string fileName)
        {
            //int w = imgObj.GetAsNumber(PdfName.WIDTH).IntValue;
            //int h = imgObj.GetAsNumber(PdfName.HEIGHT).IntValue;
            //int bpp = imgObj.GetAsNumber(PdfName.BITSPERCOMPONENT).IntValue;
            int w = ((PdfNumber)imgObj.Get(PdfName.WIDTH)).IntValue;
            int h = ((PdfNumber)imgObj.Get(PdfName.HEIGHT)).IntValue;
            int bpp = ((PdfNumber)imgObj.Get(PdfName.BITSPERCOMPONENT)).IntValue;
            var stream =imgObj.Get(PdfName.DATA);
            var pixelFormat = PixelFormat.Format1bppIndexed;

            //byte[] rawBytes = PdfReader.GetStreamBytesRaw((PRStream)imgObj);
            //byte[] decodedBytes = PdfReader.FlateDecode(rawBytes);
            //byte[] streamBytes = PdfReader.DecodePredictor(decodedBytes, imgObj.GetAsDict(PdfName.DECODEPARMS));
            //byte[] streamBytes = PdfReader.GetStreamBytes((PRStream)imgObj); // same result as above 3 lines of code.
            /*
            byte[] streamBytes = null;
            using (MemoryStream ms = new MemoryStream())
            {
                imgObj.GetDrawingImage().Save(ms, ImageFormat.Bmp);
                streamBytes = ms.ToArray();
            }
            */
            using (System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(w, h, pixelFormat))
            {
                var bmpData = bmp.LockBits(new System.Drawing.Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, pixelFormat);
                int length = (int)Math.Ceiling(w * bpp / 8.0);
                for (int i = 0; i < h; i++)
                {
                    int offset = i * length;
                    int scanOffset = i * bmpData.Stride;
                    try
                    {
                        System.Runtime.InteropServices.Marshal.Copy(streamBytes, offset, new IntPtr(bmpData.Scan0.ToInt32() + scanOffset), length);
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                    }
                }
                bmp.UnlockBits(bmpData);

                bmp.Save(fileName);
            }
        }

        public static double OperandToDouble(List<PdfObject> operands, int operandIndex)
        {
            double value = 0;
            if (operands.Count() > operandIndex && operands[operandIndex] is PdfNumber)
            {
                return OperandToDouble(operands[operandIndex]);
            }
            return value;
        }

        public static double OperandToDouble(PdfObject operand)
        {
            double value = 0;
            if (operand is PdfNumber)
            {
                PdfNumber number = operand as PdfNumber;
                value = number.DoubleValue;
            }
            return value;
        }

        public static float OperandToFloat(List<PdfObject> operands, int operandIndex)
        {
            float value = 0;
            if (operands.Count() > operandIndex && operands[operandIndex] is PdfNumber)
            {
                return OperandToFloat(operands[operandIndex]);
            }
            return value;
        }

        public static float OperandToFloat(PdfObject operand)
        {
            float value = 0;
            if (operand is PdfNumber)
            {
                PdfNumber number = operand as PdfNumber;
                value = number.FloatValue;
            }
            return value;
        }

    }
}
