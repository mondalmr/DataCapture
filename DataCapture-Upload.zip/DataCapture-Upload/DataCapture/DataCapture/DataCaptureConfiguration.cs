﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DataCapture
{
    public static class DataCaptureConfiguration
    {
        private static bool initialized = false;
        private static int[] intIncludeCharacters = null;
        private static Dictionary<int, int> replaceCharracters = new Dictionary<int, int>();
       
        private static void init()
        {
            if (initialized == false)
                initialized = true;
            else
                return;

            DataCaptureConfigurationData ConfData = null;


            StreamReader file = null;
            XmlSerializer reader;

            string[] arrTemp = null;

            try
            {
                if (File.Exists("DataCaptureConfiguration.xml"))
                {
                    file = new StreamReader("DataCaptureConfiguration.xml");
                    reader = new XmlSerializer(typeof(DataCaptureConfigurationData));
                    ConfData = (DataCaptureConfigurationData)reader.Deserialize(file);
                    if (ConfData != null)
                    {
                        if (ConfData.IncludeCharacters != null)
                        {
                            arrTemp = ConfData.IncludeCharacters.Split(',');
                            if (arrTemp != null && arrTemp.Length > 0)
                            {
                                intIncludeCharacters = new int[arrTemp.Length];
                                for (int i = 0; i < arrTemp.Length; i++)
                                {
                                    intIncludeCharacters[i] = Int16.Parse(arrTemp[i]);
                                }
                            }
                        }
                        if (ConfData.ReplaceCharacters != null)
                        {
                            arrTemp = ConfData.ReplaceCharacters.Split(',');
                            if (arrTemp != null && arrTemp.Length > 0)
                            {
                                int key, value;                               
                                for (int i = 0; i < arrTemp.Length; i++)
                                {
                                  string []arrItem= arrTemp[i].Split('-');
                                  if (arrItem != null && arrItem.Length == 2)
                                  {
                                      key= int.Parse( arrItem[0]);
                                      value=int.Parse( arrItem[1]);
                                      replaceCharracters.Add(key,value);
                                  }
                                }
                            }
                        }
                        
                    }
                }
            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.StackTrace);
            }
            finally
            {

                if (file != null)
                {
                    file.Close();
                    file.Dispose();
                    file = null;
                }
            }
        
        }

        public  static bool IsValidChar(char ch){
            if (initialized == false) init();

            int charVal = (int)ch;

            for (int i = 0; i < intIncludeCharacters.Length; i++)
            {
                if (intIncludeCharacters[i] == charVal) return true;
                
            
            }

            return false;
        }
        public static bool IsValidReplaceableChar(char ch)
        {
            if (initialized == false) init();

            int charVal = (int)ch;
            return replaceCharracters.ContainsKey(charVal);
            

        }
        public static char? ReplaceWithValidChar(char ch)
        {
            if (initialized == false) init();

            int charVal = (int)ch;
            int ch2 = 0;

            if (replaceCharracters.ContainsKey(charVal))
            {
                replaceCharracters.TryGetValue(charVal, out ch2);
                return (char)ch2;
            }
            else
            {
                return null;
            }

        }
        public class DataCaptureConfigurationData
        {
            public string IncludeCharacters { get; set; }
            public string ReplaceCharacters { get; set; }            
        }
    }
}
