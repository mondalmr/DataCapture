﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;
using DataCapture.DTO;

namespace DataCapture
{
    [Serializable]
    public class GridColumnContent : NotifyInfo
    {
        ObservableCollection<string> _columnContents;
        ObservableCollection<ReplaceInfo> _replacements;

        public GridColumnContent()
        {
            RemoveEmpties = true;
            UpperCase = true;
            NumberFormat = true;

            _columnContents = new ObservableCollection<string>();
            _replacements = new ObservableCollection<ReplaceInfo>();
        }

        public double X
        {
            get;
            set;
        }

        public ObservableCollection<string> ColumnList
        {
            get
            {
                return _columnContents;
            }
        }

        public ObservableCollection<ReplaceInfo> Replacements
        {
            get
            {
                return _replacements;
            }
        }

        Grid _packageGrid;
        [XmlIgnoreAttribute]
        public Grid PackageGrid
        {
            get
            {
                return _packageGrid;
            }
            set
            {
                _packageGrid = value;
                RaisePropertyChanged("PackageGrid");
            }
        }

        bool _upperCase;
        public bool UpperCase
        {
            get
            {
                return _upperCase;
            }
            set
            {
                _upperCase = value;
                RaisePropertyChanged("UpperCase");
            }
        }

        bool _empties;
        public bool RemoveEmpties
        {
            get
            {
                return _empties;
            }
            set
            {
                _empties = value;
                RaisePropertyChanged("RemoveEmpties");
            }
        }

        bool _emptiesMultiLine;
        public bool EmptiesMultiLine
        {
            get
            {
                return _emptiesMultiLine;
            }
            set
            {
                _emptiesMultiLine = value;
                RaisePropertyChanged("EmptiesMultiLine");
            }
        }

        bool _removeNewLine;
        public bool RemoveNewLines
        {
            get
            {
                return _removeNewLine;
            }
            set
            {
                _removeNewLine = value;
                RaisePropertyChanged("RemoveNewLines");
            }
        }

        bool _numFormat;
        public bool NumberFormat
        {
            get
            {
                return _numFormat;
            }
            set
            {
                _numFormat = value;
                RaisePropertyChanged("NumberFormat");
            }
        }

        string _pkgColumn;
        public string PackageCountColumnCount
        {
            get
            {
                return _pkgColumn;
            }
            set
            {
                _pkgColumn = value;
                RaisePropertyChanged("PackageCountColumnCount");
            }
        }          

        public bool IsPackageCount(out int columnCount)
        {
            columnCount = 0;
            var yes = ColumnList != null && (ColumnList.Contains(Grid.CertificateAmt)  || ColumnList.Contains(Grid.CertificateNo));
            if (yes)
            {
                Int32.TryParse(PackageCountColumnCount, out columnCount);
                if (columnCount == 0)
                {
                    columnCount = 1;
                }
            }
            return yes;
        }        

        public void AddColumnElement(string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                _columnContents.Add(value);
                _packageGrid.RemoveAvailableColumns(value);
            }
        }

        public void RemoveColumnElement(int idx)
        {
            if (idx >= 0 && _columnContents.Count() > idx)
            {
                var value = _columnContents[idx];
                _columnContents.RemoveAt(idx);
                if (!Grid.DISCARD.Equals(value, StringComparison.InvariantCultureIgnoreCase))
                {
                    _packageGrid.AddAvailableColumns(value);
                }
            }
        }

        public void MoveColumnElement(int fromIdx, int toIdx)
        {
            if (fromIdx != toIdx && fromIdx >= 0 && toIdx >= 0 && _columnContents.Count() > fromIdx && _columnContents.Count() > toIdx)
            {
                var tmp = _columnContents[fromIdx];
                if (fromIdx < toIdx)
                {
                    if (_columnContents.Count() > fromIdx)
                    {
                        _columnContents.RemoveAt(fromIdx);
                    }
                }
                _columnContents.Insert(toIdx, tmp);
                if (fromIdx > toIdx)
                {
                    fromIdx++;
                    if (_columnContents.Count() > fromIdx)
                    {
                        _columnContents.RemoveAt(fromIdx);
                    }
                }
            }

        }

        [XmlIgnoreAttribute]
        public FrameworkElement Button
        {
            get;
            set;
        }

        public Dictionary<string, string> Parse(string text, bool euroFormat, bool captureExtendedChars, UnitList unitList)
        {
            var content = new Dictionary<string, string>();
            if (ColumnList == null || ColumnList.Count() == 0)
            {
                return content;
            }
            text = Replacements.ReplaceTexts(text);
            if (UpperCase)
            {
                text = text.ToUpper();
            }
            if (RemoveNewLines)
            {
                text = text.Replace(Environment.NewLine, " ");
            }
            var removeExtended = true;            

            string[] texts = text.Split(new string[] { Environment.NewLine, "\n", "\r" }, StringSplitOptions.None);
            if (texts != null && texts.Length > 0)
            {
                if (ColumnList != null)
                {
                    var idx = 0;
                    foreach (var column in ColumnList)
                    {
                        if (RemoveEmpties)
                        {
                            while (idx < texts.Length)
                            {
                                if (removeExtended)
                                {
                                    texts[idx] = texts[idx].RemoveExtendedCharacters();
                                }
                                if (!string.IsNullOrWhiteSpace(texts[idx]))
                                {
                                    break;
                                }
                                idx++;
                            }
                            if (idx >= texts.Length)
                            {
                                break;
                            }
                        }
                        if (!string.IsNullOrWhiteSpace(column) && !Grid.DISCARD.Equals(column))
                        {
                            string valueColumn = "";
                            string unitColumn = "";
                            if (Grid.IsValueUnitColumn(column, out valueColumn, out unitColumn))
                            {
                                texts[idx] = texts[idx].RemoveExtendedCharacters();
                                var valueUnit = texts[idx].SeparateValueAndUM(euroFormat);
                                if (valueUnit != null && valueUnit.Length > 1)
                                {
                                    content[valueColumn] = valueUnit[0];
                                    content[unitColumn] = valueUnit[1];
                                }
                                else
                                {
                                    content[valueColumn] = texts[idx];
                                }
                            }
                            else if (Grid.IsDecimalColumn(column) && NumberFormat)
                            {
                                texts[idx] = texts[idx].RemoveExtendedCharacters();
                                texts[idx] = texts[idx].Replace(" ", "");
                                if (euroFormat)
                                {
                                    texts[idx] = texts[idx].Replace(".", "");
                                    texts[idx] = texts[idx].Replace(",", ".");
                                }
                                decimal tmp = 0;
                                if (Decimal.TryParse(texts[idx], out tmp))
                                {
                                    content[column] = "" + tmp;
                                }
                            }
                            else if (Grid.IsMultiLineColumn(column))
                            {
                                StringBuilder sb = new StringBuilder();
                                for (var i = idx; i < texts.Length; i++)
                                {
                                    if (!captureExtendedChars)
                                    {
                                        texts[i] = texts[i].RemoveExtendedCharacters();
                                    }
                                    if (!EmptiesMultiLine || !string.IsNullOrEmpty(texts[i]))
                                    {
                                        sb.AppendLine(texts[i]);
                                    }
                                }
                                content[column] = sb.ToString();
                                break;
                            }
                            else
                            {
                                content[column] = texts[idx].Trim();
                            }
                        }
                        idx++;
                        if (idx >= texts.Length)
                        {
                            break;
                        }
                    }
                }
            }
            return content;
        }

        public GridColumnContent MakeClone(Grid packageGrid)
        {
            var pgcc = new GridColumnContent();
            pgcc.PackageGrid = packageGrid;
            pgcc.X = X;
            pgcc.UpperCase = UpperCase;
            pgcc.RemoveEmpties = RemoveEmpties;
            pgcc.EmptiesMultiLine = EmptiesMultiLine;
            pgcc.RemoveNewLines = RemoveNewLines;
            pgcc.NumberFormat = NumberFormat;
            //pgcc.MarksNosColumnCount = MarksNosColumnCount;
            //pgcc.GoodsDescriptionColumnCount = GoodsDescriptionColumnCount;
            pgcc._columnContents.Clear();
            foreach (var cc in _columnContents)
            {
                pgcc._columnContents.Add(cc);
            }
            pgcc._replacements.Clear();
            foreach (var repl in _replacements)
            {
                pgcc._replacements.Add(repl.MakeClone());
            }
            return pgcc;
        }
    }
}
