﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataCapture
{
    public class PDFTextRect
    {
        public PDFTextRect()
        {
            Stroke = System.Drawing.Color.Black;
            Fill = System.Drawing.Color.Black;
        }

        public PDFTextRect(string text, double left, double top, double width, double height)
        {
            Stroke = System.Drawing.Color.Black;
            Fill = System.Drawing.Color.Black;
            Text = text;
            Left = left;
            Top = top;
            Width = width;
            Height = height;
        }

        public string Text
        {
            get;
            set;
        }

        public string FullText
        {
            get;
            set;
        }

        public string FontFamily
        {
            get;
            set;
        }

        public bool AlternateFont
        {
            get;
            set;
        }

        public bool IsBold
        {
            get;
            set;
        }

        public double FontSize
        {
            get;
            set;
        }

        public TextRenderingMode TextMode
        {
            get;
            set;
        }

        public double Top
        {
            get;
            set;
        }

        /// <summary>
        /// Actual Top can be used in case of superscript/subscript text
        /// </summary>
        public double ActualTop
        {
            get;
            set;
        }

        public double Left
        {
            get;
            set;
        }

        public double Height
        {
            get;
            set;
        }

        public double Width
        {
            get;
            set;
        }

        public float TextRotation
        {
            get;
            set;
        }

        public double FontWidth
        {
            get
            {
                if (FontSize != 0 && !string.IsNullOrWhiteSpace(FontFamily))
                {
                    if (string.IsNullOrEmpty(Text))
                    {
                        return 0;
                    }
                    var size = Text.StringSize(FontFamily, IsBold, FontSize);
                    return size.Width;
                }
                return 0;
            }
        }

        public double Bottom
        {
            get
            {
                return Top + Height;
            }
        }

        public double Right
        {
            get
            {
                return Left + Width;
            }
        }

        public bool MatchText(PDFTextRect pdfTR)
        {
            if (Text == null && pdfTR.Text == null)
            {
                return true;
            }
            if (Text != null)
            {
                return Text.Equals(pdfTR.Text);
            }
            return false;
        }

        public bool IsSamePosition(PDFTextRect pdfTR)
        {
            return pdfTR != null &&
                Math.Abs(Left - pdfTR.Left) < 1f &&
                Math.Abs(Top - pdfTR.Top) < 1f;
        }

        public bool IsRepeat(PDFTextRect pdfTR)
        {
            return pdfTR != null &&
                this.MatchText(pdfTR) &&
                this.IsSamePosition(pdfTR) &&
                this.FontSize == pdfTR.FontSize;
        }

        public System.Drawing.Color Stroke
        {
            get;
            set;
        }

        public System.Drawing.Color Fill
        {
            get;
            set;
        }

        public PDFTextRect Copy()
        {
            var copy = new PDFTextRect();
            copy.AlternateFont = AlternateFont;
            copy.FontFamily = FontFamily;
            copy.FontSize = FontSize;
            copy.Height = Height;
            copy.IsBold = IsBold;
            copy.Left = Left;
            copy.Text = Text;
            copy.Top = Top;
            copy.Width = Width;
            copy.TextRotation = TextRotation;
            copy.Stroke = Stroke;
            copy.TextMode = TextMode;
            return copy;
        }

        public System.Drawing.Bitmap TextImage(System.Drawing.Brush foreground, float textWidth, float textHeight)
        {
            var width = (int)Math.Ceiling(textWidth);
            var height = (int)Math.Ceiling(textHeight);
            if (width == 0 || height == 0)
            {
                return null;
            }
            var bmp = new System.Drawing.Bitmap(width, height);
            using (var graphics = System.Drawing.Graphics.FromImage(bmp))
            {
                try
                {
                    var bold = IsBold ? System.Drawing.FontStyle.Bold : System.Drawing.FontStyle.Regular;
                    var font = new System.Drawing.Font(FontFamily, (float)FontSize, bold, System.Drawing.GraphicsUnit.Pixel);
                    graphics.Clear(System.Drawing.Color.Transparent);
                    graphics.DrawString(Text, font, foreground, 0, 0);
                }
                catch
                {
                }
                finally
                {
                    graphics.Dispose();
                }
            }
            return bmp;
        }

    }
}
