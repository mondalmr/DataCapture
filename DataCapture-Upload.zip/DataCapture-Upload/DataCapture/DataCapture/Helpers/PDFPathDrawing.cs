﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;

namespace DataCapture
{
    public class PDFPathDrawing
    {

        private static string[] DrawingCodes = new string[] { PDFOperators.Move, PDFOperators.Line, PDFOperators.BezierC, PDFOperators.BezierV, PDFOperators.BezierY, PDFOperators.Rectangle };

        Stack<GS> gsStack;
        PathPoint lastPoint;
        PathPoint lastPointA; // Adjusted (page height - y)
        PathPoint startPoint;
        PathPoint startPointA;
        PathColor currentStroke;
        PathColor currentNonStroke;
        double currentStrokeThickness;
        double scaleFactor;
        StringBuilder codeLog;
        StringBuilder pathLog;
        MainWindow mainWindow;
        List<DrawingPath> currentDrawingPaths;
        List<DrawingPath> drawingPaths;
        TextRenderingMode textMode;

        public PDFPathDrawing(MainWindow window)
        {
            mainWindow = window;
            startPoint = new PathPoint();
            startPointA = new PathPoint();
            lastPoint = new PathPoint();
            lastPointA = new PathPoint();
            currentStrokeThickness = 1;
            currentStroke = new PathColor(); // Black
            currentNonStroke = new PathColor(255, 255, 255); // White
            textMode = TextRenderingMode.Fill;
            scaleFactor = 1;
            codeLog = new StringBuilder();
            pathLog = new StringBuilder();
            currentDrawingPaths = new List<DrawingPath>();
            drawingPaths = new List<DrawingPath>();
            gsStack = new Stack<GS>();
            ClearPath();
        }

        public Color CurrentStroke
        {
            get
            {
                return currentStroke.ToDrawingColor();
            }
        }

        public TextRenderingMode CurrentTextMode
        {
            get
            {
                return textMode;
            }
        }

        public Color CurrentNonStroke
        {
            get
            {
                return currentNonStroke.ToDrawingColor();
            }
        }

        public void SaveGraphicsState()
        {
            gsStack.Push(new GS() { Stroke = CurrentStroke, NonStroke = CurrentNonStroke, ScaleFactor = scaleFactor, StrokeThickness = currentStrokeThickness, TextMode = CurrentTextMode });
        }

        public void RestoreGraphicsState()
        {
            if (gsStack.Count() > 0)
            {
                var gs = gsStack.Pop();
                currentStroke.FromDrawingColor(gs.Stroke);
                currentNonStroke.FromDrawingColor(gs.NonStroke);
                scaleFactor = gs.ScaleFactor;
                currentStrokeThickness = gs.StrokeThickness;
                textMode = gs.TextMode;
            }
        }

        private GraphicsPath GrafixPath
        {
            get
            {
                var path = new DrawingPath((float)currentStrokeThickness, CurrentStroke, CurrentNonStroke);
                currentDrawingPaths.Add(path);
                return path.Path;
            }
        }

        private void ClearPath()
        {
            currentDrawingPaths.Clear();
        }

        private double ConvertOperand(List<PdfObject> operands, int operandIndex, bool adjustScale)
        {
            double value = 0;
            if (operands.Count() > operandIndex && operands[operandIndex] is PdfNumber)
            {
                PdfNumber number = operands[operandIndex] as PdfNumber;
                value = number.DoubleValue;
                if (adjustScale)
                {
                    if (scaleFactor > 1)
                    {
                        value = value / scaleFactor;
                    }
                    else
                    {
                        //value = value / 8.35;
                        value = value * 0.12;
                    }
                }

            }
            return value;
        }

        private void SetStartPoint(double x, double y, double ya)
        {
            startPoint.X = x;
            startPoint.Y = y;
            startPointA.X = x;
            startPointA.Y = ya;
        }

        private void SetLastPoint(double x, double y, double ya)
        {
            lastPoint.X = x;
            lastPoint.Y = y;
            lastPointA.X = x;
            lastPointA.Y = ya;
        }

        private PointF POINTF(double x, double y)
        {
            return new PointF((float)x, (float)y);
        }

        private PointF[] POINTFs(params PointF[] points)
        {
            return points;
        }

        public bool Invoke(PdfLiteral oper, List<PdfObject> operands, PDFCtm ctm, int rotation, double pageHeight, bool hideShapes)
        {
            bool success = false;
            if (oper != null)
            {
                string code = oper.ToString();
                if (!string.IsNullOrWhiteSpace(code))
                {
                    var x1 = PDFUtils.OperandToDouble(operands, 0);
                    var y1 = PDFUtils.OperandToDouble(operands, 1);

                    var x2 = PDFUtils.OperandToDouble(operands, 2);
                    var y2 = PDFUtils.OperandToDouble(operands, 3);

                    var x3 = PDFUtils.OperandToDouble(operands, 4);
                    var y3 = PDFUtils.OperandToDouble(operands, 5);

                    if (rotation == 90 || rotation == 270)
                    {
                        var tmp = x1;
                        if (x1 != y1)
                        {
                            tmp = x1;
                            x1 = y1;
                            y1 = tmp;
                        }
                        if (x2 != y2)
                        {
                            tmp = x2;
                            x2 = y2;
                            y2 = tmp;
                        }
                        if (x3 != y3)
                        {
                            tmp = x3;
                            x3 = y3;
                            y3 = tmp;
                        }
                    }

                    if (ctm != null && ctm.ScaleX != 0d && ctm.ScaleY != 0d && DrawingCodes.Contains(code))
                    {
                        x1 = x1 * ctm.ScaleX;
                        y1 = y1 * ctm.ScaleY;

                        x2 = x2 * ctm.ScaleX;
                        y2 = y2 * ctm.ScaleY;

                        x3 = x3 * ctm.ScaleX;
                        y3 = y3 * ctm.ScaleY;
                    }

                    var y1a = AdjustedY(y1);
                    var y2a = AdjustedY(y2);
                    var y3a = AdjustedY(y3);

                    if (rotation == 90 || rotation == 270)
                    {
                        y1a = y1;
                        y2a = y2;
                        y3a = y3;
                    }

                    success = true;

                    switch (code)
                    {
                        case PDFOperators.LineWidth:
                            if (x1 != 0)
                            {
                                scaleFactor = x1;
                            }
                            break;

                        case PDFOperators.TextRenderingMode:
                            textMode = (TextRenderingMode)x1;
                            break;

                        case PDFOperators.GreyStroke:
                            currentStroke.SetGrey(x1);
                            break;

                        case PDFOperators.RGBStroking:
                            currentStroke.SetRGB(x1, y1, x2);
                            break;

                        case PDFOperators.CMYKStroking:
                            currentStroke.SetCMYK(x1, y1, x2, y2);
                            break;

                        case PDFOperators.ColorStroking:
                            //currentStroke.SetRGB(x1, y1, x2);
                            break;

                        case PDFOperators.GreyNonStroke:
                            currentNonStroke.SetGrey(x1);
                            break;

                        case PDFOperators.RGBNonStroking:
                            currentNonStroke.SetRGB(x1, y1, x2);
                            break;

                        case PDFOperators.CMYKNonStroking:
                            currentNonStroke.SetCMYK(x1, y1, x2, y2);
                            break;

                        case PDFOperators.ColorNonStroking:
                            //currentNonStroke.SetRGB(x1, y1, x2);
                            break;

                        case PDFOperators.Clear:
                            ClearPath();
                            break;


                        case PDFOperators.Move:
                            ClearPath();

                            SetStartPoint(x1, y1, y1a);
                            SetLastPoint(x1, y1, y1a);
                            break;

                        case PDFOperators.Line:
                            GrafixPath.AddLine((float)lastPoint.X, (float)lastPointA.Y, (float)x1, (float)y1a);
                            SetLastPoint(x1, y1, y1a);
                            break;

                        case PDFOperators.BezierC:
                            GrafixPath.AddBeziers(POINTFs(POINTF(lastPointA.X, lastPointA.Y), POINTF(x3, y3a), POINTF(x1, y1a), POINTF(x2, y2a)));
                            SetLastPoint(x3, y3, y3a);
                            break;

                        case PDFOperators.BezierV:
                            GrafixPath.AddBeziers(POINTFs(POINTF(lastPointA.X, lastPointA.Y), POINTF(x2, y2a), POINTF(lastPointA.X, lastPointA.Y), POINTF(x1, y1a)));
                            SetLastPoint(x2, y2, y2a);
                            break;

                        case PDFOperators.BezierY:
                            GrafixPath.AddBeziers(POINTFs(POINTF(lastPointA.X, lastPointA.Y), POINTF(x2, y2a), POINTF(x1, y1a), POINTF(x2, y2a)));
                            SetLastPoint(x2, y2, y2a);
                            break;

                        case PDFOperators.Rectangle:
                            double W = x2;
                            double H = y2;
                            if (y2 < 0)
                            {
                                y1 = y1 + y2;
                                if (y1 < 0)
                                {
                                    y1 = 0;
                                }
                                H = Math.Abs(y2);
                            }
                            double X = x1;
                            double Y = y1;
                            if (rotation == 90 || rotation == 270)
                            {
                                Y = y1;
                            }
                            else
                            {
                                Y = AdjustedY(y1 + y2);
                            }
                            GrafixPath.AddRectangle(new RectangleF((float)X, (float)Y, (float)W, (float)H));
                            break;

                        case PDFOperators.Close:
                            if (lastPoint.X != startPoint.X || lastPoint.Y != startPoint.Y)
                            {
                                SetLastPoint(startPoint.X, startPoint.Y, startPointA.Y);
                                GrafixPath.AddLine((float)lastPoint.X, (float)lastPointA.Y, (float)startPoint.X, (float)startPointA.Y);
                            }
                            else
                            {
                                ClearPath();
                            }
                            break;


                        case PDFOperators.FillStrokeEvenOdd:
                        case PDFOperators.FillEvenOdd:
                        case PDFOperators.FillStrokeNonZero:
                        case PDFOperators.FillPathNonZeroObsolete:
                        case PDFOperators.FillPathNonZero:
                        case PDFOperators.Stroke:
                            if (hideShapes)
                            {
                                ClearPath();
                            }
                            else
                            {
                                RenderPaths(code, true);
                            }
                            break;

                        case PDFOperators.CloseFillStrokeEvenOdd:
                        case PDFOperators.CloseFillStrokeNonZero:
                        case PDFOperators.StrokeAfterClose:
                            if (hideShapes)
                            {
                                ClearPath();
                            }
                            else
                            {
                                RenderPaths(code, false);
                            }
                            break;

                        default:
                            success = false;
                            break;
                    }
                }
            }
            if (success)
            {
                codeLog.Append(oper);
                codeLog.Append(" :");
                foreach (var pdfO in operands)
                {
                    codeLog.Append(" ");
                    codeLog.Append(pdfO);
                }
                codeLog.AppendLine("");
            }
            return success;
        }

        private void RenderPaths(string code, bool clearPaths)
        {
            if (currentDrawingPaths != null && currentDrawingPaths.Count() > 0)
            {
                foreach (var path in currentDrawingPaths)
                {
                    path.FillCode = code;
                    switch (code)
                    {
                        case PDFOperators.FillStrokeEvenOdd:
                        case PDFOperators.CloseFillStrokeEvenOdd:
                        case PDFOperators.FillEvenOdd:
                            path.Path.FillMode = FillMode.Alternate;
                            break;

                        case PDFOperators.FillStrokeNonZero:
                        case PDFOperators.CloseFillStrokeNonZero:
                        case PDFOperators.FillPathNonZeroObsolete:
                        case PDFOperators.FillPathNonZero:
                            path.Path.FillMode = FillMode.Winding;
                            break;
                    }
                }
                drawingPaths.AddRange(currentDrawingPaths);
                if (clearPaths)
                {
                    ClearPath();
                }
            }
        }

        public List<DrawingPath> DrawingPaths
        {
            get
            {
                return drawingPaths;
            }
        }

        private double AdjustedY(double y)
        {
            double pageHeight = mainWindow.PageHeight;
            if (pageHeight > y)
            {
                return pageHeight - y;
            }
            return y;
        }
    }

    class GS
    {
        public Color Stroke
        {
            get;
            set;
        }

        public Color NonStroke
        {
            get;
            set;
        }

        public double StrokeThickness
        {
            get;
            set;
        }

        public double ScaleFactor
        {
            get;
            set;
        }

        public TextRenderingMode TextMode
        {
            get;
            set;
        }
    }

    class PathPoint
    {
        public double X
        {
            get;
            set;
        }

        public double Y
        {
            get;
            set;
        }
    }

    class PathColor
    {
        public PathColor()
        {
        }

        public PathColor(byte red, byte green, byte blue)
        {
            Red = red;
            Green = green;
            Blue = blue;
        }

        public byte Red
        {
            get;
            set;
        }

        public byte Green
        {
            get;
            set;
        }

        public byte Blue
        {
            get;
            set;
        }

        public void SetGrey(double greyScale)
        {
            var grey = (byte)(255 * greyScale);
            Red = grey;
            Green = grey;
            Blue = grey;
        }

        public void SetCMYK(double cyanScale, double magentaScale, double yellowScale, double blackScale)
        {
            Red = (byte)(255 * (1 - cyanScale) * (1 - blackScale));
            Green = (byte)(255 * (1 - magentaScale) * (1 - blackScale));
            Blue = (byte)(255 * (1 - yellowScale) * (1 - blackScale));
        }

        public void SetRGB(double redScale, double greenScale, double blueScale)
        {
            Red = (byte)(255 * redScale);
            Green = (byte)(255 * greenScale);
            Blue = (byte)(255 * blueScale);
        }

        public Color ToDrawingColor()
        {
            return Color.FromArgb((int)Red, (int)Green, (int)Blue);
        }


        public void FromDrawingColor(Color color)
        {
            Red = color.R;
            Green = color.G;
            Blue = color.B;
        }
    }
}
