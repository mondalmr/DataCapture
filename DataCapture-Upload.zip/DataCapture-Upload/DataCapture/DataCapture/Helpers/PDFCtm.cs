﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;

namespace DataCapture
{
    public class PDFCtm
    {

        public PDFCtm()
        {
        }

        public PDFCtm(List<PdfObject> operands)
        {
            ScaleX = PDFUtils.OperandToDouble(operands, 0);
            SkewX = PDFUtils.OperandToDouble(operands, 1);
            SkewY = PDFUtils.OperandToDouble(operands, 2);
            ScaleY = PDFUtils.OperandToDouble(operands, 3);
            X = PDFUtils.OperandToDouble(operands, 4);
            Y = PDFUtils.OperandToDouble(operands, 5);

        }

        public PDFCtm Copy()
        {
            PDFCtm ctm = new PDFCtm();
            ctm.ScaleX = ScaleX;
            ctm.ScaleY = ScaleY;
            ctm.SkewX = SkewX;
            ctm.SkewY = SkewY;
            ctm.X = X;
            ctm.Y = Y;
            return ctm;
        }

        public double ScaleX
        {
            get;
            set;
        }

        public double ScaleY
        {
            get;
            set;
        }

        public double SkewX
        {
            get;
            set;
        }

        public double SkewY
        {
            get;
            set;
        }

        public double X
        {
            get;
            set;
        }

        public double Y
        {
            get;
            set;
        }

        public System.Drawing.Drawing2D.Matrix ToMatrix()
        {
            return new System.Drawing.Drawing2D.Matrix((float)ScaleX, (float)SkewX, (float)SkewY, (float)ScaleY, (float)X, (float)Y);
        }

        public void Concat(List<PdfObject> operands)
        {
            double b11 = ScaleX;
            double b12 = SkewX;
            double b13 = 0;

            double b21 = SkewY;
            double b22 = ScaleY;
            double b23 = 0;

            double b31 = X;
            double b32 = Y;
            double b33 = 1;

            double a11 = PDFUtils.OperandToDouble(operands, 0);
            double a12 = PDFUtils.OperandToDouble(operands, 1);
            double a13 = 0;

            double a21 = PDFUtils.OperandToDouble(operands, 2);
            double a22 = PDFUtils.OperandToDouble(operands, 3);
            double a23 = 0;

            double a31 = PDFUtils.OperandToDouble(operands, 4);
            double a32 = PDFUtils.OperandToDouble(operands, 5);
            double a33 = 1;

            double c11 = (a11 * b11) + (a12 * b21) + (a13 * b31);
            double c12 = (a11 * b12) + (a12 * b22) + (a13 * b32);
            double c13 = (a11 * b13) + (a12 * b23) + (a13 * b33);

            double c21 = (a21 * b11) + (a22 * b21) + (a23 * b31);

            double c22 = (a21 * b12) + (a22 * b22) + (a23 * b32);
            double c23 = (a21 * b13) + (a22 * b23) + (a23 * b33);

            double c31 = (a31 * b11) + (a32 * b21) + (a33 * b31);
            double c32 = (a31 * b12) + (a32 * b22) + (a33 * b32);
            double c33 = (a31 * b13) + (a32 * b23) + (a33 * b33);

            /*
             * 3x3 matrix concatenation
             * c13, c23 & c33 are discarded
             * Replace with 0 for a13, a23, b13, b23 
             *          and 1 for a33, b33, we get
             * c11 = (a11 * b11) + (a12 * b21) + (  0 * b31);
             * c12 = (a11 * b12) + (a12 * b22) + (  0 * b32);
             * 
             * c21 = (a21 * b11) + (a22 * b21) + (  0 * b31);
             * c22 = (a21 * b12) + (a22 * b22) + (  0 * b32);
             * 
             * c31 = (a31 * b11) + (a32 * b21) + (  1 * b31);
             * c32 = (a31 * b12) + (a32 * b22) + (  1 * b32);
             * 
             * We get as below
             * 
             * c11 = (a11 * b11) + (a12 * b21);
             * c12 = (a11 * b12) + (a12 * b22);
             * 
             * c21 = (a21 * b11) + (a22 * b21);
             * c22 = (a21 * b12) + (a22 * b22);
             * 
             * c31 = (a31 * b11) + (a32 * b21) + b31;
             * c32 = (a31 * b12) + (a32 * b22) + b32;
             */


            ScaleX = c11;
            SkewX = c12;

            SkewY = c21;
            ScaleY = c22;

            X = c31;
            Y = c32;
        }
    }
}
