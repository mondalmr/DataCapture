﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf.parser;

namespace DataCapture
{
    public class PDFImageCtm
    {

        public PDFImageCtm(Matrix ctm, Image image, int rotation, double pageHeight)
            : this()
        {
            if (ctm != null)
            {
                if (rotation == 90 || rotation == 270)
                {
                    X = ctm[7];
                    Y = ctm[6];
                    ScaleWidth = ctm[4];
                    ScaleHeight = ctm[0];
                    SkewX = ctm[3];
                    SkewY = ctm[1];
                }
                else
                {
                    X = ctm[6];
                    Y = ctm[7];
                    ScaleWidth = ctm[0];
                    ScaleHeight = ctm[4];
                    SkewX = ctm[1];
                    SkewY = ctm[3];
                }
            }
            Image = image;
            if (ScaleWidth < 0 && ScaleHeight < 0)
            {
                //Image.RotateFlip(RotateFlipType.RotateNoneFlipXY);
                //ScaleWidth = ScaleWidth * -1;
                //ScaleHeight = ScaleHeight * -1;
            }
            else if (ScaleWidth < 0)
            {
                //Image.RotateFlip(RotateFlipType.RotateNoneFlipX);
                //ScaleWidth = ScaleWidth * -1;
            }
            else if (ScaleHeight < 0)
            {
                //Image.RotateFlip(RotateFlipType.RotateNoneFlipY);
                //ScaleHeight = ScaleHeight * -1;
            }
        }

        public PDFImageCtm()
        {
            X = 0;
            Y = 0;
            ScaleWidth = 0;
            ScaleHeight = 0;
        }

        public double X
        {
            get;
            set;
        }

        public double Y
        {
            get;
            set;
        }

        public float ScaleWidth
        {
            get;
            set;
        }

        public float ScaleHeight
        {
            get;
            set;
        }

        public float SkewX
        {
            get;
            set;
        }

        public float SkewY
        {
            get;
            set;
        }

        public float RotateX
        {
            get;
            set;
        }

        public float RotateY
        {
            get;
            set;
        }

        public Image Image
        {
            get;
            set;
        }

        public double ActualWidth
        {
            get
            {
                if (Image != null)
                {
                    var value = (double)Image.Width;
                    return value;
                }
                return 0;
            }
        }

        public double ActualHeight
        {
            get
            {
                if (Image != null)
                {
                    var value = (double)Image.Height;
                    return value;
                }
                return 0;
            }
        }

        public double XFactor
        {
            get
            {
                double actual = ActualWidth;
                if (actual > 0 && ScaleWidth > 0)
                {
                    return actual / ScaleWidth;

                }
                return (double)1;
            }
        }

        public double YFactor
        {
            get
            {
                var ah = Math.Abs(ScaleHeight);
                double actual = ActualHeight;
                if (actual > 0 && ah > 0)
                {
                    return actual / ah;

                }
                return (double)1;
            }
        }

        public double AdjustedX
        {
            get
            {
                return X * XFactor;
            }
        }


        public double AdjustedY
        {
            get
            {
                return Y * YFactor;
            }
        }

        private double ScaledValue(double value, double scale)
        {
            if (scale > 0 && scale != 1)
            {
                return value / scale;
            }
            return value;
        }

        public double ScaledLeft
        {
            get
            {
                return ScaledValue(X, ScaleWidth);
            }
        }

        public double ScaledTop
        {
            get
            {
                return ScaledValue(Y, ScaleHeight);
            }
        }

        public void AdjustActualSize(ref double width, ref double height)
        {
            var leftWidth = AdjustedX + ActualWidth;
            //var topHeight = AdjustedY + ActualHeight;
            var topHeight = AdjustedY;
            if (topHeight == 0)
            {
                topHeight = ActualHeight;
            }
            if (width < leftWidth)
            {
                width = leftWidth;
            }
            if (height < topHeight)
            {
                height = topHeight;
            }
        }

        public void AdjustScaleSize(ref double width, ref double height)
        {
            var leftWidth = X + ScaleWidth;
            var topHeight = Y + ScaleHeight;
            if (ScaleWidth > 0 && width < leftWidth)
            {
                width = leftWidth;
            }
            if (ScaleHeight>0 && height < topHeight)
            {
                height = topHeight;
            }
        }


    }
}
