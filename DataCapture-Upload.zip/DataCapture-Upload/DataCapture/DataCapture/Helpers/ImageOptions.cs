﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class ImageOptions : NotifyInfo
    {
        public ImageOptions()
        {
            SmoothEdges = false;
        }

        public bool HasValue
        {
            get
            {
                return
                    (this.SpeckleWidth.ContainsValue() && this.SpeckleHeight.ContainsValue() && this.WhitespaceWidth.ContainsValue() && this.WhitespaceHeight.ContainsValue()) ||
                    this.HMax.ContainsValue() ||
                    this.VMax.ContainsValue() ||
                    this.SmoothEdges == true
                    ;
            }
        }

        string _speckleWidth;
        public string SpeckleWidth
        {
            get
            {
                return _speckleWidth;
            }
            set
            {
                _speckleWidth = value;
                RaisePropertyChanged("SpeckleWidth");
            }
        }

        string _speckleHeight;
        public string SpeckleHeight
        {
            get
            {
                return _speckleHeight;
            }
            set
            {
                _speckleHeight = value;
                RaisePropertyChanged("SpeckleHeight");
            }
        }

        string _whitespaceWidth;
        public string WhitespaceWidth
        {
            get
            {
                return _whitespaceWidth;
            }
            set
            {
                _whitespaceWidth = value;
                RaisePropertyChanged("WhitespaceWidth");
            }
        }

        string _whitespaceHeight;
        public string WhitespaceHeight
        {
            get
            {
                return _whitespaceHeight;
            }
            set
            {
                _whitespaceHeight = value;
                RaisePropertyChanged("WhitespaceHeight");
            }
        }

        string _hMax;
        public string HMax
        {
            get
            {
                return _hMax;
            }
            set
            {
                _hMax = value;
                RaisePropertyChanged("HMax");
            }
        }

        string _vMax;
        public string VMax
        {
            get
            {
                return _vMax;
            }
            set
            {
                _vMax = value;
                RaisePropertyChanged("VMax");
            }
        }

        bool? _smoothEdges;
        public bool? SmoothEdges
        {
            get
            {
                return _smoothEdges;
            }
            set
            {
                _smoothEdges = value;
                RaisePropertyChanged("SmoothEdges");
            }
        }

        public ImageOptions Copy()
        {
            var copy = new ImageOptions();
            copy.HMax = HMax;
            copy.VMax = VMax;
            copy.SpeckleWidth = SpeckleWidth;
            copy.SpeckleHeight = SpeckleHeight;
            copy.WhitespaceWidth = WhitespaceWidth;
            copy.WhitespaceHeight = WhitespaceHeight;
            copy.SmoothEdges = SmoothEdges;
            return copy;
        }

    }
}
