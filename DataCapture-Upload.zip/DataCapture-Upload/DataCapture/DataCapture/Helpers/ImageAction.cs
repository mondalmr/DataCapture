﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace DataCapture
{
    public class ImageAction
    {
        static Brush CustomBrush = null;
        static Brush EraseBrush = null;
        static Brush RotateBrush = null;
        static Brush DeskewBrush = null;

        public double Left
        {
            get;
            set;
        }

        public double Top
        {
            get;
            set;
        }

        public double Width
        {
            get;
            set;
        }

        public double Height
        {
            get;
            set;
        }

        public ImageOperation Operation
        {
            get;
            set;
        }

        public int Page
        {
            get;
            set;
        }

        public bool IsCustom
        {
            get;
            set;
        }

        public bool Skip
        {
            get;
            set;
        }

        public float Rotation
        {
            get;
            set;
        }

        [XmlIgnoreAttribute]
        public Rectangle Rectangle
        {
            get;
            set;
        }

        public bool Equals(ImageAction action)
        {
            return
                Page == action.Page &&
                Left == action.Left &&
                Top == action.Top &&
                Width == action.Width &&
                Height == action.Height
                ;
        }

        public void UpdateRectangeBrush()
        {
            if (Rectangle == null)
            {
                return;
            }
            if (CustomBrush == null)
            {
                var siCapture = MainWindow.Current;
                if (siCapture != null)
                {
                    EraseBrush = siCapture.FindResource("DiagonalLinesErase") as Brush;
                    RotateBrush = siCapture.FindResource("DiagonalLinesRotate") as Brush;
                    DeskewBrush = siCapture.FindResource("DiagonalLinesDeskew") as Brush;
                    CustomBrush = siCapture.FindResource("DiagonalLinesCustom") as Brush;
                }
            }

            if (IsCustom)
            {
                Rectangle.StrokeThickness = 1;
                Rectangle.Stroke = CustomBrush;
            }
            else
            {
                Rectangle.StrokeThickness = 2;
                switch (Operation)
                {
                    case ImageOperation.Deskew:
                        Rectangle.Stroke = DeskewBrush;
                        break;

                    case ImageOperation.Rotate:
                        Rectangle.Stroke = RotateBrush;
                        break;

                    case ImageOperation.Erase:
                        Rectangle.Stroke = EraseBrush;
                        break;
                }
            }

        }
    }
}
