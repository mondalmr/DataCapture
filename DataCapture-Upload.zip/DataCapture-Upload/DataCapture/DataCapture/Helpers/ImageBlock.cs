﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class ImageBlock
    {
        public int RowSpan
        {
            get;
            set;
        }

        public int ColumnSpan
        {
            get;
            set;
        }

        public int Left
        {
            get;
            set;
        }

        public int Top
        {
            get;
            set;
        }

        public int Width
        {
            get;
            set;
        }

        public int Height
        {
            get;
            set;
        }

        public int Right
        {
            get
            {
                if (Width > 0)
                {
                    return Left + Width - 1;
                }
                return Left;
            }
        }

        public int Bottom
        {
            get
            {
                if (Height > 0)
                {
                    return Top + Height - 1;
                }
                return Top;
            }
        }

        public bool IsMargin
        {
            get;
            set;
        }

    }
}
