﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DataCapture
{
    public class ImageSIReader : IDCReader
    {
        int _PageCount = -1;
        string _FilePath;
        string _ErrorMessage;
        Canvas _Canvas;
        MainWindow _Window;
        string _UnskewImages;
        int _ImageColor;
        Bitmap _Image;

        public ImageSIReader(MainWindow siCapture)
        {
            _Image = null;
            _Window = siCapture;
        }

        public string Description
        {
            get
            {
                return "Image";
            }
        }

        public string[] SupportedExtensions
        {
            get
            {
                return new string[] { "bmp", "jpg", "jpeg", "gif", "png", "tif", "tiff" };
            }
        }

        public string FilePath
        {
            get
            {
                return _FilePath;
            }
            set
            {
                if (string.Compare(_FilePath, value, true) != 0)
                {
                    _FilePath = value;
                    _PageCount = -1;
                }
            }
        }

        public int PageCount
        {
            get
            {
                if (_PageCount < 0)
                {
                    ReadFile();
                }
                return _PageCount;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return _ErrorMessage;
            }
        }

        public void RenderPage(int pageNo, Canvas canvas, MainWindow window, string unskewImages, int imageColor, bool automate = false)
        {
            if (_Image != null)
            {
                pageNo--;

                _UnskewImages = unskewImages;
                _ImageColor = imageColor;
                _Window = window;
                _Canvas = canvas;
                _Image.SelectActiveFrame(FrameDimension.Page, pageNo);

                ImageUtils.Flip(_Image, _Window.ImageFlip);
                Size size = _Image.Size;
                _Window.SetPageSize(size.Width, size.Height);
                var unskew = Constants.DESKEWREGULAR.Equals(_UnskewImages);
                var image = ImageUtils.ResizeAndDeSkewImage(_Image, unskew, imageColor, size.Width, size.Height);

                image = ImageUtils.ApplyEnhancements(image, window.ImageOptions);

                ImageAction[] actions = null;
                if (Constants.DESKEWCUSTOM.Equals(_UnskewImages))
                {
                    actions = ImageUtils.DeSkewImageInBlocks(image, _Window.DeskewInfo, pageNo, _Window.CurrentPageActions);
                }
                _Window.ImageExists = true;
                _Window.SetImage(image, 0, 0);
                _Window.SetImageActionsForPage(actions, pageNo);
            }
        }

        private void ReadFile()
        {
            if (!string.IsNullOrWhiteSpace(FilePath))
            {
                byte[] data = File.ReadAllBytes(FilePath);
                _Image = new Bitmap(new MemoryStream(data));
                _PageCount = _Image.GetFrameCount(FrameDimension.Page);
            }
        }


    }
}
