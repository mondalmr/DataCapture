﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DataCapture
{
    public class ImageRegion
    {
        public ImageRegion(Image image, System.Drawing.Bitmap bitmap, HighlightRegion highlightRegion, double ocrSize)
        {
            Image = image;
            Bitmap = bitmap;
            HighlightRegion = highlightRegion;
            OCRSize = ocrSize;
        }

        public double OCRSize
        {
            get;
            set;
        }

        public System.Drawing.Bitmap Bitmap
        {
            get;
            set;
        }

        public Image Image
        {
            get;
            set;
        }

        public HighlightRegion HighlightRegion
        {
            get;
            set;
        }

        public BitmapSource CroppedImage()
        {
            if (Image != null)
            {
                BitmapSource bSource = Image.Source as BitmapSource;
                if (bSource != null)
                {
                    CroppedBitmap cBmp = new CroppedBitmap(bSource, new Int32Rect((int)HighlightRegion.Left, (int)HighlightRegion.Top, (int)HighlightRegion.Width, (int)HighlightRegion.Height));
                    return cBmp;
                }
            }
            return null;
        }

        public BitmapSource ImageWithUpgradedResolution(BitmapSource bmp)
        {
            if (bmp != null)
            {
                var dpiX = bmp.DpiX;
                var dpiY = bmp.DpiY;
                if (dpiX < 300 || dpiY < 300)
                {
                    if (dpiX == dpiY)
                    {
                        dpiX = 300;
                        dpiY = 300;
                    }
                    else
                    {
                        var tmp = dpiY;
                        if (dpiX < 300)
                        {
                            tmp = dpiX;
                        }
                        tmp = (double)300 / tmp;
                        dpiX = tmp * dpiX;
                        dpiY = tmp * dpiY;
                    }
                    var width = bmp.PixelWidth;
                    var height = bmp.PixelHeight;
                    var stride = width * 4;
                    var length = stride * height;
                    byte[] pixels = new byte[length];
                    bmp.CopyPixels(pixels, stride, 0);
                    return BitmapSource.Create(width, height, dpiX, dpiY, PixelFormats.Gray16, null, pixels, stride);
                }
            }
            return bmp;
        }

        public bool CropAndSave(string filePath, string deskew, out ImageSource image)
        {
            if (Bitmap != null)
            {
                var croppedImage = Bitmap.CropImage(HighlightRegion);
                if (croppedImage != null)
                {
                    if (Constants.DESKEWBEFOREOCR.Equals(deskew))
                    {
                        double skewAngle = 0;
                        croppedImage = ImageUtils.DeSkewImage(croppedImage, out skewAngle, true, true);
                    }

                    int minWidth = 500;
                    int minHeight = 150;
                    var paddedImage = croppedImage;
                    if (croppedImage.Width < minWidth || croppedImage.Height < minHeight)
                    {
                        paddedImage = ImageUtils.PaddedImage(croppedImage, minWidth, minHeight);
                    }
                    var resizedImage = ImageUtils.ResizeImage(paddedImage, OCRSize);
                    resizedImage.SaveAsTiff(filePath);
                    resizedImage.Dispose();
                    image = croppedImage.ToWPFImageSource(false, 2);
                    croppedImage.Dispose();
                    paddedImage.Dispose();
                    return true;
                }
            }            

            bool success = true;
            image = null;
            BitmapSource bmp = CroppedImage();
            if (bmp != null)
            {
                using (FileStream stream = new FileStream(filePath, FileMode.Create))
                {
                    try
                    {
                        var encoder = new TiffBitmapEncoder();
                        encoder.Frames.Add(BitmapFrame.Create(bmp));
                        encoder.Save(stream);
                        stream.Close();
                        success = true;
                        image = bmp;
                    }
                    catch (Exception e)
                    {
                        e.LogException();
                    }
                }
            }
            return success;
        }

        public string GetText(out ImageSource image, out double accuracy, string characterList, string imageFile, string textFile, string deskew, int rounds)
        {
            accuracy = 0;
            string text = null;
            if (CropAndSave(imageFile, deskew, out image))
            {
                text = OCRUtils.GetTextFromOCRTif(out accuracy, characterList, imageFile, textFile, rounds);
            }
           
            return text;
        }
    }
}
