﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace DataCapture
{
    public class PDFSIReader : IDCReader, IRenderListener, IContentOperator, IXObjectDoHandler
    {

        public const int FillText = 0;
        public const int StrokeText = 1;
        public const int FillThenStrokeText = 2;
        public const int Invisible = 3;
        public const int FillTextAndAddToPathForClipping = 4;
        public const int StrokeTextAndAddToPathForClipping = 5;
        public const int FillThenStrokeTextAndAddToPathForClipping = 6;
        public const int AddTextToPaddForClipping = 7;

        int _PageCount = -1;
        string _FilePath;
        Canvas _Canvas;
        protected MainWindow _Window;
        string _UnskewImages;
        int _ImageColor;
        PDFPathDrawing _PathDrawing;
        PdfReader _Reader;
        List<PDFImageCtm> _CTMS;
        double _MaxWidth;
        double _MaxHeight;
        double _ScaleWidth;
        double _ScaleHeight;
        StringBuilder _Operators;
        PDFCtm _CurrentCTM;
        PDFCtm _CurrentTextCTM;
        Stack<PDFCtm> _StackCTM;
        Stack<double> _StackFontSize;
        double _FontSize;
        string _FontName;
        long _TextCount;
        int _Rotation;
        iTextSharp.text.Rectangle _PageRect;
        Dictionary<string, IContentOperator> _ExistingOperators;
        PDFTextRect _LastTR;
        SortedDictionary<XYCo, PDFTextRect> _PdfTexts;
        protected string _ErrorMessage;

        public PDFSIReader(MainWindow siCapture)
        {
            _PageCount = -1;
            _FilePath = "";
            _Reader = null;
            _Window = siCapture;
            _PathDrawing = null;
            _CurrentCTM = null;
            _CurrentTextCTM = null;
            _StackCTM = new Stack<PDFCtm>();
            _StackFontSize = new Stack<double>();
            _CTMS = new List<PDFImageCtm>();
            _ExistingOperators = new Dictionary<string, IContentOperator>();
            _FontName = "";
            _FontSize = 0;
            _Operators = new StringBuilder();
            _PdfTexts = new SortedDictionary<XYCo, PDFTextRect>();
        }

        public virtual string Description
        {
            get
            {
                return "Adobe Acrobat PDF";
            }
        }

        public virtual string[] SupportedExtensions
        {
            get
            {
                return new string[] { "pdf" };
            }
        }

        public virtual string FilePath
        {
            get
            {
                return _FilePath;
            }
            set
            {
                if (string.Compare(_FilePath, value, true) != 0)
                {
                    _FilePath = value;
                    _PageCount = -1;
                }
            }
        }

        public int PageCount
        {
            get
            {
                if (_PageCount < 0)
                {
                    ReadFile();
                }
                return _PageCount;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return _ErrorMessage;
            }
        }

        internal void ExportToTIFF(string pdfPath, string tifPath)
        {
            FilePath = pdfPath;
            var pageCount = PageCount;
            if (_Reader != null)
            {
                var tiffEncoder = ImageCodecInfo.GetImageEncoders().Where(p => p.FormatDescription.Equals("TIFF")).FirstOrDefault();
                System.Drawing.Bitmap tifImage = null;
                int imageCount = 0;
                for (int i = 1; i <= pageCount; i++)
                {
                    _CTMS.Clear();
                    _Rotation = 0;
                    _MaxWidth = 0;
                    _MaxHeight = 0;
                    _StackCTM.Clear();
                    _StackFontSize.Clear();
                    _ExistingOperators.Clear();
                    _TextCount = 0;
                    _Operators = new StringBuilder();
                    _PageRect = _Reader.GetPageSize(i);
                    _Rotation = _Reader.GetPageRotation(i);

                    if (_Rotation > 0)
                    {
                        _PageRect = _Reader.GetPageSizeWithRotation(i);
                    }

                    IRenderListener listener = this;
                    PdfContentStreamProcessor processor = new PdfContentStreamProcessor(listener);

                    PdfDictionary page = _Reader.GetPageN(i);
                    PdfDictionary resourcesDic = page.GetAsDict(PdfName.RESOURCES);
                    var bytes = _Reader.GetPageContent(i);
                    var allBytes = ContentByteUtils.GetContentBytesForPage(_Reader, i);
                    processor.ProcessContent(allBytes, resourcesDic);
                    if (_CTMS.Count() > 0)
                    {
                        var mergedImage = _CTMS.MergeImages(_Rotation, _PageRect.Height, true, ref _ScaleWidth, ref _ScaleHeight);
                        //==============
                        //mergedImage = ImageUtils.CropUnwantedBackground(mergedImage);
                        //==============

                        _CTMS.Clear();
                        GC.Collect();

                        if (tifImage == null)
                        {
                            tifImage = mergedImage;
                        }
                        else
                        {
                            var eps = new EncoderParameters(1);
                            if (imageCount == 1)
                            {
                                eps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)EncoderValue.MultiFrame);
                                tifImage.Save(tifPath, tiffEncoder, eps);
                            }
                            eps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)EncoderValue.FrameDimensionPage);
                            tifImage.SaveAdd(mergedImage, eps);
                            mergedImage.Dispose();
                            GC.Collect();
                        }
                        imageCount++;
                    }
                }
                if (imageCount == 1)
                {
                    File.Delete(tifPath);
                    tifImage.SaveAsTiff(tifPath);
                }
                else if (imageCount > 1)
                {
                    var epsx = new EncoderParameters(1);
                    epsx.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)EncoderValue.Flush);
                    tifImage.SaveAdd(epsx);
                }
                if (tifImage != null)
                {
                    tifImage.Dispose();
                    GC.Collect();
                }
            }
        }

        private void RegisterContentOperator(PdfContentStreamProcessor processor, string operCode)
        {
            _ExistingOperators[operCode] = processor.RegisterContentOperator(operCode, this);
        }

        private void RegisterAllContentOperators(PdfContentStreamProcessor processor)
        {
            RegisterContentOperator(processor, PDFOperators.BeginCompatibilitySection);
            RegisterContentOperator(processor, PDFOperators.BeginInlineImage);
            RegisterContentOperator(processor, PDFOperators.BeginMarkedContent);
            RegisterContentOperator(processor, PDFOperators.BeginMarkedContentSequence);
            RegisterContentOperator(processor, PDFOperators.BeginText);
            RegisterContentOperator(processor, PDFOperators.BezierC);
            RegisterContentOperator(processor, PDFOperators.BezierV);
            RegisterContentOperator(processor, PDFOperators.BezierY);
            RegisterContentOperator(processor, PDFOperators.CharacterSpacing);
            RegisterContentOperator(processor, PDFOperators.Clear);
            RegisterContentOperator(processor, PDFOperators.ClippingPathEvenOdd);
            RegisterContentOperator(processor, PDFOperators.ClippingPathNonZero);
            RegisterContentOperator(processor, PDFOperators.Close);
            RegisterContentOperator(processor, PDFOperators.CloseFillStrokeEvenOdd);
            RegisterContentOperator(processor, PDFOperators.CloseFillStrokeNonZero);
            RegisterContentOperator(processor, PDFOperators.CMYKNonStroking);
            RegisterContentOperator(processor, PDFOperators.CMYKStroking);
            RegisterContentOperator(processor, PDFOperators.ColorNonStroking);
            RegisterContentOperator(processor, PDFOperators.ColorRenderingIntent);
            RegisterContentOperator(processor, PDFOperators.ColorSpaceNonStroking);
            RegisterContentOperator(processor, PDFOperators.ColorSpaceStroking);
            RegisterContentOperator(processor, PDFOperators.ColorStroking);
            RegisterContentOperator(processor, PDFOperators.DefineMarkedContent);
            RegisterContentOperator(processor, PDFOperators.EndCompatibilitySection);
            RegisterContentOperator(processor, PDFOperators.EndInlineImage);
            RegisterContentOperator(processor, PDFOperators.EndMarkedContentSequence);
            RegisterContentOperator(processor, PDFOperators.EndText);
            RegisterContentOperator(processor, PDFOperators.FillEvenOdd);
            RegisterContentOperator(processor, PDFOperators.FillPathNonZero);
            RegisterContentOperator(processor, PDFOperators.FillPathNonZeroObsolete);
            RegisterContentOperator(processor, PDFOperators.FillStrokeEvenOdd);
            RegisterContentOperator(processor, PDFOperators.FillStrokeNonZero);
            RegisterContentOperator(processor, PDFOperators.GlyphWidthBoundingBoxFontType3);
            RegisterContentOperator(processor, PDFOperators.GlyphWidthFontType3);
            RegisterContentOperator(processor, PDFOperators.GraphicsState);
            RegisterContentOperator(processor, PDFOperators.GreyNonStroke);
            RegisterContentOperator(processor, PDFOperators.GreyStroke);
            RegisterContentOperator(processor, PDFOperators.ICCNonStroking);
            RegisterContentOperator(processor, PDFOperators.ICCStroking);
            RegisterContentOperator(processor, PDFOperators.ImageDataBegin);
            RegisterContentOperator(processor, PDFOperators.InvokeXObject);
            RegisterContentOperator(processor, PDFOperators.Line);
            RegisterContentOperator(processor, PDFOperators.LineCapStyle);
            RegisterContentOperator(processor, PDFOperators.LineDashPattern);
            RegisterContentOperator(processor, PDFOperators.LineJoinStyle);
            RegisterContentOperator(processor, PDFOperators.LineWidth);
            RegisterContentOperator(processor, PDFOperators.MarkedContentPoint);
            RegisterContentOperator(processor, PDFOperators.MiterLimit);
            RegisterContentOperator(processor, PDFOperators.Move);
            RegisterContentOperator(processor, PDFOperators.MoveTextPositionSetLeading);
            RegisterContentOperator(processor, PDFOperators.MoveTextPostion);
            RegisterContentOperator(processor, PDFOperators.MoveToNextLine);
            RegisterContentOperator(processor, PDFOperators.MoveToNextLineShowText);
            RegisterContentOperator(processor, PDFOperators.Rectangle);
            RegisterContentOperator(processor, PDFOperators.RestoreGraphicsState);
            RegisterContentOperator(processor, PDFOperators.RGBNonStroking);
            RegisterContentOperator(processor, PDFOperators.RGBStroking);
            RegisterContentOperator(processor, PDFOperators.SaveGraphicsState);
            RegisterContentOperator(processor, PDFOperators.SetFlat);
            RegisterContentOperator(processor, PDFOperators.ShadingPattern);
            RegisterContentOperator(processor, PDFOperators.ShowText);
            RegisterContentOperator(processor, PDFOperators.ShowTextGlyphPosition);
            RegisterContentOperator(processor, PDFOperators.Stroke);
            RegisterContentOperator(processor, PDFOperators.StrokeAfterClose);
            RegisterContentOperator(processor, PDFOperators.TextAndTextLineMatrix);
            RegisterContentOperator(processor, PDFOperators.TextFont);
            RegisterContentOperator(processor, PDFOperators.TextHScaling);
            RegisterContentOperator(processor, PDFOperators.TextLeading);
            RegisterContentOperator(processor, PDFOperators.TextRenderingMode);
            RegisterContentOperator(processor, PDFOperators.TextRise);
            RegisterContentOperator(processor, PDFOperators.TextWordSpacing);
            RegisterContentOperator(processor, PDFOperators.TransformationMatrixConcat);
            RegisterContentOperator(processor, PDFOperators.WordCharacterSpacing);

        }

        public void RenderPage(int pageNo, Canvas canvas, MainWindow window, string unskewImages, int imageColor, bool automate = false)
        {
            if (_Reader != null)
            {
                _LastTR = null;
                _UnskewImages = unskewImages;
                _ImageColor = imageColor;
                _Window = window;
                _Canvas = canvas;
                _PathDrawing = new PDFPathDrawing(window);
                _CTMS.Clear();
                _Rotation = 0;
                _MaxWidth = 0;
                _MaxHeight = 0;
                _ScaleWidth = 0;
                _ScaleHeight = 0;
                _CurrentCTM = null;
                _CurrentTextCTM = null;
                _StackCTM.Clear();
                _StackFontSize.Clear();
                _ExistingOperators.Clear();
                _TextCount = 0;
                _Operators = new StringBuilder();
                _PageRect = _Reader.GetPageSize(pageNo);
                _Rotation = _Reader.GetPageRotation(pageNo);
                _PdfTexts.Clear();

                if (_Rotation > 0)
                {
                    _PageRect = _Reader.GetPageSizeWithRotation(pageNo);
                }

                PdfDictionary page = _Reader.GetPageN(pageNo);
                var bytes = _Reader.GetPageContent(pageNo);
                var allBytes = ContentByteUtils.GetContentBytesForPage(_Reader, pageNo);
                _Window.SetPageSize(_PageRect.Width, _PageRect.Height);

                IRenderListener listener = this;
                PdfContentStreamProcessor processor = new PdfContentStreamProcessor(listener);

                RegisterAllContentOperators(processor);

                processor.RegisterXObjectDoHandler(PdfName.DEFAULT, this);
                PdfDictionary resourcesDic = page.GetAsDict(PdfName.RESOURCES);

                processor.ProcessContent(allBytes, resourcesDic);
                double maxWidth = Math.Max(_Window.PageWidth, _MaxWidth);
                maxWidth = _MaxWidth; // take image width over page width
                double maxHeight = Math.Max(_Window.PageHeight, _MaxHeight);
                if (_Rotation == 90 || _Rotation == 270)
                {
                    maxHeight = _MaxHeight;
                }
                _Window.PopulateTextCollection(_PdfTexts.Values);
                _PdfTexts.Clear();
                _Window.TextExists = _TextCount > 50;
                _Window.DrawingPaths = _PathDrawing.DrawingPaths;

                if (!automate)
                {
                    if (_CTMS.Count() == 0)
                    {
                        _Window.RenderTextImage();
                    }
                    else
                    {
                        var mergedImage = _CTMS.MergeImages(_Rotation, _Window.PageHeight, true, ref _ScaleWidth, ref _ScaleHeight);
                        _CTMS.Clear();
                        GC.Collect();

                        if (ImageUtils.Flip(mergedImage, _Window.ImageFlip))
                        {
                            Utils.Swap(ref _ScaleWidth, ref _ScaleHeight);
                            _Window.SetPageSize(_Window.PageHeight, _Window.PageWidth);
                        }

                        var unskew = Constants.DESKEWREGULAR.Equals(_UnskewImages);
                        if (_Window.TextExists)
                        {
                            unskew = false;
                        }

                        var tmp = ImageUtils.ResizeAndDeSkewImage(mergedImage, unskew, _ImageColor, mergedImage.Width, mergedImage.Height);
                        mergedImage.Dispose(); // Releasing memory
                        GC.Collect();
                        mergedImage = tmp;

                        tmp = ImageUtils.ApplyEnhancements(mergedImage, window.ImageOptions);
                        if (tmp != mergedImage)
                        {
                            mergedImage.Dispose();
                            GC.Collect();
                        }
                        mergedImage = tmp;

                        // this resize is to make the ratio of original image with the pdf page setting if applicable
                        if (_ScaleWidth > 0 && _ScaleHeight > 0)
                        {
                            double bratio = (double)mergedImage.Width / mergedImage.Height;
                            double iratio = (double)_ScaleWidth / _ScaleHeight;
                            double dratio = Math.Abs((double)bratio - iratio);
                            if (dratio > 0.1 && iratio > 0d && _ScaleHeight != mergedImage.Height && _ScaleWidth != mergedImage.Width)
                            {
                                double newwidth = mergedImage.Width;
                                double newheight = newwidth / iratio;
                                if (mergedImage.Height > mergedImage.Width)
                                {
                                    newheight = mergedImage.Height;
                                    newwidth = newheight / iratio;
                                }
                                var tmpImage = ImageUtils.ResizeImage(mergedImage, newwidth, newheight);
                                if (tmpImage != mergedImage)
                                {
                                    mergedImage.Dispose();
                                    GC.Collect();
                                }
                                mergedImage = tmpImage;
                            }
                        }


                        ImageAction[] actions = null;
                        if (Constants.DESKEWCUSTOM.Equals(_UnskewImages))
                        {
                            var deskewInfo = _Window.DeskewInfo;
                            if (deskewInfo != null && _ScaleWidth > 0 && _ScaleHeight > 0)
                            {
                                deskewInfo = deskewInfo.Scaled((double)mergedImage.Width / _ScaleWidth, (double)mergedImage.Height / _ScaleHeight);
                            }
                            actions = ImageUtils.DeSkewImageInBlocks(mergedImage, deskewInfo, pageNo, _Window.CurrentPageActions);
                        }
                        _Window.ImageExists = true;
                        _Window.SetImageActionsForPage(actions, pageNo);
                        _Window.SetImage(mergedImage, _ScaleWidth, _ScaleHeight);
                    }
                }                

                try
                {

                    if (automate)
                        File.WriteAllText(System.IO.Path.Combine(_Window.WorkingPath, "DebugPDFOperators.txt"), _Operators.ToString());//$"DebugPDFOperators{pageNo}.txt"
                    else
                        File.WriteAllText(System.IO.Path.Combine(_Window.WorkingPath, "DebugPDFOperators.txt"), _Operators.ToString());
                }
                catch
                {
                }
            }
        }


        bool _IsBelow1_4 = false;

        private void ReadFile()
        {
            if (!string.IsNullOrWhiteSpace(FilePath))
            {
                byte[] data = File.ReadAllBytes(FilePath);
                byte version4 = (byte)'4';
                if (data[7] < version4)
                {
                    _IsBelow1_4 = true;
                }
                _Reader = new PdfReader(data);
                _PageCount = _Reader.NumberOfPages;
            }
        }

        public void BeginTextBlock()
        {
        }

        public void EndTextBlock()
        {
        }

        public void RenderImage(ImageRenderInfo renderInfo)
        {
            if (renderInfo != null)
            {
                var imageType = "";
                try
                {
                    var image = renderInfo.GetImage();
                    try
                    {
                        imageType = image.GetFileType();
                    }
                    catch
                    {
                    }
                    //File.WriteAllBytes("ctm." + image.GetFileType(), image.GetImageAsBytes());
                    var draw = image.GetDrawingImage();
                    var matrix = renderInfo.GetImageCTM();

                    PDFImageCtm ctm = new PDFImageCtm(matrix, draw, _Rotation, _PageRect.Height);
                    ctm.AdjustActualSize(ref _MaxWidth, ref _MaxHeight);
                    ctm.AdjustScaleSize(ref _ScaleWidth, ref _ScaleHeight);

                    _Operators.AppendLine("Image " + matrix);
                    _CTMS.Add(ctm);
                }
                catch (Exception ex)
                {
                    if ("JBIG2".Equals(imageType, StringComparison.InvariantCultureIgnoreCase))
                    {
                        MessageBox.Show("This PDF file contains JBIG2 type image files. These files are not supported and will be ignored.", "Warning", MessageBoxButton.OK);
                    }
                    else
                    {
                        MessageBox.Show("Failed to show embeded image in the file .", "Warning", MessageBoxButton.OK);
                    }
                    ex.LogException();
                }
            }
        }

        public void RenderText(TextRenderInfo renderInfo)
        {
            if (_Window == null || renderInfo == null || renderInfo.GetTextRenderMode() == 3)
            {
                return;
            }
            var adjustedFontSize = 1d;
            if (_FontSize > 1)
            {
                adjustedFontSize = AdjustedFontSize();
            }
            string alternateFont = "";            
            if (string.IsNullOrWhiteSpace(alternateFont))
            {
                alternateFont = "Arial";
            }
            var pdfTextRect = renderInfo.ToPDFTextRect(_IsBelow1_4, _PageRect, _Window.PageHeight, alternateFont, adjustedFontSize, _PathDrawing.CurrentStroke, _PathDrawing.CurrentNonStroke, _PathDrawing.CurrentTextMode);
            var text = renderInfo.GetText();

            var charRects = renderInfo.GetCharacterTextRects(_Unicode, _IsBelow1_4, _PageRect, _Window.PageHeight, alternateFont, adjustedFontSize, _PathDrawing.CurrentStroke, _PathDrawing.CurrentNonStroke, _PathDrawing.CurrentTextMode);
            if (charRects != null)
            {
                foreach (var charRect in charRects)
                {
                    RenderEachText(charRect, text);
                }
                _TextCount += charRects.Count();
            }
            else
            {
                _TextCount++;
            }

        }

        private void RenderEachText(PDFTextRect pdfTextRect, string fullText)
        {
            if (_Window == null || pdfTextRect == null || pdfTextRect.Left < 0)
            {
                return;
            }
            var xyCo = new XYCo();
            xyCo.X = pdfTextRect.Left;
            xyCo.Y = pdfTextRect.Top;


            try
            {                
                if (_PdfTexts.ContainsKey(xyCo))
                {
                    if (_PdfTexts[xyCo].Text == string.Empty && pdfTextRect.Text != string.Empty)
                        _PdfTexts[xyCo] = pdfTextRect;
                }
                else
                    _PdfTexts[xyCo] = pdfTextRect;
            }
            catch (Exception ex)
            {
                //_PdfTexts[xyCo] = pdfTextRect;
            }

            TextBlock tb = new TextBlock();
            string text = pdfTextRect.Text;
            if (string.IsNullOrEmpty(text))
            {
                text = _Unicode;
            }
            tb.Text = text;
            var fontName = pdfTextRect.FontFamily;
            var fontSize = pdfTextRect.FontSize;
            if (!string.IsNullOrWhiteSpace(fontName))
            {
                if (pdfTextRect.Width < 0)
                {
                    _LastTR = null;
                    tb.RenderTransform = new RotateTransform(270);
                }

                tb.FontFamily = new System.Windows.Media.FontFamily(fontName);                
                if (Math.Abs(fontSize) <= pdfTextRect.Width)
                {
                    tb.FontSize = Math.Abs(fontSize);
                }
                else
                {
                    var fs = Math.Floor(Math.Abs(fontSize)) - 1;
                    if (fs <= 0)
                    {
                        fs = Math.Abs(fontSize);
                    }
                    tb.FontSize = fs;
                }
                if (pdfTextRect.IsBold)
                {
                    tb.FontWeight = FontWeights.Bold;
                }
            }
            if (_LastTR != null && _LastTR.FontSize > pdfTextRect.FontSize)
            {
                if ((_LastTR.Top.Between(pdfTextRect.Top, pdfTextRect.Bottom, false) || _LastTR.Bottom.Between(pdfTextRect.Top, pdfTextRect.Bottom, false)) && (double)2 >= ((double)pdfTextRect.Left - _LastTR.Right))
                {
                    pdfTextRect.FontSize = _LastTR.FontSize;
                    pdfTextRect.ActualTop = pdfTextRect.Top;
                    pdfTextRect.Top = _LastTR.Top;
                }

            }
            Canvas.SetLeft(tb, pdfTextRect.Left);
            Canvas.SetTop(tb, pdfTextRect.Top);
            Canvas.SetZIndex(tb, 10);
            tb.Tag = pdfTextRect;
            _LastTR = pdfTextRect;
        }

        public iTextSharp.text.Rectangle GetTextRect(TextRenderInfo renderInfo)
        {
            var baseLine = renderInfo.GetBaseline();
            var bottomLeft = baseLine.GetStartPoint();

            var ascentLine = renderInfo.GetAscentLine();


            if (float.IsNaN(ascentLine.GetStartPoint()[0]) || float.IsNaN(ascentLine.GetEndPoint()[0]))
            {
                var BaseLineStart = bottomLeft;
                var BaseLineEnd = baseLine.GetEndPoint();

                var AscendLineStart = new iTextSharp.text.pdf.parser.Vector(BaseLineStart[0], BaseLineStart[1] + 8, 1);
                var AscendLineEnd = new iTextSharp.text.pdf.parser.Vector(BaseLineEnd[0], BaseLineEnd[1] + 8, 1);

                ascentLine = new iTextSharp.text.pdf.parser.LineSegment(AscendLineStart, AscendLineEnd);
            }

            var topRight = ascentLine.GetEndPoint();
            var textRect = new iTextSharp.text.Rectangle(bottomLeft[iTextSharp.text.pdf.parser.Vector.I1], bottomLeft[iTextSharp.text.pdf.parser.Vector.I2], topRight[iTextSharp.text.pdf.parser.Vector.I1], topRight[iTextSharp.text.pdf.parser.Vector.I2]);
            return textRect;
        }


        private List<PdfObject> RotateOperands(List<PdfObject> operands)
        {
            if (_Rotation == 90 || _Rotation == 270)
            {
                if (operands != null && operands.Count() > 5)
                {
                    var tmp = new List<PdfObject>();
                    tmp.Add(operands[3]);
                    tmp.Add(operands[2]);
                    tmp.Add(operands[1]);
                    tmp.Add(operands[0]);
                    tmp.Add(operands[5]);
                    tmp.Add(operands[4]);
                    var num = new PdfNumber((double)_PageRect.Height - PDFUtils.OperandToDouble(operands, 4));
                    return tmp;
                }
            }
            return operands;
        }

        string _Unicode;

        // IContentOperator
        public void Invoke(PdfContentStreamProcessor processor, PdfLiteral oper, List<PdfObject> operands)
        {
            _Unicode = "";
            var rotatedOperands = RotateOperands(operands);
            bool invoked = true;
            string operCode = "";
            if (oper != null)
            {
                operCode = oper.ToString();
            }
            switch (operCode)
            {
                case PDFOperators.ShowText:
                case PDFOperators.ShowTextGlyphPosition:
                    foreach (var operx in operands)
                    {
                        if (operx is PdfString)
                        {
                            var strOper = (PdfString)operx;
                            var sb = new StringBuilder();
                            byte[] bytes = strOper.GetBytes();
                            for (int i = 0; i < bytes.Length; i += 2)
                            {
                                if ((i + 1) < bytes.Length)
                                {
                                    // each character code is 2 bytes in size
                                    // we skip the first byte, assuming it is 00
                                    int charcode = bytes[i + 1];
                                    sb.Append((char)(charcode + 29));
                                }
                            }
                            _Unicode = sb.ToString();
                        }
                    }
                    break;

                case PDFOperators.TransformationMatrixConcat:
                    if (_CurrentCTM == null)
                    {
                        _CurrentCTM = new PDFCtm(rotatedOperands);
                    }
                    else
                    {
                        _CurrentCTM.Concat(rotatedOperands);
                        _Operators.AppendLine("CTM changed to " + _CurrentCTM.ScaleX + " " + _CurrentCTM.SkewX + " " + _CurrentCTM.SkewY + " " + _CurrentCTM.ScaleY + " " + _CurrentCTM.X + " " + _CurrentCTM.Y);
                    }
                    break;

                case PDFOperators.BeginText:
                    break;

                case PDFOperators.EndText:
                    _CurrentTextCTM = null;
                    break;

                case PDFOperators.TextAndTextLineMatrix:
                    _CurrentTextCTM = new PDFCtm(rotatedOperands);
                    break;

                case PDFOperators.TextHScaling:
                    break;

                case PDFOperators.SaveGraphicsState:
                    if (_CurrentCTM != null)
                    {
                        _StackCTM.Push(_CurrentCTM.Copy());
                    }
                    _StackFontSize.Push(_FontSize);
                    _PathDrawing.SaveGraphicsState();
                    break;

                case PDFOperators.RestoreGraphicsState:
                    if (_StackCTM.Count() > 0)
                    {
                        _CurrentCTM = _StackCTM.Pop();
                        _Operators.AppendLine("CTM restored to " + _CurrentCTM.ScaleX + " " + _CurrentCTM.SkewX + " " + _CurrentCTM.SkewY + " " + _CurrentCTM.ScaleY + " " + _CurrentCTM.X + " " + _CurrentCTM.Y);
                    }
                    else
                    {
                        _CurrentCTM = null;
                        _Operators.AppendLine("CTM restored to null");
                    }
                    if (_StackFontSize.Count() > 0)
                    {
                        _FontSize = _StackFontSize.Pop();
                    }
                    _PathDrawing.RestoreGraphicsState();
                    break;

                case PDFOperators.TextFont:
                    _FontSize = PDFUtils.OperandToDouble(operands, 1);
                    break;

                default:
                    var hide = false;
                    if (_Window != null)
                    {                        
                    }
                    invoked = _PathDrawing.Invoke(oper, operands, _CurrentCTM, _Rotation, _PageRect.Height, hide);
                    break;
            }

            if (_ExistingOperators.ContainsKey(operCode))
            {
                if (_ExistingOperators[operCode] != null)
                {
                    _ExistingOperators[operCode].Invoke(processor, oper, operands);
                }
            }

            if (invoked)
            {
                _Operators.Append("[exec]");
            }
            else
            {
                _Operators.Append("[    ]");
            }
            _Operators.Append(oper);
            _Operators.Append(" :");
            foreach (var pdfO in rotatedOperands)
            {
                _Operators.Append(" ");
                _Operators.Append(pdfO);
            }
            _Operators.AppendLine("");
            return;
        }
        

        private double GetFontScale()
        {
            System.Drawing.Drawing2D.Matrix m = null;
            if (_CurrentCTM != null)
            {
                m = _CurrentCTM.ToMatrix();
            }
            if (_CurrentTextCTM != null)
            {
                if (m != null)
                {
                    m.Multiply(_CurrentTextCTM.ToMatrix());
                }
                else
                {
                    m = _CurrentTextCTM.ToMatrix();
                }
            }
            if (m == null)
            {
                return 1;
            }
            return Math.Sqrt((m.Elements[1] * m.Elements[1]) + (m.Elements[3] * m.Elements[3]));
        }

        private double AdjustedFontSize()
        {
            double fontSize = _FontSize;
            _Operators.Append("Return  [FontSize: " + fontSize);

            var fontScale = GetFontScale();
            return fontSize * fontScale;

            if (_CurrentTextCTM != null)
            {
                _Operators.Append(" Text ScaleX/ScaleY: " + _CurrentTextCTM.ScaleX + "/" + _CurrentTextCTM.ScaleY);
                if (_CurrentTextCTM.ScaleX > 0)
                {
                    fontSize = fontSize * _CurrentTextCTM.ScaleX;
                }
            }
            if (_CurrentCTM != null && _CurrentCTM.ScaleX > 0)
            {
                _Operators.Append(" ScaleX/ScaleY: " + _CurrentCTM.ScaleX + "/" + _CurrentCTM.ScaleY);
                fontSize = fontSize * _CurrentCTM.ScaleX;
            }
            _Operators.AppendLine(" ReturnValue: " + fontSize);
            return fontSize;
        }

        public void HandleXObject(PdfContentStreamProcessor processor, PdfStream stream, PdfIndirectReference refi, ICollection markedContentInfoStack)
        {
            //throw new NotImplementedException();
        }

        // IXObjectDoHandler
        public void HandleXObject(PdfContentStreamProcessor processor, PdfStream stream, PdfIndirectReference refi)
        {

        }
    }
}