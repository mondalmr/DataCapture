﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataCapture
{
    /// <summary>
    /// In most case the highlight region is a rectangle. However, when using PackageGrid
    /// there is a possibility that Marks and Numbers or Goods Description could overflow to 
    /// adjacent columns on the right. To handle this, highlight region has an insetwidth and
    /// insetheight property. What this means the highlight region will include the adjacent
    /// columns but it will inset out the top right section of the rectangle.
    /// 
    /// During OCR, the image on the top right is whited out
    /// </summary>
    public class HighlightRegion
    {
        public HighlightRegion()
        {
        }

        public HighlightRegion(Rect rect)
            : this(rect.Left, rect.Top, rect.Width, rect.Height, 0, 0)
        {
        }

        public HighlightRegion(double left, double top, double width, double height, double insetWidth = 0d, double insetHeight = 0d)
        {
            Left = left;
            Top = top;
            Width = width;
            Height = height;
            InsetWidth = insetWidth;
            InsetHeight = insetHeight;
        }

        public double Left
        {
            get;
            set;
        }

        public double Top
        {
            get;
            set;
        }

        public double Width
        {
            get;
            set;
        }

        public double Height
        {
            get;
            set;
        }

        public double InsetWidth
        {
            get;
            set;
        }

        public double InsetHeight
        {
            get;
            set;
        }

        /// <summary>
        /// Checks if any part intersects with specified value. Special handling for
        /// Marks and Nos and Goods Description which could span to the column(s) on the right
        /// </summary>
        /// <param name="highlightRegion"></param>
        /// <returns></returns>
        public bool IntersectsWith(HighlightRegion highlightRegion)
        {
            var intersects = false;
            if (highlightRegion != null)
            {
                var rect = new Rect(Left, Top, Width, Height);
                var highlightRect = new Rect(highlightRegion.Left, highlightRegion.Top, highlightRegion.Width, highlightRegion.Height);
                intersects = rect.IntersectsWith(highlightRect);
                if (intersects)
                {
                    // Special logic to check for intersect
                    /*
                    if (InsetWidth > 0 && InsetHeight > 0)
                    {
                        var insetRect = GetInsetRect();
                        if (insetRect.IntersectsWith(highlightRect))
                        {
                            intersects = false;
                        }
                    }
                    */
                }
            }
            return intersects;
        }

        /// <summary>
        /// Updates the region with intersection of specified value
        /// </summary>
        /// <param name="highlightRegion"></param>
        public void Intersect(HighlightRegion highlightRegion)
        {
            var rect = new Rect(Left, Top, Width, Height);
            var highlightRect = new Rect(highlightRegion.Left, highlightRegion.Top, highlightRegion.Width, highlightRegion.Height);
            rect.Intersect(highlightRect);
            Left = rect.Left;
            Top = rect.Top;
            Width = rect.Width;
            Height = rect.Height;
        }

        public Rect GetInsetRect()
        {
            return new Rect(Width - InsetWidth, 0, InsetWidth, InsetHeight);
        }
    }
}
