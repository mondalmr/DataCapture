﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;


namespace DataCapture
{
  
    
    public static class MSOfficeUtils
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]//AS15024 
        static extern int GetWindowThreadProcessId(IntPtr hWnd, out int processId); //AS15024 

        public static string MSExcelToPdf(string sourceFilePath, string targetFilePath)
        {
            string message = "";
            Excel.Application ms = new Excel.Application();
            int hwnd = ms.Hwnd;//AS15024 
            int processId;//AS15024 
            GetWindowThreadProcessId((IntPtr)hwnd, out  processId);//AS15024 

            Excel.Workbook wb = null;
            Excel.Range range = null; //AS15024 
            try
            {
                wb = ms.Workbooks.Open(Filename: sourceFilePath, ReadOnly: true);

                foreach (Excel._Worksheet ws in wb.Sheets)
                {
                    range = ws.UsedRange;
                    //range.Font.Name = "Arial";
                    double minFontSize = GetMinFontSizeForExcel(range);

                    try
                    {
                        range.Font.Size = minFontSize;
                        range.VerticalAlignment = Excel.XlVAlign.xlVAlignBottom;
                        //range.HorizontalAlignment = Excel.XlHAlign.xlHAlignGeneral;

                        //range.Font.Size=11;
                        //range.Font.Name = "Arial";

                    //    //range.Columns.AutoFit();
                    }
                    catch (Exception)
                    {

                    }
                }

                var activeSheet = wb.ActiveSheet;
                if (activeSheet != null)
                {
                    var pageSetup = activeSheet.PageSetup;
                    if (pageSetup != null)
                    {
                        pageSetup.TopMargin = 0;
                        pageSetup.LeftMargin = 0;
                        pageSetup.RightMargin = 0;
                        pageSetup.BottomMargin = 0; 
                        
                        pageSetup.Zoom = false;
                        pageSetup.FitToPagesWide = 1;
                    }
                }
                //
               

                wb.ExportAsFixedFormat(Type: Excel.XlFixedFormatType.xlTypePDF, Filename: targetFilePath, IgnorePrintAreas: false);
            }
            catch
            {
                message = "Failed to open file " + sourceFilePath;
            }
            finally
            {
                if (wb != null)
                {
                    
                    wb.Close(SaveChanges: false);
                }
                if (ms != null)
                {
                    ms.Application.Quit();
                }
                try
                {
                    if (processId != 0)
                        System.Diagnostics.Process.GetProcessById((int)processId).Kill();
                }
                catch
                { 
                }
            }
            return message;
        }

        public static string MSWordToPdf(string sourceFilePath, string targetFilePath)
        {
            string message = "";
            Word.Application ms = new Word.Application();
            Word.Document doc = null;
            try
            {
                doc = ms.Documents.Open(FileName: sourceFilePath, ConfirmConversions: false, ReadOnly: true, AddToRecentFiles: false);
                doc.ExportAsFixedFormat(OutputFileName: targetFilePath, ExportFormat: Word.WdExportFormat.wdExportFormatPDF, OptimizeFor: Word.WdExportOptimizeFor.wdExportOptimizeForOnScreen, BitmapMissingFonts: false);
            }
            catch
            {
                message = "Failed to open file " + sourceFilePath;
            }
            finally
            {
                if (doc != null)
                {
                    doc.Close();
                }
            }
            return message;
        }

        //AS15024 
        private static double GetMinFontSizeForExcel(Excel.Range range)
        {

            double minFontSize = 10;//8;
            double fontSize = 0;

            for (int rCnt = 1; rCnt <= range.Rows.Count; rCnt++)
            {
                for (int cCnt = 1; cCnt <= range.Columns.Count; cCnt++)
                {
                    try
                    {
                        fontSize = range.Cells[rCnt, cCnt].Font.Size;
                    }
                    catch (Exception)
                    {
                        fontSize = minFontSize;
                    }
                    minFontSize = (fontSize < minFontSize) ? fontSize : minFontSize;
                }
            }
            //if (minFontSize < 8) minFontSize = 8;
            return minFontSize;
        }
    }
}
