﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class DataCaptureElement
    {
        internal List<FrameworkElement> _Rectangles;

        public DataCaptureElement(DataCaptureElementType blElementType, string name, Color color, RadioButton widget = null, string menuName = "CMDefault", string inputGestureText = "")
        {
            X = double.NaN;
            Y = double.NaN;
            Width = double.NaN;
            Height = double.NaN;
            _Rectangles = new List<FrameworkElement>();
            DCElementType = blElementType;
            Name = name;
            Color = color;
            MenuName = menuName;
            Widget = widget;
            InputGestureText = inputGestureText;
        }

        public string InputGestureText
        {
            get;
            set;
        }

        public DataCaptureElementType DCElementType
        {
            get;
            set;
        }

        public string MenuName
        {
            get;
            set;
        }

        public RadioButton Widget
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public Color Color
        {
            get;
            set;
        }

        public double X
        {
            get;
            set;
        }

        public double Y
        {
            get;
            set;
        }

        public double Width
        {
            get;
            set;
        }

        public double Height
        {
            get;
            set;
        }

        public int Page
        {
            get;
            set;
        }

        public FrameworkElement GetRectangle(int pageNo)
        {
            if (pageNo >= 0 && _Rectangles != null && _Rectangles.Count > pageNo)
            {
                return _Rectangles[pageNo];
            }
            return null;
        }

        public void ClearRectangles()
        {
            if (_Rectangles != null)
            {
                _Rectangles.Clear();
            }
        }


        public void SetRectangle(int pageNo, FrameworkElement rectangle)
        {
            int len = _Rectangles.Count();
            for (int i = len; i <= pageNo; i++)
            {
                _Rectangles.Add(null);
            }
            _Rectangles[pageNo] = rectangle;
        }

        public bool AcceptsNewLine()
        {
            bool accepts = true;
            switch (DCElementType)
            {
                case DataCaptureElementType.ChallanNo:
                //case DataCaptureElementType.PackageCount:
                //case DataCaptureElementType.PackageMeasure:
                //case DataCaptureElementType.PackageMeasureUM:
                //case DataCaptureElementType.PackageType:
                //case DataCaptureElementType.PackageWeight:
                //case DataCaptureElementType.PackageWeightUM:
                case DataCaptureElementType.SectionCode:
                case DataCaptureElementType.TAN:
                case DataCaptureElementType.AssessmentYear:
                case DataCaptureElementType.TDS:
                case DataCaptureElementType.Surcharge:
                case DataCaptureElementType.EducationCess:
                case DataCaptureElementType.Interest:
                case DataCaptureElementType.Fee:
                case DataCaptureElementType.Others:
                case DataCaptureElementType.TotalTax:
                case DataCaptureElementType.BranchCode:
                case DataCaptureElementType.BankName:
                case DataCaptureElementType.DepositDate:
                case DataCaptureElementType.MinorHead:
                case DataCaptureElementType.CertAckNo:
                case DataCaptureElementType.CertDate:
                case DataCaptureElementType.PANNo:
                case DataCaptureElementType.CertName:
                    //case DataCaptureElementType.Remarks:
                    accepts = false;
                    break;
            }
            return accepts;
        }

        public Brush GetBorderBrush()
        {
            return new SolidColorBrush(Color);
        }

        public Brush GetFillBrush(bool useFill)
        {
            if (useFill)
            {
                var brush = new SolidColorBrush(Color);
                if (DCElementType == DataCaptureElementType.PackageGrid)
                {
                    brush.Opacity = 0.2;
                }
                else
                {
                    brush.Opacity = 0.4;
                }
                return brush;
            }
            else
            {
                return Brushes.Transparent;
            }
        }

        public void UpdateBrushes(bool useFill)
        {
            if (_Rectangles != null)
            {
                var border = GetBorderBrush();
                var fill = GetFillBrush(useFill);
                foreach (var element in _Rectangles)
                {
                    var rectangle = element as Rectangle;
                    if (rectangle != null)
                    {
                        rectangle.Stroke = border;
                        rectangle.Fill = fill;
                    }
                    Control control = element as Grid;
                    if (control != null)
                    {
                        control.BorderBrush = border;
                        control.Background = fill;
                    }
                }
            }
        }

    }
}
