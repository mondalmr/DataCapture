﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for ReplacementEditor.xaml
    /// </summary>
    public partial class ReplacementEditor : Window
    {
        public ReplacementEditor()
        {
            InitializeComponent();
        }

        ObservableCollection<ReplaceInfo> _Replacements;
        public ObservableCollection<ReplaceInfo> Replacements
        {
            get
            {
                return _Replacements;
            }
            set
            {
                _Replacements = value;
                DGReplacements.ItemsSource = _Replacements;
            }
        }


        private void BClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var idx = DGReplacements.SelectedIndex;
            if (idx != -1 && _Replacements.Count > idx)
            {
                _Replacements.RemoveAt(idx);
            }
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            var idx = _Replacements.Count;
            _Replacements.Add(new ReplaceInfo() { IgnoreCase = true, ReplaceCategory = "M" });
            DGReplacements.SelectedIndex = idx;
        }


    }
}
