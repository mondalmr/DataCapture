﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataCapture.DTO;

namespace DataCapture
{
    public class ValueSubstitution : NotifyInfo
    {

        public ValueSubstitution()
        {
        }

        public ValueSubstitution(string value, UnitInfo mappedUnit, CreateDataInfo createBLInfo)
        {
            Value = value;
            MappedUnit = mappedUnit;
            CreateBLInfo = createBLInfo;
        }

        public UnitInfo[] PackageUMs
        {
            get
            {
                if (CreateBLInfo != null)
                {
                    return CreateBLInfo.PackageUMs;
                }
                return null;
            }
        }

        public UnitInfo[] WeightUMs
        {
            get
            {
                if (CreateBLInfo != null)
                {
                    return CreateBLInfo.WeightUMs;
                }
                return null;
            }
        }

        public UnitInfo[] MeasureUMs
        {
            get
            {
                if (CreateBLInfo != null)
                {
                    return CreateBLInfo.MeasureUMs;
                }
                return null;
            }
        }

        CreateDataInfo _createBLInfo;
        public CreateDataInfo CreateBLInfo
        {
            get
            {
                return _createBLInfo;
            }
            set
            {
                _createBLInfo = value;
                RaisePropertyChanged("CreateBLInfo");
                RaisePropertyChanged("PackageUMs");
                RaisePropertyChanged("MeasureUMs");
                RaisePropertyChanged("WeightUMs");
            }
        }

        string _value;
        public string Value
        {
            get
            {
                return _value;
            }
            set
            {
                _value = value;
                RaisePropertyChanged("Value");
            }
        }

        UnitInfo _mappedUnit;
        public UnitInfo MappedUnit
        {
            get
            {
                return _mappedUnit;
            }
            set
            {
                _mappedUnit = value;
                RaisePropertyChanged("MappedUnit");
            }
        }
    }
}
