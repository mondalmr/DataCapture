﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using DataCapture.DTO;

namespace DataCapture
{
    [Serializable]
    public class DataCaptureInfo : UndoRedoModel
    {
        public void CopyFrom(DataCaptureInfo dcInfo)
        {
            if (dcInfo != null)
            {
                var actions = new UndoRedoCollection();
                MultilineElement1.CopyFrom(dcInfo.MultilineElement1, actions);                

                CopyFieldValues(dcInfo, actions);

                GridInfo selectedPackage = null;
                ClearPackages(actions, true);
                if (dcInfo.PackageList != null)
                {
                    foreach (GridInfo pi in dcInfo.PackageList)
                    {
                        var tmpPI = NewPackage();
                        tmpPI.CopyFrom(pi, actions);
                        PackageList.Add(tmpPI);
                        if (selectedPackage == null)
                        {
                            selectedPackage = tmpPI;
                        }
                    }
                }
                                
                SelectedPackage = selectedPackage;
                UndoRedoManager.Current.AddUndoAction(actions);
            }
        }

        public DataCaptureInfo()
            : this(false)
        {
        }

        public DataCaptureInfo(bool createPackage)
            : base()
        {
            MultilineElement1 = new MultilineInfo();            
            PackageList = new ObservableCollection<GridInfo>();
            
            if (ListOfTextAreaElement1 == null)
                ListOfTextAreaElement1 = new List<string>();
            
            Clear(null, createPackage);
        }

        public void Clear(DataCaptureElementType? elementType = null, bool createPackage = true)
        {
            var actions = new UndoRedoCollection();

            if (elementType == null || elementType == DataCaptureElementType.ChallanNo)
            {
                SetPropertyValue(DataCaptureFields.ChallanNo, "", true, actions);
                //SetPropertyValue(BLInfoFields.BLNoUid, "", true, actions);
                //SetPropertyValue(BLInfoFields.PCTBLNo, "", true, actions);
            }
            
            if (elementType == null || elementType == DataCaptureElementType.SectionCode)
            {
                SetPropertyValue(DataCaptureFields.SectionCode, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTPrimaryBookingNo, "", true, actions);
            }
            
            if (elementType == null || elementType == DataCaptureElementType.TAN)
            {
                SetPropertyValue(DataCaptureFields.TAN, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTAdditionalBookingNos, "", true, actions);
            }

            if(elementType==null || elementType == DataCaptureElementType.AssessmentYear)
            {
                SetPropertyValue(DataCaptureFields.AssessmentYear, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTAssessmentYear, "", true, actions);
            }

            if (elementType == null || elementType == DataCaptureElementType.TDS)
            {
                SetPropertyValue(DataCaptureFields.TDS, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTTDS, "", true, actions);
            }

            if (elementType == null || elementType == DataCaptureElementType.Surcharge)
            {
                SetPropertyValue(DataCaptureFields.Surcharge, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTSurcharge, "", true, actions);
            }

            if (elementType == null || elementType == DataCaptureElementType.EducationCess)
            {
                SetPropertyValue(DataCaptureFields.EducationCess, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTEducationCess, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.Interest)
            {
                SetPropertyValue(DataCaptureFields.Interest, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTInterest, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.Fee)
            {
                SetPropertyValue(DataCaptureFields.Fee, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTFee, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.Others)
            {
                SetPropertyValue(DataCaptureFields.Others, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTOthers, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.TotalTax)
            {
                SetPropertyValue(DataCaptureFields.TotalTax, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTTotalTax, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.BranchCode)
            {
                SetPropertyValue(DataCaptureFields.BranchCode, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTBranchCode, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.BankName)
            {
                SetPropertyValue(DataCaptureFields.BankName, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTBankName, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.DepositDate)
            {
                SetPropertyValue(DataCaptureFields.DepositDate, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTDepositDate, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.MinorHead)
            {
                SetPropertyValue(DataCaptureFields.MinorHead, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTMinorHead, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.Remarks)
            {
                SetPropertyValue(DataCaptureFields.Remarks, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTRemarks, "", true, actions);
            }

            if (elementType == null || elementType == DataCaptureElementType.CertAckNo)
            {
                SetPropertyValue(DataCaptureFields.CertAckNo, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTCertAckNo, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.CertDate)
            {
                SetPropertyValue(DataCaptureFields.CertDate, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTCertDate, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.PANNo)
            {
                SetPropertyValue(DataCaptureFields.PANNo, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTPANNo, "", true, actions);
            }
            if (elementType == null || elementType == DataCaptureElementType.CertName)
            {
                SetPropertyValue(DataCaptureFields.CertName, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTCertName, "", true, actions);
            }





            if (elementType == null || elementType == DataCaptureElementType.TextAreaElement1)
            {
                SetPropertyValue(DataCaptureFields.TextAreaElement1, "", true, actions);
                //SetPropertyValue(DataCaptureFields.PCTAESNo, "", true, actions);
            }
            
            // Clear Shipper
            if (elementType == null || elementType == DataCaptureElementType.MultilineElement1)
            {
                MultilineElement1.Clear(actions);
            }
                        
            // Clear Package
            if (elementType == null || elementType == DataCaptureElementType.PackageGrid)
            {
                ClearPackages(actions, !createPackage);
            }

            // Only if Package related elements
            if (elementType != null && SelectedPackage != null)
            {
                switch (elementType.Value)
                {                    
                    // Package Count
                    case DataCaptureElementType.CertificateAmt:
                        SelectedPackage.SetPropertyValue(GridInfoFields.CertificateAmt, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTCertificateAmt, "", true, actions);
                        break;

                    // Package 
                    case DataCaptureElementType.CertificateNo:
                        SelectedPackage.SetPropertyValue(GridInfoFields.CertificateNo, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTCertificateNo, "", true, actions);
                        break;

                    // Package Measure
                    case DataCaptureElementType.IntCol4:
                        SelectedPackage.SetPropertyValue(GridInfoFields.IntCol4, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasure, "", true, actions);
                        break;

                    // Package 
                    case DataCaptureElementType.ToDate:
                        SelectedPackage.SetPropertyValue(GridInfoFields.ToDate, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTToDate, "", true, actions);
                        break;

                    case DataCaptureElementType.IntCol3:
                        SelectedPackage.SetPropertyValue(GridInfoFields.IntCol3, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeight, "", true, actions);
                        break;


                    case DataCaptureElementType.FromDate:
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PackageNetWeightUM, "", true, actions);
                        SelectedPackage.SetPropertyValue(GridInfoFields.FromDate, "", true, actions);
                        break;
                    
                    case DataCaptureElementType.PrescribedRate:
                        SelectedPackage.SetPropertyValue(GridInfoFields.PrescribedRate, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeight, "", true, actions);
                        break;

                    // Package Weight UM
                    case DataCaptureElementType.Nature:
                        SelectedPackage.SetPropertyValue(GridInfoFields.Nature, "", true, actions);
                        //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeightUM, "", true, actions);
                        break;
                }
            }
            if (elementType != null)
            {
                UndoRedoManager.Current.AddUndoAction(actions);
            }
        }

        public void InitializePackageList(UndoRedoCollection actions)
        {
            if (PackageList != null && PackageList.Count == 0)
            {
                var temp = NewPackage();
                PackageList.Add(temp);
                SelectedPackage = temp;
                AdjustPackageSeq();
                var undoRedo = new UndoRedoAddPackage(this);
                if (actions != null)
                {
                    actions.Actions.Add(undoRedo);
                }
                else
                {
                    UndoRedoManager.Current.AddUndoAction(undoRedo);
                }
            }
        }

        public string DefaultPkgCode
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.DefaultPkgCode);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.DefaultPkgCode, value, true);
            }
        }

        public string DefaultGWUM
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.DefaultGWUM);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.DefaultGWUM, value, true);
            }
        }

        public string DefaultNWUM
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.DefaultNWUM);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.DefaultNWUM, value, true);
            }
        }

        public string DefaultGMUM
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.DefaultGMUM);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.DefaultGMUM, value, true);
            }
        }

        public string DefaultNMUM
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.DefaultNMUM);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.DefaultNMUM, value, true);
            }
        }
        
        public string ChallanNo
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.ChallanNo);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.ChallanNo, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string SectionCode
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.SectionCode);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.SectionCode, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string TAN
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.TAN);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.TAN, value.RemoveSpaces().ToSingleLine(), true);
            }
        }

        public string AssessmentYear
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.AssessmentYear);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.AssessmentYear, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string TDS
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.TDS);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.TDS, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string Surcharge
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.Surcharge);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.Surcharge, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }


        public string EducationCess
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.EducationCess);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.EducationCess, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string Interest
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.Interest);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.Interest, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string Fee
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.Fee);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.Fee, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string Others
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.Others);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.Others, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string TotalTax
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.TotalTax);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.TotalTax, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string BranchCode
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.BranchCode);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.BranchCode, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }



        public string BankName
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.BankName);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.BankName, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string DepositDate
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.DepositDate);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.DepositDate, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string MinorHead
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.MinorHead);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.MinorHead, value.RemoveExtendedCharacters().ToSingleLine(), true);
            }
        }

        public string Remarks
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.Remarks);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.Remarks, value.RemoveExtendedCharacters(), true);
            }
        }

        public string CertAckNo
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.CertAckNo);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.CertAckNo, value.RemoveExtendedCharacters(), true);
            }
        }

        public string CertDate
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.CertDate);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.CertDate, value.RemoveExtendedCharacters(), true);
            }
        }

        public string PANNo
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.PANNo);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.PANNo, value.RemoveExtendedCharacters(), true);
            }
        }

        public string CertName
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.CertName);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.CertName, value.RemoveExtendedCharacters(), true);
            }
        }
        

        public MultilineInfo MultilineElement1
        {
            get;
            set;
        }        

        public string TextAreaElement1
        {
            get
            {
                return GetPropertyValue(DataCaptureFields.TextAreaElement1);
            }
            set
            {
                SetPropertyValue(DataCaptureFields.TextAreaElement1, value, true);
                string[] old = value.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                ListOfTextAreaElement1 = old.ToList();
            }
        }
        
        public List<string> ListOfTextAreaElement1 { get; set; }
               
        private ObservableCollection<GridInfo> _packagelist;

        public ObservableCollection<GridInfo> PackageList
        {
            get
            {
                return _packagelist;
            }
            private set
            {
                _packagelist = value;
            }
        }

        //public ObservableCollection<ClpInfo> ClpList { get; set; }

        GridInfo _selectedPackage;

        public GridInfo SelectedPackage
        {
            get
            {
                return _selectedPackage;
            }
            set
            {
                _selectedPackage = value;
                RaisePropertyChanged("SelectedPackage");
            }
        }

        public ICommand AddPackage
        {
            get
            {
                return new RelayCommand(ExecuteAddPackage, CanExecuteAddPackage);
            }
        }

        private void ExecuteAddPackage(object parameter)
        {
            var package = NewPackage();
            PackageList.Add(package);
            SelectedPackage = package;
            AdjustPackageSeq();
            UndoRedoManager.Current.AddUndoAction(new UndoRedoAddPackage(this));
        }

        private bool CanExecuteAddPackage(object paramter)
        {
            return true;
        }

        public ICommand DeletePackage
        {
            get
            {
                return new RelayCommand(ExecuteDeletePackage, CanExecuteDeletePackage);
            }
        }

        private void ExecuteDeletePackage(object parameter)
        {
            if (SelectedPackage != null)
            {
                UndoRedoManager.Current.AddUndoAction(new UndoRedoDeletePackage(this));

                var package = SelectedPackage;
                int idx = PackageList.IndexOf(package);
                PackageList.Remove(package);
                var count = PackageList.Count();
                AdjustPackageSeq();
                if (count == 0)
                {
                    package = new GridInfo();
                    PackageList.Add(package);
                }
                else
                {
                    if (idx < count)
                    {
                        package = PackageList[idx];
                    }
                    else if (idx - 1 < count)
                    {
                        package = PackageList[idx - 1];
                    }
                    else
                    {
                        package = PackageList[0];
                    }
                }
                SelectedPackage = package;
            }
        }

        private bool CanExecuteDeletePackage(object paramter)
        {
            if (SelectedPackage == null)
            {
                return false;
            }
            return true;
        }

        public ICommand DeleteAllPackages
        {
            get
            {
                return new RelayCommand(ExecuteDeleteAllPackages, CanExecuteDeleteAllPackages);
            }
        }

        internal void ClearPackages(UndoRedoCollection actions, bool skipPostInitialize)
        {
            if (PackageList != null)
            {
                var undoRedo = new UndoRedoClearPackages(this);
                if (actions != null)
                {
                    actions.Actions.Add(undoRedo);
                }
                else
                {
                    UndoRedoManager.Current.AddUndoAction(undoRedo);
                }
                PackageList.Clear();
                if (!skipPostInitialize)
                {
                    InitializePackageList(actions);
                }
            }
        }

        private void ExecuteDeleteAllPackages(object parameter)
        {
            ClearPackages(null, false);
        }

        private bool CanExecuteDeleteAllPackages(object paramter)
        {
            if (PackageList != null && PackageList.Count() > 0)
            {
                return true;
            }
            return false;
        }

        public ICommand ApplyDefaults
        {
            get
            {
                return new RelayCommand(ExecuteApplyDefaults, CanExecuteApplyDefaults);
            }
        }

        public GridInfo NewPackage(UndoRedoCollection actions = null)
        {
            var pkg = new GridInfo();
            var add = false;
            if (actions == null)
            {
                actions = new UndoRedoCollection();
                add = true;
            }
            UpdatePackageDefaults(pkg, actions);
            if (add)
            {
                UndoRedoManager.Current.AddUndoAction(actions);
            }
            return pkg;
        }

        private void ExecuteApplyDefaults(object parameter)
        {
            if (PackageList != null)
            {
                UpdatePackageDefaults();
            }
        }

        private bool CanExecuteApplyDefaults(object paramter)
        {
            if (PackageList != null && PackageList.Count() > 0)
            {
                return true;
            }
            return false;
        }

        public void UpdatePackageDefaults()
        {
            if (PackageList != null)
            {
                var actions = new UndoRedoCollection();
                foreach (var pkg in PackageList)
                {
                    UpdatePackageDefaults(pkg, actions);
                }
            }
        }

        public void UpdatePackageDefaults(GridInfo package, UndoRedoCollection actions)
        {
            if (package == null)
            {
                return;
            }
            if (string.IsNullOrWhiteSpace(package.CertificateNo))
            {
                package.SetPropertyValue(GridInfoFields.CertificateNo, DefaultPkgCode, true, actions);
            }

            if (string.IsNullOrWhiteSpace(package.Nature))
            {
                package.SetPropertyValue(GridInfoFields.Nature, DefaultGWUM, true, actions);
            }

            if (string.IsNullOrWhiteSpace(package.FromDate))
            {
                package.SetPropertyValue(GridInfoFields.FromDate, DefaultNWUM, true, actions);
            }

            if (string.IsNullOrWhiteSpace(package.ToDate))
            {
                package.SetPropertyValue(GridInfoFields.ToDate, DefaultGMUM, true, actions);
            }

            //if (string.IsNullOrWhiteSpace(package.PackageNetMeasureUM))
            //{
            //    package.SetPropertyValue(GridInfoFields.PackageNetMeasureUM, DefaultNMUM, true, actions);
            //}
        }

        public string GetElementValue(DataCaptureElementType blElementType)
        {
            switch (blElementType)
            {
                case DataCaptureElementType.MultilineElement1:
                    return MultilineElement1.Value;                               

                case DataCaptureElementType.CertificateAmt:
                    return SelectedPackage.CertificateAmt;

                case DataCaptureElementType.CertificateNo:
                    return SelectedPackage.CertificateNo;

                case DataCaptureElementType.PrescribedRate:
                    return SelectedPackage.PrescribedRate;

                case DataCaptureElementType.Nature:
                    return SelectedPackage.Nature;

                case DataCaptureElementType.IntCol4:
                    return SelectedPackage.IntCol4;

                case DataCaptureElementType.ToDate:
                    return SelectedPackage.ToDate;

                case DataCaptureElementType.IntCol3:
                    return SelectedPackage.IntCol3;

                case DataCaptureElementType.FromDate:
                    return SelectedPackage.FromDate;

                //case DataCaptureElementType.PackageNetMeasure:
                //    return SelectedPackage.PackageNetMeasure;

                //case DataCaptureElementType.PackageNetMeasureUM:
                //    return SelectedPackage.PackageNetMeasureUM;                
               
                case DataCaptureElementType.TextAreaElement1:
                    return TextAreaElement1;                

                case DataCaptureElementType.ChallanNo:
                    return ChallanNo;

                case DataCaptureElementType.SectionCode:
                    return SectionCode;

                case DataCaptureElementType.TAN:
                    return TAN;

                case DataCaptureElementType.AssessmentYear:
                    return AssessmentYear;

                case DataCaptureElementType.TDS:
                    return TDS;

                case DataCaptureElementType.Surcharge:
                    return Surcharge;

                case DataCaptureElementType.EducationCess:
                    return EducationCess;

                case DataCaptureElementType.Interest:
                    return Interest;

                case DataCaptureElementType.Fee:
                    return Fee;

                case DataCaptureElementType.Others:
                    return Others;

                case DataCaptureElementType.TotalTax:
                    return TotalTax;

                case DataCaptureElementType.BranchCode:
                    return BranchCode;

                case DataCaptureElementType.BankName:
                    return BankName;
                case DataCaptureElementType.DepositDate:
                    return DepositDate;
                case DataCaptureElementType.MinorHead:
                    return MinorHead;
                case DataCaptureElementType.Remarks:
                    return Remarks;
                case DataCaptureElementType.CertAckNo:
                    return CertAckNo;
                case DataCaptureElementType.CertDate:
                    return CertDate;
                case DataCaptureElementType.PANNo:
                    return PANNo;
                case DataCaptureElementType.CertName:
                    return CertName;
            }
            return "";
        }

        //public string GetElementPCT(BLElementType blElementType)
        //{
        //    switch (blElementType)
        //    {
        //        case BLElementType.Shipper:
        //            return Shipper.PCT;

        //        case BLElementType.ExportReference:
        //            return PCTExpref;

        //        case BLElementType.AESNo:
        //            return PCTAESNo;

        //        case BLElementType.Por:
        //            return PCTPor;

        //        case BLElementType.Pori:
        //            return PCTPori;

        //        case BLElementType.OriginPlace:
        //            return PCTOrigin;

        //        case BLElementType.FinalDestination:
        //            return PCTFinalDestination;

        //        case BLElementType.Forwarder:
        //            return Forwarder.PCT;

        //        case BLElementType.Consignee:
        //            return Consignee.PCT;

        //        case BLElementType.NotifyParty:
        //            return NotifyParty.PCT;

        //        case BLElementType.NotifyParty2:
        //            return NotifyParty2.PCT;

        //        case BLElementType.NotifyParty3:
        //            return NotifyParty3.PCT;

        //        case BLElementType.AlsoNotifyExportReference:
        //            return PCTAnpXr;

        //        case BLElementType.PackageCount:
        //            return SelectedPackage.PCTPackageCount;

        //        case BLElementType.PackageType:
        //            return SelectedPackage.PCTPackageType;

        //        case BLElementType.PackageWeight:
        //            return SelectedPackage.PCTPackageWeight;

        //        case BLElementType.PackageWeightUM:
        //            return SelectedPackage.PCTPackageWeightUM;

        //        case BLElementType.PackageMeasure:
        //            return SelectedPackage.PCTPackageMeasure;

        //        case BLElementType.PackageMeasureUM:
        //            return SelectedPackage.PCTPackageMeasureUM;

        //        case BLElementType.PackageNetWeight:
        //            return SelectedPackage.PCTPackageNetWeight;

        //        case BLElementType.PackageNetWeightUM:
        //            return SelectedPackage.PCTPackageNetWeightUM;

        //        case BLElementType.PackageNetMeasure:
        //            return SelectedPackage.PCTPackageNetMeasure;

        //        case BLElementType.PackageNetMeasureUM:
        //            return SelectedPackage.PCTPackageNetMeasureUM;

        //        case BLElementType.MarksNos:
        //            return SelectedPackage.PCTMarksNos;

        //        case BLElementType.GoodsDescription:
        //            return SelectedPackage.PCTGoodsDescription;

        //        case BLElementType.Containers:
        //            return PCTContainers;

        //        case BLElementType.SealNos:
        //            return PCTSealNos;

        //        case BLElementType.ChallanNo:
        //            return PCTBLNo;

        //        case BLElementType.SectionCode:
        //            return PCTSectionCode;

        //        case BLElementType.TAN:
        //            return PCTTAN;

        //        case BLElementType.AssessmentYear:
        //            return PCTAssessmentYear;

        //        case BLElementType.TDS:
        //            return PCTTDS;

        //        case BLElementType.Surcharge:
        //            return PCTSurcharge;

        //        case BLElementType.EducationCess:
        //            return PCTEducationCess;

        //        case BLElementType.Interest:
        //            return PCTInterest;

        //        case BLElementType.Fee:
        //            return PCTFee;

        //        case BLElementType.Others:
        //            return PCTOthers;

        //        case BLElementType.TotalTax:
        //            return PCTTotalTax;

        //        case BLElementType.BranchCode:
        //            return PCTBranchCode;

        //        case BLElementType.CertAckNo
        //            return PCTCertAckNo;

        //        case BLElementType.CertDate
        //            return PCTCertDate;

        //        case BLElementType.PANNo
        //            return PCTPANNo;

        //        case BLElementType.CertName
        //            return PCTCertName;


        //        case BLElementType.BLTextBody:
        //            return PCTBLTextBody;

        //        case BLElementType.PreCarriage:
        //            return PCTPreCarriage;

        //        case BLElementType.PlaceReceipt:
        //            return PCTPlaceReceipt;

        //        case BLElementType.OceanVessel:
        //            return PCTOceanVessel;

        //        case BLElementType.OceanVoyage:
        //            return PCTOceanVoyage;

        //        case BLElementType.PortLoading:
        //            return PCTPortLoading;

        //        case BLElementType.PortDischarge:
        //            return PCTPortDischarge;

        //        case BLElementType.PlaceDelivery:
        //            return PCTPlaceDelivery;
        //    }
        //    return "";
        //}

        public string ApplyElement(DataCaptureElementType dcElementType, double accuracy, string text, bool euroFormat)
        {
            string value = text;
            string valuePlain = value.ToSingleLine(); // value after removing new line characters
            string pct = " " + accuracy + "% ";
            if (accuracy < 0)
            {
                pct = "";
            }
            string[] values = null;
            string message = "";
            var actions = new UndoRedoCollection();
            if (dcElementType == DataCaptureElementType.General)
            {
                //message = "Apply is not supported for this selection.";
            }
            else if (dcElementType == DataCaptureElementType.ChallanNo)            
                SetPropertyValue(DataCaptureFields.ChallanNo, valuePlain, true, actions);                            
            else if (dcElementType == DataCaptureElementType.SectionCode)
                SetPropertyValue(DataCaptureFields.SectionCode, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.TAN)
                SetPropertyValue(DataCaptureFields.TAN, valuePlain.RemoveSpaces(), true, actions);
            else if (dcElementType == DataCaptureElementType.AssessmentYear)
                SetPropertyValue(DataCaptureFields.AssessmentYear, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.TDS)
                SetPropertyValue(DataCaptureFields.TDS, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.Surcharge)
                SetPropertyValue(DataCaptureFields.Surcharge, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.EducationCess)
                SetPropertyValue(DataCaptureFields.EducationCess, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.Interest)
                SetPropertyValue(DataCaptureFields.Interest, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.Fee)
                SetPropertyValue(DataCaptureFields.Fee, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.Others)
                SetPropertyValue(DataCaptureFields.Others, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.TotalTax)
                SetPropertyValue(DataCaptureFields.TotalTax, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.BranchCode)
                SetPropertyValue(DataCaptureFields.BranchCode, valuePlain, true, actions);
            else if(dcElementType == DataCaptureElementType.BankName)
                SetPropertyValue(DataCaptureFields.BankName, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.DepositDate)
                SetPropertyValue(DataCaptureFields.DepositDate, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.MinorHead)
                SetPropertyValue(DataCaptureFields.MinorHead, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.Remarks)
                SetPropertyValue(DataCaptureFields.Remarks, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.CertAckNo)
                SetPropertyValue(DataCaptureFields.CertAckNo, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.CertDate)
                SetPropertyValue(DataCaptureFields.CertDate, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.PANNo)
                SetPropertyValue(DataCaptureFields.PANNo, valuePlain, true, actions);
            else if (dcElementType == DataCaptureElementType.CertName)
                SetPropertyValue(DataCaptureFields.CertName, valuePlain, true, actions);


            else if (dcElementType == DataCaptureElementType.TextAreaElement1)
            {
                if (!string.IsNullOrWhiteSpace(valuePlain))
                {
                    string[] old = TextAreaElement1.Split(new string[] { Environment.NewLine, "" }, StringSplitOptions.RemoveEmptyEntries);

                    ListOfTextAreaElement1 = old.ToList();

                    string[] temp = value.Trim().Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

                    temp = Array.ConvertAll(temp, t => t.Trim());

                    foreach (string s in temp)
                    {
                        if (!ListOfTextAreaElement1.Contains(s.Trim()))
                        {
                            ListOfTextAreaElement1.Add(s.Trim());
                        }
                    }
                    ListOfTextAreaElement1.RemoveAll(e => string.IsNullOrWhiteSpace(e));

                    SetPropertyValue(DataCaptureFields.TextAreaElement1, string.Join(Environment.NewLine, ListOfTextAreaElement1.ToArray()), true, actions);
                }
            }               
            else if (dcElementType == DataCaptureElementType.MultilineElement1)
            {
                message = MultilineElement1.Apply(value, accuracy, actions);
            }
            else
            {
                if (SelectedPackage == null)
                {
                    message = "No Package Row Selected.";
                }
                else
                {
                    switch (dcElementType)
                    {                        
                        case DataCaptureElementType.CertificateAmt:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.CertificateAmt, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTCertificateAmt, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.CertificateNo, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageType, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.CertificateAmt, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTCertificateAmt, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.CertificateNo:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.CertificateAmt, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTCertificateAmt, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.CertificateNo, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageType, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.CertificateNo, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageType, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.PrescribedRate:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.PrescribedRate, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeight, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.Nature, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeightUM, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.PrescribedRate, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeight, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.Nature:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.PrescribedRate, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeight, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.Nature, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeightUM, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.Nature, valuePlain, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageWeightUM, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.IntCol4:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.IntCol4, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasure, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.ToDate, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasureUM, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.IntCol4, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasure, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.ToDate:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.IntCol4, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasure, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.ToDate, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasureUM, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.ToDate, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageMeasureUM, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.IntCol3:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.IntCol3, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeight, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.FromDate, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeightUM, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.IntCol3, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeight, pct, true, actions);
                            }
                            break;

                        case DataCaptureElementType.FromDate:
                            values = value.SeparateValueAndUM(euroFormat);
                            if (values != null && values.Length > 1)
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.IntCol3, values[0], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeight, pct, true, actions);
                                SelectedPackage.SetPropertyValue(GridInfoFields.FromDate, values[1], true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeightUM, pct, true, actions);
                            }
                            else
                            {
                                SelectedPackage.SetPropertyValue(GridInfoFields.FromDate, valuePlain, true, actions);
                                //SelectedPackage.SetPropertyValue(GridInfoFields.PCTPackageNetWeightUM, pct, true, actions);
                            }
                            break;                       

                        default:
                            break;
                    }
                }
            }
            if (actions != null && actions.Actions != null && actions.Actions.Count() > 0)
            {
                UndoRedoManager.Current.AddUndoAction(actions);
            }
            return message;
        }

        public CapturedData CopyTo()
        {
            CapturedData objData = new CapturedData();
            
            return objData;
        }

        internal bool CopyOrMovePackageInfo(bool copy, GridInfo sourcePackage, GridInfo targetPackage)
        {
            if (PackageList != null && PackageList.Count > 0 && sourcePackage != null && sourcePackage != targetPackage)
            {
                var targetIdx = PackageList.Count - 1;
                if (targetPackage != null)
                {
                    targetIdx = PackageList.IndexOf(targetPackage);
                }
                if (copy)
                {
                    var copyPackage = new GridInfo();
                    copyPackage.CopyFrom(sourcePackage);
                    if (targetPackage == null)
                    {
                        PackageList.Add(copyPackage);
                    }
                    else
                    {
                        PackageList.Insert(targetIdx, copyPackage);
                    }
                }
                else
                {
                    var sourceIdx = PackageList.IndexOf(sourcePackage);
                    if (sourceIdx >= 0 && targetIdx >= 0 && sourceIdx != targetIdx)
                    {
                        PackageList.Move(sourceIdx, targetIdx);
                        return true;
                    }
                }
            }
            return false;
        }

        public int SelectedPackageIndex
        {
            get
            {
                return GetPackageIndex(SelectedPackage);
            }
            set
            {
                if (value >= 0 && PackageList.Count() > value)
                {
                    SelectedPackage = PackageList[value];
                }
                else
                {
                    SelectedPackage = null;
                }
            }
        }

        public int GetPackageIndex(GridInfo packageInfo)
        {
            if (packageInfo != null)
            {
                return PackageList.IndexOf(packageInfo);
            }
            return -1;
        }       

        private void AdjustPackageSeq()
        {
            var seqNo = 1;
            PackageList.ToList().ForEach(m =>
            {
                m.SeqNo = seqNo.ToString();
                seqNo++;
            });
        }
    }
}
