﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class OCRPostNumberRule : IOCRPostRule
    {
        public string Description
        {
            get 
            {
                return "Convert certain characters to numbers";
            }
        }

        public string Apply(string text)
        {
            var words = text.ToWords();
            if (words == null)
            {
                return text;
            }
            else
            {
                for (int i = 0; i < words.Length; i++)
                {
                    if (words[i] != null && words[i].Length > 1)
                    {
                        words[i] = words[i].Replace('|', '1');
                        words[i] = words[i].Replace('!', '0');
                        words[i] = words[i].Replace('l', '1');
                        words[i] = words[i].Replace('D', '0');
                        words[i] = words[i].Replace('O', '0');
                        words[i] = words[i].Replace('o', '0');
                        words[i] = words[i].Replace('G', '6');
                        words[i] = words[i].Replace('C', '6');
                        words[i] = words[i].Replace('Z', '2');
                        words[i] = words[i].Replace("/£", "4");
                    }
                }
            }
            return string.Join("", words);
        }
    }
}
