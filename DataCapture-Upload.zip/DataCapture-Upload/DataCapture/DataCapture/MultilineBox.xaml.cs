﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for AddressBox.xaml
    /// </summary>
    public partial class MultilineBox : UserControl
    {
        public MultilineBox()
        {
            InitializeComponent();
            Loaded += MultilineBox_Loaded;
        }

        void MultilineBox_Loaded(object sender, RoutedEventArgs e)
        {
            OCRPostUtils.SetupContextMenu(FindResource("CMSelectedText") as ContextMenu);
        }

        public int GetCaretIndex()
        {
            TextBox tb = FocusManager.GetFocusedElement(GAddressBox) as TextBox;
            if (tb != null)
            {
                if (tb.CaretIndex != -1)
                {
                    int nl = Environment.NewLine.Length;

                    int idx = tb.CaretIndex;
                    if (tb == TBName)
                    {
                        return idx;
                    }

                    idx = idx + nl + TBName.Text.Length;
                    if (tb == TBAddr1)
                    {
                        return idx;
                    }

                    idx = idx + nl + TBAddr1.Text.Length;
                    if (tb == TBAddr2)
                    {
                        return idx;
                    }

                    idx = idx + nl + TBAddr2.Text.Length;
                    if (tb == TBAddr3)
                    {
                        return idx;
                    }

                    idx = idx + nl + TBAddr3.Text.Length;
                    if (tb == TBAddr4)
                    {
                        return idx;
                    }

                    idx = idx + nl + TBAddr4.Text.Length;
                    if (tb == TBAddr4)
                    {
                        return idx;
                    }
                    
                    idx = idx + nl + TBAddr5.Text.Length;
                    if (tb == TBAddr5)
                    {
                        return idx;
                    }
                }
            }
            return -1;
        }

        //public void SetCopyConsignee(MultilineBox cns)
        //{
        //    var address = DataContext as MultilineInfo;
        //    if (address != null)
        //    {
        //        address.Name = cns.TBName.Text;
        //        address.Addr1 = cns.TBAddr1.Text;
        //        address.Addr2 = cns.TBAddr2.Text;
        //        address.Addr3 = cns.TBAddr3.Text;
        //        address.Addr4 = cns.TBAddr4.Text;
        //        address.Addr5 = cns.TBAddr5.Text;
        //        address.NameRcvd = cns.TBNameRcvd.Text;
        //    }
        //}

        //public void SetSameAsConsignee()
        //{
        //    var address = DataContext as MultilineInfo;
        //    if (address != null)
        //    {
        //        address.Name = "SAME AS CONSIGNEE";
        //        address.Addr1 = ".";
        //        address.Addr2 = "";
        //        address.Addr3 = "";
        //        address.Addr4 = "";
        //        address.Addr5 = "";
        //        address.NameRcvd = "";
        //    }
        //}

        public void SetTextBrush(Brush brush)
        {
            TBName.Background = brush;
            TBAddr1.Background = brush;
            TBAddr2.Background = brush;
            TBAddr3.Background = brush;
            TBAddr4.Background = brush;            
        }


        private void OCRFix_Click(object sender, RoutedEventArgs e)
        {
            (sender as MenuItem).ExecuteOCRFix(Window.GetWindow(this));
        }

        private void InsertDelete(MenuItem menuItem, bool isDelete)
        {
            if (menuItem != null)
            {
                var multiline = DataContext as MultilineInfo;
                var cm = menuItem.GetContextMenu();
                if (cm != null)
                {
                    var tb = cm.PlacementTarget as TextBox;
                    if (tb != null && tb.Tag is string)
                    {
                        int idx = -1;
                        if (Int32.TryParse(tb.Tag as string, out idx) && idx >= 0 && idx < 5)
                        {
                            List<string> lines = new List<string> { multiline.Line1 ?? string.Empty, multiline.Line2 ?? string.Empty, multiline.Line3 ?? string.Empty, multiline.Line4 ?? string.Empty, multiline.Line5 ?? string.Empty, multiline.Line6 ?? string.Empty };
                            if (isDelete)
                            {
                                lines.RemoveAt(idx);
                                lines.Add(string.Empty);
                            }
                            else
                            {
                                var proceed = true;                                
                                if (proceed)
                                {
                                    lines.Insert(idx, "");
                                }
                            }
                            multiline.Line1 = lines[0];                            
                            multiline.Line2 = lines[1];
                            multiline.Line3 = lines[2];
                            multiline.Line4 = lines[3];
                            multiline.Line5 = lines[4];
                            multiline.Line6 = lines[5];
                        }
                    }
                }
            }
        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            InsertDelete(sender as MenuItem, false);
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            InsertDelete(sender as MenuItem, true);
        }

        private void TB_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            UndoRedoManager.Current.HandlePreviewKeyDown(sender, e);
        }

        //internal bool AreTBsValid()
        //{
        //    var valid = true;
        //    if (!TBName.ValidateText())
        //    {
        //        valid = false;
        //    }
        //    if (!TBAddr1.ValidateText())
        //    {
        //        valid = false;
        //    }
        //    if (!TBAddr2.ValidateText())
        //    {
        //        valid = false;
        //    }
        //    if (!TBAddr3.ValidateText())
        //    {
        //        valid = false;
        //    }
        //    if (!TBAddr4.ValidateText())
        //    {
        //        valid = false;
        //    }
        //    if (!TBAddr5.ValidateText())
        //    {
        //        valid = false;
        //    }
        //    return valid;
        //}
    }
}
