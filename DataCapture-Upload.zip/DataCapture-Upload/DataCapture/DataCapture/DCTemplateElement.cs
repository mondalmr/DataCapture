﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    [Serializable]
    public class DCTemplateElement
    {
        public DCTemplateElement()
        {
        }

        public double Left
        {
            get;
            set;
        }

        public double Top
        {
            get;
            set;
        }

        public double Width
        {
            get;
            set;
        }

        public double Height
        {
            get;
            set;
        }

        public int PageNo
        {
            get;
            set;
        }

        public bool Visible
        {
            get;
            set;
        }

        public DataCaptureElementType ElementType
        {
            get;
            set;
        }

        public double[] Columns
        {
            get;
            set;
        }

        public double[] Rows
        {
            get;
            set;
        }

        public double[] RowsEnd
        {
            get;
            set;
        }

        public double[] RowsPkg
        {
            get;
            set;
        }

        public double[] RowsMks
        {
            get;
            set;
        }

        public double[] RowsGds
        {
            get;
            set;
        }

        public GridColumnContent[] ColumnContents
        {
            get;
            set;
        }
    }
}
