﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class BitmapWorker
    {
        Bitmap _BMP;
        BitArray _BW;

        public BitmapWorker(Bitmap bitmap)
        {
            SetupBitmapData(bitmap);
        }

        public int Stride
        {
            get;
            private set;
        }

        public int ByteCount
        {
            get
            {
                return Stride * Height;
            }
        }

        public int WidthByHeight
        {
            get
            {
                return Width * Height;
            }
        }

        public int Width
        {
            get;
            private set;
        }

        public int Height
        {
            get;
            private set;
        }


        public byte[] GetBytes()
        {
            int idx = 0;
            var depth = 3;
            var stride = Stride;
            var size = ByteCount;
            var buffer = new byte[size];
            int offset;
            for (int i = 0; i < Height; i++)
            {
                offset = i * stride;
                for (int j = 0; j < Width; j++)
                {
                    idx = offset + (j * depth);
                    if (!IsBlack(j, i))
                    {
                        buffer[idx] = 255;
                        buffer[idx + 1] = 255;
                        buffer[idx + 2] = 255;
                    }
                }
            }
            return buffer;
        }

        public Bitmap Apply()
        {
            var buffer = GetBytes();
            PixelFormat pxf = ImageUtils.DefaultPixelFormat;
            Bitmap bmp = _BMP;
            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, Width, Height), ImageLockMode.WriteOnly, pxf);
            Marshal.Copy(buffer, 0, bmpData.Scan0, buffer.Length);
            bmp.UnlockBits(bmpData);
            return bmp;
        }

        public bool IsBlack(int x, int y)
        {
            try
            {
                return _BW.Get((y * Width) + x);
            }
            catch
            {
                return false;
            }
        }

        public void SetPixel(int x, int y, bool isBlack)
        {
            _BW.Set((y * Width) + x, isBlack);
        }

        public bool SetPixel(int x, int y, int w, int h, bool isBlack)
        {
            for (int i = 0; i < h; i++)
            {
                for (int j = 0; j < w; j++)
                {
                    SetPixel(x + j, y + i, isBlack);
                }
            }
            return false;
        }

        private void SetupBitmapData(Bitmap bitmap)
        {
            _BMP = bitmap;
            BitmapData data = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadOnly, ImageUtils.DefaultPixelFormat);
            int skip = ImageUtils.DefaultPixelFormatByteLength;
            Width = bitmap.Width;
            Height = bitmap.Height;
            Stride = data.Stride;
            byte[] buffer = new byte[ByteCount];
            Marshal.Copy(data.Scan0, buffer, 0, ByteCount);
            bitmap.UnlockBits(data);

            int idx;
            int offset;
            _BW = new BitArray(Height * Width);
            for (int i = 0; i < Height; i++)
            {
                offset = i * Stride;
                for (int j = 0; j < Width; j++)
                {
                    idx = offset + (j * skip);

                    if (((buffer[idx + 2] * 0.299) + (buffer[idx + 1] * 0.587) + (buffer[idx] * 0.114)) < 140)
                    {
                        _BW.Set((i * Width) + j, true);
                    }
                }
            }
        }

        public void RemoveSpeckles(int speckMaxWidth, int speckMaxHeight, int minWhiteSpaceWidth, int minWhiteSpaceHeight)
        {
            int width = Width;
            int height = Height;
            int newj = 0;
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (IsBlack(j, i))
                    {
                        newj = CheckAndRemoveSpeckle(speckMaxWidth, speckMaxHeight, minWhiteSpaceWidth, minWhiteSpaceHeight, j, i);
                        if (newj > 0)
                        {
                            j = newj;
                        }
                    }
                }
            }
        }

        private int CheckAndRemoveSpeckle(int speckMaxWidth, int speckMaxHeight, int minWhiteSpaceWidth, int minWhiteSpaceHeight, int x, int y)
        {
            int width = Width;
            int height = Height;
            int x1 = x;
            int y1 = y;
            int x2 = x;
            int y2 = y;
            int newvalue = 0;
            while (x1 > 0 && x2 > 0 && y1 > 0 && y2 > 0)
            {
                if (Math.Abs(x2) - Math.Abs(x1) > speckMaxWidth)
                {
                    return 0;
                }
                if (Math.Abs(y2) - Math.Abs(y1) > speckMaxHeight)
                {
                    return 0;
                }
                if (x1 > 0)
                {
                    x1--;
                    if (!IsBlack(x1, y))
                    {
                        x1++;
                        x1 = x1 * -1;
                    }
                }
                if (x2 > 0)
                {
                    x2++;
                    if (width < x2 || !IsBlack(x2, y))
                    {
                        x2--;
                        x2 = x2 * -1;
                    }
                }
                if (y1 > 0)
                {
                    y1--;
                    if (!IsBlack(x, y1))
                    {
                        y1++;
                        y1 = y1 * -1;
                    }
                }
                if (y2 > 0)
                {
                    y2++;
                    if (height <= y2 || !IsBlack(x, y2))
                    {
                        y2--;
                        y2 = y2 * -1;
                    }
                }
            }

            x1 = Math.Abs(x1);
            x2 = Math.Abs(x2);
            y1 = Math.Abs(y1);
            y2 = Math.Abs(y2);

            if (minWhiteSpaceWidth > 0 || minWhiteSpaceHeight > 0)
            {
                int xs = Math.Max(x1 - minWhiteSpaceWidth, 0);
                int xe = Math.Min(x2 + minWhiteSpaceWidth, width);
                int ys = Math.Max(y1 - minWhiteSpaceHeight, 0);
                int ye = Math.Min(y2 + minWhiteSpaceHeight, height);
                for (int i = ys; i < ye; i++)
                {
                    for (int j = xs; j < xe; j++)
                    {
                        if (j >= x1 && j <= x2 && i >= y1 && i <= y2) // Skip speckle region
                        {
                            continue;
                        }
                        else
                        {
                            if (IsBlack(j, i))
                            {
                                return 0;
                            }
                        }
                    }
                }
                newvalue = xe - 1;
            }
            for (int i = y1; i <= y2; i++)
            {
                for (int j = x1; j <= x2; j++)
                {
                    SetPixel(j, i, false);
                }
            }
            return newvalue;
        }

        public void RemoveStraightLines(int value, bool isVertical)
        {
            Color color;
            int jMax = Width;
            int iMax = Height;
            if (isVertical)
            {
                iMax = Width;
                jMax = Height;
            }
            for (int i = 0; i < iMax; i++)
            {
                int start = -1;
                int end = -1;
                for (int j = 0; j < jMax; j++)
                {
                    bool isBlack;
                    if (isVertical)
                    {
                        isBlack = IsBlack(i, j);
                    }
                    else
                    {
                        isBlack = IsBlack(j, i);
                    }

                    if (isBlack)
                    {
                        if (start == -1)
                        {
                            start = j;
                            end = j;
                        }
                        else
                        {
                            end = j;
                        }
                    }
                    else
                    {
                        if (start != -1)
                        {
                            if (isVertical)
                            {
                                if (IsBlack(i, j + 1))
                                {
                                    continue;
                                }
                            }
                            else
                            {
                                if (IsBlack(j + 1, i))
                                {
                                    continue;
                                }
                            }
                            if (end - start > (int)value)
                            {
                                for (int k = start; k <= end; k++)
                                {
                                    if (isVertical)
                                    {
                                        SetPixel(i, k, false);
                                    }
                                    else
                                    {
                                        SetPixel(k, i, false);
                                        if (i > 0)
                                        {
                                            SetPixel(k, i - 1, false);
                                        }
                                        if (i < (Height - 1))
                                        {
                                            SetPixel(k, i + 1, false);
                                        }
                                    }
                                }
                            }
                            start = -1;
                            end = -1;
                        }
                    }
                }
            }
        }

        public void SmoothEdges(bool horizontal, bool vertical)
        {
            UpdatePixelsBasedOnNeighbors(5, 4);
            /*
            var width = Width - 2;
            var height = Height - 2;
            for (int i = 1; i < height; i++)
            {
                for (int j = 1; j < width; j++)
                {
                    SmoothEdgesSet(horizontal, vertical, width - j, height - i, -1);
                }
            }
            */
        }

        private void SmoothEdgesSet(bool horizontal, bool vertical, int x, int y, int delta)
        {
            var copied = false;
            if (!IsBlack(x, y))
            {
                if (horizontal && IsBlack(x + delta, y))
                {
                    SetPixel(x, y, true);
                    copied = true;
                }
                if (vertical && IsBlack(x, y + delta))
                {
                    SetPixel(x, y, true);
                    copied = true;
                }
                if (!copied && vertical && horizontal && IsBlack(x + delta, y + delta))
                {
                    SetPixel(x, y, true);
                    copied = true;
                }
            }
        }

        public ImageBlock[] GetBlocks(CustomDeskewInfo deskewInfo)
        {
            var blocks = new List<ImageBlock>();
            var xHeight = Height - deskewInfo.MarginBottom;
            var xWidth = Width - deskewInfo.MarginRight;
            var rows = (int)Math.Ceiling((double)xHeight / deskewInfo.Height);
            var cols = (int)Math.Ceiling((double)xWidth / deskewInfo.Width);
            var ibs = new ImageBlock[rows, cols];
            int x = deskewInfo.MarginLeft;
            int y = deskewInfo.MarginTop;
            int w = deskewInfo.Width;
            int h = deskewInfo.Height;
            for (int i = 0; i < rows; i++)
            {
                if ((y + h) > xHeight)
                {
                    h = xHeight - y;
                }
                x = deskewInfo.MarginLeft;
                w = deskewInfo.Width;
                for (int j = 0; j < cols; j++)
                {
                    if ((x + w) > xWidth)
                    {
                        w = xWidth - x;
                    }
                    ibs[i, j] = new ImageBlock() { Left = x, Top = y, Width = w, Height = h };
                    x = x + w;
                }
                y = y + h;
            }
            ImageBlock ib = null;
            ImageBlock ibx = null;
            if (deskewInfo.MarginLeft > 0)
            {
                blocks.Add(new ImageBlock() { IsMargin = true, Left = 0, Top = 0, Width = deskewInfo.MarginLeft, Height = this.Height });
            }
            if (deskewInfo.MarginRight > 0)
            {
                blocks.Add(new ImageBlock() { IsMargin = true, Left = this.Width - deskewInfo.MarginRight, Top = 0, Width = deskewInfo.MarginRight, Height = this.Height });
            }
            if (deskewInfo.MarginTop > 0)
            {
                blocks.Add(new ImageBlock() { IsMargin = true, Left = deskewInfo.MarginLeft, Top = 0, Width = this.Width - deskewInfo.MarginLeft - deskewInfo.MarginRight, Height = deskewInfo.MarginTop });
            }
            if (deskewInfo.MarginBottom > 0)
            {
                blocks.Add(new ImageBlock() { IsMargin = true, Left = deskewInfo.MarginLeft, Top = this.Height - deskewInfo.MarginBottom, Width = this.Width - deskewInfo.MarginLeft - deskewInfo.MarginRight, Height = deskewInfo.MarginBottom });
            }
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    ib = ibs[i, j];
                    if (ib != null)
                    {
                        ibx = MaxRowColumn(ibs, i, j, rows, cols);
                        if (ibx != null && ib != ibx)
                        {
                            ib.Width = (ibx.Right - ib.Left) + 1;
                            ib.Height = (ibx.Bottom - ib.Top) + 1;
                        }
                    }
                    ib = ibs[i, j];
                    if (ib != null && ib.Width > 0 && ib.Height > 0)
                    {
                        if (ib.Width > deskewInfo.Width || ib.Height > deskewInfo.Height || AnyBlack(ib.Left, ib.Top, ib.Width, ib.Height))
                        {
                            blocks.Add(ib);
                        }
                    }
                }
            }
            return blocks.ToArray();
        }

        private ImageBlock MaxRowColumn(ImageBlock[,] blocks, int y, int x, int rows, int cols)
        {
            var ib = blocks[y, x];
            if (ib == null)
            {
                return ib;
            }
            int my = y;
            int mx = MaxColumn(blocks, y, x, rows, cols);
            int cx;
            int cy;
            int j = x;
            while (j <= mx)
            {
                cy = MaxRow(blocks, j, my, rows, cols);
                if (cy > my)
                {
                    for (int i = my; i <= cy; i++)
                    {
                        cx = MaxColumn(blocks, i, mx, rows, cols);
                        if (cx > mx)
                        {
                            mx = AdjustMaxColumnForPrevious(blocks, y, i, cx, rows, cols);
                        }
                    }
                    my = AdjustMaxRowForPrevious(blocks, x, j, cy, rows, cols);
                }
                j++;
            }
            if (mx != x || my != y)
            {
                ib = blocks[my, mx];
                for (int iy = y; iy <= my; iy++)
                {
                    for (int ix = x; ix <= mx; ix++)
                    {
                        if (iy != y || ix != x)
                        {
                            blocks[iy, ix] = null;
                        }
                    }
                }
            }
            return ib;
        }

        private int AdjustMaxColumnForPrevious(ImageBlock[,] blocks, int startY, int endY, int x, int rows, int cols)
        {
            int cx = x;
            int mx = x;
            if (endY > startY)
            {
                for (int k = startY; k < endY; k++)
                {
                    cx = MaxColumn(blocks, k, x, rows, cols);
                    if (cx > mx)
                    {
                        mx = cx;
                        if (k > startY)
                        {
                            AdjustMaxColumnForPrevious(blocks, startY, k, mx, rows, cols);
                        }
                    }
                }
            }
            return mx;
        }

        private int MaxColumn(ImageBlock[,] blocks, int row, int startX, int rows, int cols)
        {
            var lastCol = cols - 1;
            for (int i = startX; i < cols; i++)
            {
                if (i == lastCol)
                {
                    return i;
                }
                var ib = blocks[row, i];
                if (ib == null)
                {
                    return i - 1;
                }
                if (!AnyBlack(ib.Right, ib.Top, 1, ib.Height))
                {
                    //SetPixel(ib.Right - 2, ib.Top, 1, ib.Height, true);
                    return i;
                }
            }
            return cols - 1;
        }

        private int AdjustMaxRowForPrevious(ImageBlock[,] blocks, int startX, int endX, int y, int rows, int cols)
        {
            int cy = y;
            int my = y;
            if (endX > startX)
            {
                for (int k = startX; k < endX; k++)
                {
                    cy = MaxRow(blocks, k, y, rows, cols);
                    if (cy > my)
                    {
                        my = cy;
                        if (k > startX)
                        {
                            AdjustMaxRowForPrevious(blocks, startX, k, my, rows, cols);
                        }
                    }
                }
            }
            return my;
        }

        private int MaxRow(ImageBlock[,] blocks, int column, int startY, int rows, int cols)
        {
            var lastRow = rows - 1;
            for (int i = startY; i < rows; i++)
            {
                if (i == lastRow)
                {
                    return i;
                }
                var ib = blocks[i, column];
                if (ib == null)
                {
                    return i - 1;
                }
                if (!AnyBlack(ib.Left, ib.Bottom, ib.Width, 2))
                {
                    //SetPixel(ib.Left, ib.Bottom-3, ib.Width-2, 1, true);
                    return i;
                }
            }
            return rows - 1;
        }

        public bool AnyBlack(int x, int y, int w, int h)
        {
            for (int i = 0; i < h; i++)
            {
                for (int j = 0; j < w; j++)
                {
                    if (IsBlack(x + j, y + i))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private byte[] PixelsAsBytes()
        {
            var size = _BW.Count;
            var bytes = new byte[size];
            for (int i = 0; i < size; i++)
            {
                if (_BW.Get(i))
                {
                    bytes[i] = 1;
                }
            }
            return bytes;
        }

        private void PixelsFromBytes(byte[] bytes)
        {
            var size = _BW.Count;
            for (int i = 0; i < size; i++)
            {
                _BW.Set(i, bytes[i] > 0);
            }
        }

        public void UpdatePixelsBasedOnNeighbors(byte minValue, int repeatCount)
        {
            if (repeatCount > 0 && minValue > 1)
            {
                byte total;
                int offset;
                int idx;
                int xdx;
                int width = Width;
                int xw = width - 1;
                int height = Height;
                int yh = height - 1;
                int sx;
                int sy;
                int ex;
                int ey;
                var bytes = PixelsAsBytes();
                var size = bytes.Length;
                for (int i = 0; i < repeatCount; i++)
                {
                    for (int y = 0; y < height; y++)
                    {
                        offset = y * width;
                        for (int x = 0; x < width; x++)
                        {
                            idx = offset + x;
                            if (bytes[idx] > 0)
                            {
                                total = 0;

                                sy = y;
                                ey = y;
                                if (y > 0)
                                {
                                    sy--;
                                }
                                if (y < yh)
                                {
                                    ey++;
                                }

                                sx = x;
                                ex = x;
                                if (x > 0)
                                {
                                    sx--;
                                }
                                if (x < xw)
                                {
                                    ex++;
                                }

                                for (int yy = sy; yy <= ey; yy++)
                                {
                                    for (int xx = sx; xx <= ex; xx++)
                                    {
                                        if (bytes[(yy * width) + xx] > 0)
                                        {
                                            total++;
                                        }
                                    }
                                }

                                bytes[idx] = total;
                            }
                        }
                    }

                    for (int j = 0; j < size; j++)
                    {
                        if (bytes[j] < minValue)
                        {
                            if (bytes[j] > 0)
                            {
                                bytes[j] = 0;
                            }
                        }
                        else
                        {
                            bytes[j] = 1;
                        }
                    }
                }
                PixelsFromBytes(bytes);
            }
        }
    }
}
