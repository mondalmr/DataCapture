﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public enum DataCaptureElementType
    {
        General,
        MultilineElement1,
        CertificateAmt,
        CertificateNo,
        PrescribedRate,
        Nature,
        IntCol4,
        //MarksNos,
        //GoodsDescription,
        //Containers,
        //SealNos,
        ChallanNo,
        SectionCode,
        TAN,
        AssessmentYear,
        TDS,
        Surcharge,
        EducationCess,
        Interest,
        Fee,
        Others,
        TotalTax,
        BranchCode,
        BankName,
        DepositDate,
        MinorHead,
        Remarks,
        CertAckNo,
        CertDate,
        PANNo,
        CertName,
        //BLTextBody,
        PackageGrid,
        IntCol3,
        FromDate,
        ToDate,
        //PackageNetMeasure,
        //PackageNetMeasureUM,
        //PreCarriage,
        //PlaceReceipt,
        //OceanVessel,
        //OceanVoyage,
        //PortLoading,
        //PortDischarge,
        //PlaceDelivery,
        //ExportReference,
        TextAreaElement1,
        //Por,
        //Pori,
        //PorType,
        //OriginPlace,
        //FinalDestination        
    }
}
