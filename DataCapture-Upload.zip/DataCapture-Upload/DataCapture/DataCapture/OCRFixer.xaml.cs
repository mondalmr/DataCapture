﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for OCRFixer.xaml
    /// </summary>
    public partial class OCRFixer : Window
    {
        double LeftColumnWidth;
        double RightColumnWidth;

        public OCRFixer()
        {
            InitializeComponent();
        }

        public bool AcceptsReturn
        {
            get
            {
                return TBPost.AcceptsReturn;
            }
            set
            {
                TBPost.AcceptsReturn = value;
            }
        }

        public bool AcceptsTab
        {
            get
            {
                return TBPost.AcceptsTab;
            }
            set
            {
                TBPost.AcceptsTab = value;
            }
        }

        private void ApplyAll()
        {
            var task = DataContext as OCRPostTask;
            if (task != null)
            {
                var text = task.Original;
                if (!string.IsNullOrWhiteSpace(text))
                {
                    if (task.Rules != null)
                    {
                        foreach (var rule in task.Rules)
                        {
                            if (rule != null && rule.IsChecked)
                            {
                                text = rule.Rule.Apply(text);
                            }
                        }
                    }
                }
                task.Fixed = text;
            }
        }

        private void BApply_Click(object sender, RoutedEventArgs e)
        {
            ApplyAll();
        }

        private void BAccept_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void BCollapseRight_Click(object sender, RoutedEventArgs e)
        {
            if (ContentLeftColumn.Width.Value == 0)
            {
                ContentLeftColumn.Width = new GridLength(LeftColumnWidth, GridUnitType.Pixel);
            }
            else if (ContentRightColumn.ActualWidth > 0)
            {
                RightColumnWidth = ContentRightColumn.ActualWidth;
                ContentRightColumn.Width = new GridLength(0, GridUnitType.Pixel);
                ContentLeftColumn.Width = new GridLength(1, GridUnitType.Star);
            }
        }

        private void BCollapseLeft_Click(object sender, RoutedEventArgs e)
        {
            if (ContentRightColumn.Width.Value == 0)
            {
                ContentRightColumn.Width = new GridLength(RightColumnWidth, GridUnitType.Pixel);
            }
            else if (ContentLeftColumn.ActualWidth > 0)
            {
                LeftColumnWidth = ContentLeftColumn.ActualWidth;
                ContentLeftColumn.Width = new GridLength(0, GridUnitType.Pixel);
                ContentRightColumn.Width = new GridLength(1, GridUnitType.Star);
            }
        }

        private void BRule_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null)
            {
                var check = button.Parent as CheckBox;
                if (check != null)
                {
                    var postInfo = check.DataContext as OCRPostInfo;
                    if (postInfo != null && !postInfo.IsChecked)
                    {
                        postInfo.IsChecked = true;
                        ApplyAll();
                    }
                }
            }
        }
    }
}
