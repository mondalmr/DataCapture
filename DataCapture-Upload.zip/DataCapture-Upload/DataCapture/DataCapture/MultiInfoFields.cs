﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public static class MultiInfoFields
    {
        //public const string PCT = "PCT";
        public const string Line1 = "Line1";
        public const string Line2 = "Line2";
        public const string Line3 = "Line3";
        public const string Line4 = "Line4";
        public const string Line5 = "Line5";
        public const string Line6 = "Line6";        
    }
}
