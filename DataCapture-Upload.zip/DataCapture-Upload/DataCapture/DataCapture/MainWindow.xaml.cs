﻿using DataCapture.DTO;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.IO.Compression;

namespace DataCapture
{    
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public static RoutedCommand Command = new RoutedCommand("Command", typeof(MainWindow));
        const string StartOver = "StartOver";
        const string OpenSource = "OpenSource";
        const string OpenTemplate = "OpenTemplate";
        DataTable _capturedChallans = new DataTable();

        const string ControlK = "ControlK";
        //const string ControlDot = "ControlDot";
        const string ControlQ = "ControlQ";
        //const string ControlPlus = "ControlPlus";

        const string NextPage = "NextPage";
        const string PreviousPage = "PreviousPage";        

        const string ZoomIn = "ZoomIn";
        const string ZoomOut = "ZoomOut";

        const string Undo = "Undo";
        const string Redo = "Redo";

        const string DCT = ".dct";
        
        const string TemplateExtension = "Template (*" + DCT + ")|*" + DCT;        
        static string DCFileExtension = "";
        static DataCaptureElement[] DCELMENTS = null;
        static IDCReader[] DCREADERS = null;
        internal double PageWidth;
        internal double PageHeight;
        double LeftColumnWidth;
        double RightColumnWidth;        
        double ImageScaleWidth;
        double ImageScaleHeight;        
        ImageOptions _ImageOptions;
        DataCaptureInfo Dc;
        FrameworkElement Rectangle2Move;
        Point RectangleXY2Move;
        Image ImageBox;        
        Ellipse MouseEllipse;
        double MagnifyingGlassSize = 100;
        List<ImageAction> _ImageActions;
        List<FrameworkElement> AdjustElements;
        ObservableCollection<Size> _shortCutBoxes;
        ObservableCollection<ShortCutKeyInfo> _shortCutKeys;
        List<Rectangle> _ActionRects;
        string _WordCuts;
        ObservableCollection<ReplaceInfo> _Replacements;        
        UndoRedoRectangle _UndoRedoRectangle = null;        
        string _Instance;
        List<PDFTextRect> _TextCollection;
        List<DrawingPath> _DrawingPaths;        

        public static MainWindow Current
        {
            get
            {
                if (Application.Current != null)
                {
                    return Application.Current.MainWindow as MainWindow;
                }
                return null;
            }
        }

        public MainWindow()
        {
            TrySetupDirectories();

            CommandBindings.Add(new CommandBinding(Command, new ExecutedRoutedEventHandler(ShortCutHandler)));

            //InputBindings.Add(new KeyBinding(Command, Key.Space, ModifierKeys.Control) { CommandParameter = StartOver });
            //InputBindings.Add(new KeyBinding(Command, Key.S, ModifierKeys.Control) { CommandParameter = OpenSource });
            //InputBindings.Add(new KeyBinding(Command, Key.T, ModifierKeys.Control) { CommandParameter = OpenTemplate });


            //InputBindings.Add(new KeyBinding(Command, Key.K, ModifierKeys.Control) { CommandParameter = ControlK });
            //InputBindings.Add(new KeyBinding(Command, Key.Q, ModifierKeys.Control) { CommandParameter = ControlQ });

            //InputBindings.Add(new KeyBinding(Command, Key.N, ModifierKeys.Control) { CommandParameter = NextPage });
            //InputBindings.Add(new KeyBinding(Command, Key.P, ModifierKeys.Control) { CommandParameter = PreviousPage });
            
            //InputBindings.Add(new KeyBinding(Command, Key.I, ModifierKeys.Control) { CommandParameter = ZoomIn });
            //InputBindings.Add(new KeyBinding(Command, Key.O, ModifierKeys.Control) { CommandParameter = ZoomOut });

            //InputBindings.Add(new KeyBinding(Command, Key.Z, ModifierKeys.Control) { CommandParameter = Undo });
            //InputBindings.Add(new KeyBinding(Command, Key.Y, ModifierKeys.Control) { CommandParameter = Redo });

            _UndoRedoRectangle = null;
            _Replacements = new ObservableCollection<ReplaceInfo>();
            _WordCuts = "";            
            _TextCollection = new List<PDFTextRect>();
            _DrawingPaths = new List<DrawingPath>();
            _ActionRects = new List<Rectangle>();
            _ImageActions = new List<ImageAction>();
            AdjustElements = new List<FrameworkElement>();
            ShortCutSizes = new ObservableCollection<Size>();
            _shortCutKeys = new ObservableCollection<ShortCutKeyInfo>();

            InitializeComponent();
            DeskewInfo = new CustomDeskewInfo() { Width = 40, Height = 20, MarginLeft = 20, MarginTop = 20, MarginBottom = 20, MarginRight = 20 };

            LeftColumnWidth = 0;
            RightColumnWidth = 0;
            if (DCELMENTS == null)
            {
                int totalfonts = iTextSharp.text.FontFactory.RegisterDirectory("C:\\WINDOWS\\Fonts");
                StringBuilder sb = new StringBuilder();
                foreach (string fontname in iTextSharp.text.FontFactory.RegisteredFonts)
                {
                    sb.Append(fontname + "\n");
                }
                string list = sb.ToString();

                Color shortCutInfoColor = (Color)ColorConverter.ConvertFromString("#EAEAEA");

                shortCutInfoColor = Colors.White;

                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + Space", "New S/I", shortCutInfoColor, NewSI));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + S", "Open S/I", shortCutInfoColor, OpenSI));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + T", "Open Template", shortCutInfoColor, OpenTemplate));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + W", "Open WorkFile", shortCutInfoColor, OpenWork));

                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + P", "Previous Page", shortCutInfoColor, PreviousPage));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + N", "Next Page", shortCutInfoColor, NextPage));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + M", "Magnify Option", shortCutInfoColor, MagnifyOption));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + I", "Zoom In", shortCutInfoColor, ZoomIn));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + O", "Zoom Out", shortCutInfoColor, ZoomOut));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + Z", "Undo", shortCutInfoColor, Undo));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + Y", "Redo", shortCutInfoColor, Redo));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + K", "OCR Fix", Colors.Gray));
                //ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + Q", "Word List", Colors.Gray));

                DCELMENTS = new DataCaptureElement[]{
                    RegisterDCElement(DataCaptureElementType.ChallanNo, "Challan No",  Colors.LightGray, RBChallanNo),
                    RegisterDCElement(DataCaptureElementType.SectionCode, "Section Code", Colors.Gray, RBSectionCode),
                    RegisterDCElement(DataCaptureElementType.TAN, "TAN", Colors.Orange, RBTAN),
                    RegisterDCElement(DataCaptureElementType.AssessmentYear,"AssessmentYear",Colors.AliceBlue,RBAssessmentYear),
                    RegisterDCElement(DataCaptureElementType.TDS,"TDS",Colors.Blue,RBTDS),
                    RegisterDCElement(DataCaptureElementType.Surcharge,"Surcharge",Colors.Tomato,RBSurcharge),
                    RegisterDCElement(DataCaptureElementType.EducationCess,"EducationCess",Colors.Cyan,RBEducationCess),
                    RegisterDCElement(DataCaptureElementType.Interest,"Interest",Colors.DarkGoldenrod,RBInterest),
                    RegisterDCElement(DataCaptureElementType.Fee,"Fee",Colors.DarkGreen, RBFee),
                    RegisterDCElement(DataCaptureElementType.Others,"Others",Colors.DarkKhaki,RBOthers),
                    RegisterDCElement(DataCaptureElementType.TotalTax,"TotalTax",Colors.DarkRed,RBTotalTax),
                    RegisterDCElement(DataCaptureElementType.BranchCode,"BranchCode",Colors.DarkViolet,RBBranchCode),
                    RegisterDCElement(DataCaptureElementType.BankName, "BankName", Colors.Gainsboro, RBBankName),
                    RegisterDCElement(DataCaptureElementType.DepositDate, "DepositDate", Colors.HotPink, RBDepositDate),
                    RegisterDCElement(DataCaptureElementType.MinorHead, "MinorHead", Colors.LavenderBlush, RBMinorHead),
                    RegisterDCElement(DataCaptureElementType.Remarks, "Remarks", Colors.LightSalmon, RBRemarks),

                    RegisterDCElement(DataCaptureElementType.CertAckNo, "CertAckNo", Colors.Thistle, RBCertAckNo),
                    RegisterDCElement(DataCaptureElementType.CertDate, "CertDate", Colors.Teal, RBCertDate),
                    RegisterDCElement(DataCaptureElementType.PANNo, "PANNo", Colors.SteelBlue, RBPANNo),
                    RegisterDCElement(DataCaptureElementType.CertName, "CertName", Colors.SpringGreen, RBCertName),


                    //RegisterDCElement(DataCaptureElementType.Containers, "Containers", Colors.Olive, RBContainers),
                    //RegisterDCElement(DataCaptureElementType.SealNos, "Seal No.(s)", Colors.Cyan, RBSealNos),

                    RegisterDCElement(DataCaptureElementType.General, "General", Colors.Yellow, RBGeneral),
                    //RegisterDCElement(DataCaptureElementType.MultilineElement1, "MultilineElement1", Colors.Red, RBMultilineElement1, "Alt + S", Key.S),
                                                           
                    //RegisterDCElement(DataCaptureElementType.TextAreaElement1, "TextAreaElement1", Colors.Navy, RBTextAreaElement1, "Alt + T", Key.T),
                    

                    //RegisterDCElement(DataCaptureElementType.MarksNos, "Marks & Nos", Colors.LightGreen, RBMarksNos, "Alt + M", Key.M),
                    //RegisterDCElement(DataCaptureElementType.GoodsDescription, "Goods Description", Colors.Orange, RBGoodsDescription, "Alt + G", Key.G),

                    RegisterDCElement(DataCaptureElementType.CertificateAmt, "CertificateAmt", Colors.DarkCyan, RBCertificateAmt),
                    RegisterDCElement(DataCaptureElementType.CertificateNo, "CertificateNo", Colors.DarkSlateGray, RBCertificateNo),

                    RegisterDCElement(DataCaptureElementType.PrescribedRate, "PrescribedRate", Colors.Blue, RBPrescribedRate),
                    RegisterDCElement(DataCaptureElementType.Nature, "Nature", Colors.Fuchsia, RBNature),

                    //RegisterDCElement(DataCaptureElementType.IntCol3, "IntCol3", Colors.LightCoral, RBPkgMeasure),
                    RegisterDCElement(DataCaptureElementType.FromDate, "FromDate", Colors.RosyBrown, RBFromDate),

                    //RegisterDCElement(DataCaptureElementType.IntCol4, "IntCol4", Colors.CornflowerBlue, RBPkgNetWeight),
                    RegisterDCElement(DataCaptureElementType.ToDate, "ToDate", Colors.Plum, RBToDate),
                    
                    //RegisterDCElement(DataCaptureElementType.PackageNetMeasure, "Package N/M", Colors.Crimson, RBPkgNetMeasure),
                    //RegisterDCElement(DataCaptureElementType.PackageNetMeasureUM, "Package N/M UM", Colors.Chartreuse, RBPkgUMNetMeasure),

                    RegisterDCElement(DataCaptureElementType.PackageGrid, "Package Grid", Colors.YellowGreen, RBGrid, "Alt + P", Key.P)
                   
                    //RegisterBLElement(DataCaptureElementType.BLTextBody, "BL Text Body", Colors.LightYellow, RBTextBody)
                };


                ShortCutKeys.Add(new ShortCutKeyInfo("Ctrl + DoubleClick", "Package Grid Row", Colors.Gray));
                ShortCutKeys.Add(new ShortCutKeyInfo("Shift + DoubleClick", "Package Grid Column", Colors.Gray));
                ShortCutKeys.Add(new ShortCutKeyInfo("Alt + DoubleClick", "Package Grid Content", Colors.Gray));


                DCREADERS = new IDCReader[]{
                    new PDFSIReader(this),
                    new ImageSIReader(this),
                    new MSExcelSIReader(this),
                    new MSWordSIReader(this)
                };

                sb.Clear();
                foreach (IDCReader reader in DCREADERS)
                {
                    if (sb.Length > 0)
                    {
                        sb.Append("|");
                    }
                    sb.Append(" ");
                    sb.Append(reader.Description);
                    sb.Append(" |");
                    string sep = "";
                    foreach (string ext in reader.SupportedExtensions)
                    {
                        sb.Append(sep);
                        sb.Append(" *.");
                        sb.Append(ext);
                        sep = ";";
                    }
                }
                DCFileExtension = sb.ToString().Trim();
            }
            Loaded += MainWindow_Loaded;
            Closing += MainWindow_Closing;

            _capturedChallans.Columns.Clear();
            _capturedChallans.Columns.Add("ChallanNo");
            _capturedChallans.Columns.Add("DepositeDate");
            _capturedChallans.Columns.Add("AssessmentYear");
            _capturedChallans.Columns.Add("Tan");
            _capturedChallans.Columns.Add("Section");
            _capturedChallans.Columns.Add("MinorHead");
            _capturedChallans.Columns.Add("BankName");
            _capturedChallans.Columns.Add("BranchCode");
            _capturedChallans.Columns.Add("TDS");
            _capturedChallans.Columns.Add("Surcharge");
            _capturedChallans.Columns.Add("Ecess");
            _capturedChallans.Columns.Add("Others");
            _capturedChallans.Columns.Add("Interest");
            _capturedChallans.Columns.Add("Fee(234E)");
            _capturedChallans.Columns.Add("TotalTax");
        }        

        //public UnitList CachedUnitList
        //{
        //    get
        //    {
        //        if (_UnitList == null)
        //        {
        //        }
        //        return _UnitList;
        //    }
        //}       

        public ImageAction[] CurrentPageActions
        {
            get
            {
                if (_ImageActions != null)
                {
                    return _ImageActions.Where(p => p.Page == CurrentPage).ToArray();
                }
                return null;
            }
        }

        public ImageAction[] ImageActions
        {
            get
            {
                if (_ImageActions != null)
                {
                    return _ImageActions.ToArray();
                }
                return null;
            }
            set
            {
                if (_ImageActions == null)
                {
                    _ImageActions = new List<ImageAction>();
                }
                else
                {
                    _ImageActions.Clear();
                }
                if (value != null)
                {
                    _ImageActions.AddRange(value);
                }
            }
        }

        bool _ImageExists;
        public bool ImageExists
        {
            get
            {
                return _ImageExists;
            }
            set
            {
                _ImageExists = value;
                RaisePropertyChanged("ImageExists");
            }
        }

        bool _TextExists;
        public bool TextExists
        {
            get
            {
                return _TextExists;
            }
            set
            {
                _TextExists = value;
                RaisePropertyChanged("TextExists");
            }
        }

        //bool _AlternateFontVisible;
        //public bool AlternateFontVisible
        //{
        //    get
        //    {
        //        return _AlternateFontVisible;
        //    }
        //    set
        //    {
        //        if (_AlternateFontVisible != value)
        //        {
        //            _AlternateFontVisible = value;
        //            RaisePropertyChanged("AlternateFontVisible");
        //        }
        //    }
        //}

        public CustomDeskewInfo DeskewInfo
        {
            get;
            set;
        }

        public string ImageFlip
        {
            get
            {
                if (imageFlip != null && imageFlip.SelectedValue is string)
                {
                    return (string)imageFlip.SelectedValue;
                }
                return "";
            }
        }

        public ImageOptions ImageOptions
        {
            get
            {
                return _ImageOptions;
            }
            set
            {
                _ImageOptions = value;
            }
        }

        private bool AllowPartial
        {
            get
            {
                return false;
            }
        }

        public System.Drawing.Bitmap Bitmap
        {
            get;
            set;
        }

        public System.Drawing.Bitmap TextBitmap
        {
            get;
            set;
        }

        public ObservableCollection<Size> ShortCutSizes
        {
            get
            {
                return _shortCutBoxes;
            }
            private set
            {
                _shortCutBoxes = value;
                RaisePropertyChanged("ShortCutSizes");
            }
        }

        public ObservableCollection<ShortCutKeyInfo> ShortCutKeys
        {
            get
            {
                return _shortCutKeys;
            }
            private set
            {
                _shortCutKeys = value;
                RaisePropertyChanged("ShortCutKeys");
            }
        }

        public string WordCutText
        {
            get
            {
                return _WordCuts;
            }
            set
            {
                _WordCuts = value;                
            }
        }

        public ReplaceInfo[] Replacements
        {
            get
            {
                return _Replacements.ToArray();
            }
            set
            {
                _Replacements.Clear();
                if (value != null)
                {
                    foreach (var ri in value)
                    {
                        if (ri != null)
                        {
                            _Replacements.Add(ri);
                        }
                    }
                }
                
            }
        }

        public Brush ShortCutFill
        {
            get
            {
                var element = SelectedElement;
                if (element != null)
                {
                    bool useFill = true;//CFilledBoxes.IsChecked == true;
                    return element.GetFillBrush(useFill);
                }
                return Brushes.White;
            }
        }

        public Brush ShortCutStroke
        {
            get
            {
                var element = SelectedElement;
                if (element != null)
                {
                    bool useFill = true;// CFilledBoxes.IsChecked == true;
                    if (useFill)
                    {
                        return Brushes.Black;
                    }
                    return element.GetBorderBrush();
                }
                return Brushes.Black;
            }
        }

        private DataCaptureElement RegisterDCElement(DataCaptureElementType dcElementType, string name, Color color, RadioButton widget, string inputGestureText = "", params Key[] keys)
        {
            if (widget != null)
            {
                widget.IsTabStop = false;
                widget.FontSize = 9;
                widget.FontWeight = FontWeights.Bold;
                if (widget != RBGeneral)
                {
                    ContextMenu cm = FindResource("CMClearData") as ContextMenu;
                    if (cm != null)
                    {
                        widget.ContextMenu = cm;
                    }
                }
                widget.Checked += widget_Checked;
            }
            if (keys != null)
            {
                foreach (var key in keys)
                {
                    InputBindings.Add(new KeyBinding(Command, key, ModifierKeys.Alt) { CommandParameter = dcElementType });
                }
            }
            if (!string.IsNullOrWhiteSpace(inputGestureText) && widget != null)
            {
                ShortCutKeys.Add(new ShortCutKeyInfo(inputGestureText, name, color, dcElementType));
            }
            return new DataCaptureElement(dcElementType, name, color, widget, "CMDefault", inputGestureText);
        }

        void ShortCutHandler(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command != null)
            {
                ExecuteShortCut(e.Parameter);
            }
        }

        private void BShortCutInfo_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null)
            {
                ExecuteShortCut(button.Tag);
            }
        }

        private void ExecuteShortCut(object tag)
        {
            if (tag is string)
            {
                var cmd = tag as string;
                switch (cmd)
                {
                    case StartOver:
                        Prepare4New(false);
                        break;

                    case OpenSource:
                        FileOpen_Click(null, null);
                        break;

                    case OpenTemplate:
                        TemplateOpen_Click(null, null);
                        break;                    
                        
                    case NextPage:
                    case PreviousPage:
                        if (pager != null && pager.Items != null && pager.Items.Count > 1)
                        {
                            int idx = pager.SelectedIndex + 1;
                            if (PreviousPage.Equals(cmd))
                            {
                                idx = pager.SelectedIndex - 1;
                            }
                            if (idx >= 0 && idx < pager.Items.Count)
                            {
                                pager.SelectedIndex = idx;
                            }
                        }
                        break;                    

                    case ZoomIn:
                    case ZoomOut:
                        if (zoomer != null && zoomer.Items != null)
                        {
                            var idx = zoomer.SelectedIndex + (ZoomOut.Equals(cmd) ? -1 : 1);
                            if (idx >= 0 && idx < zoomer.Items.Count)
                            {
                                zoomer.SelectedIndex = idx;
                            }
                        }
                        break;

                    case Undo:
                        UndoRedoManager.Current.Undo();
                        break;

                    case Redo:
                        UndoRedoManager.Current.Redo();
                        break;
                }
            }
            else if (tag is DataCaptureElementType && DCELMENTS != null)
            {
                var dcElementType = (DataCaptureElementType)tag;
                FrameworkElement rect = null;
                var element = DCELMENTS.Where(p => p.DCElementType == dcElementType).FirstOrDefault();
                if (element != null)
                {
                    rect = element.GetRectangle(CurrentPage);
                    if ((rect == null || !rect.IsVisible || rect.ActualWidth <= 0 || rect.ActualHeight <= 0) && dcElementType != DataCaptureElementType.PackageGrid)
                    {
                        rect = null;
                        element = DCELMENTS.Where(p => p.DCElementType == DataCaptureElementType.General).FirstOrDefault();
                        rect = element.GetRectangle(CurrentPage);
                        if (rect == null || !rect.IsVisible || rect.ActualWidth <= 0 || rect.ActualHeight <= 0)
                        {
                            MessageBox.Show("Please highlight region first. You can either highlight the region with specific type or General.");
                            return;
                        }
                    }
                }
                if (element != null)
                {
                    if (rect != null && rect.IsVisible && rect.ActualWidth > 0 && rect.ActualHeight > 0)
                    {
                        if (rect is Grid)
                        {
                            ApplyPackageGrid(rect as Grid);
                        }
                        else
                        {
                            ApplyText(dcElementType, rect, false, false, true);
                        }
                    }
                }
            }
        }

        void widget_Checked(object sender, RoutedEventArgs e)
        {
            var rb = sender as RadioButton;
            if (rb != null)
            {
                RaisePropertyChanged("ShortCutFill");
                RaisePropertyChanged("ShortCutStroke");
            }
        }

        void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            //Window tempWindow = GRightPanel.Parent as Window;
            //if (tempWindow != null)
            //{
            //    DockUndockRightPanel(false);
            //}
            //if (Magnifier != null)
            //{
            //    Magnifier.Close();
            //}
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            string appVersion = string.Empty;
            if (Dc == null)
            {
                string title = "Data Capture ";
                try
                {                    
                    var version = Assembly.GetExecutingAssembly().GetName().Version;
                    if (version != null)
                    {
                        title = title + "(Version: " + version.Major + "." + version.Minor + ")";
                        appVersion = version.Major + "." + version.Minor;
                    }
                }
                catch (Exception ex)
                {
                }
                if (!string.IsNullOrWhiteSpace(title))
                {
                    Title = title;
                }
                var worker = new BackgroundWorker();
                worker.DoWork += (bw, args) =>
                    {
                        var msg = "";                        
                    };
                worker.RunWorkerAsync();

                var stroke = new LinearGradientBrush();
                stroke.StartPoint = new Point(0, 0);
                stroke.EndPoint = new Point(0, 1);
                stroke.GradientStops.Add(new GradientStop(Color.FromRgb(200, 200, 200), 0));
                stroke.GradientStops.Add(new GradientStop(Color.FromRgb(150, 150, 150), 1));

                MouseEllipse = new Ellipse();
                MouseEllipse.Stroke = stroke;
                MouseEllipse.Width = MagnifyingGlassSize;
                MouseEllipse.Height = MagnifyingGlassSize;
                MouseEllipse.Visibility = Visibility.Hidden;
                Canvas.SetZIndex(MouseEllipse, 300);

                _ImageOptions = new ImageOptions();

                var actions = new UndoRedoCollection();

                Dc = new DataCaptureInfo(true);
                Dc.InitializePackageList(actions);
                DataContext = Dc;

                BoxAdorner.RootWindow = this;
                bool isChecked = true;
                foreach (DataCaptureElement element in DCELMENTS)
                {
                    element.Widget.Tag = element;
                    element.Widget.Background = new SolidColorBrush(element.Color);
                }

                SetupContextMenu();
                //SetupShortCuts();

                if (OCRSize != null)
                {
                    OCRSize.Items.Clear();
                    int skip = 5;
                    int i = 50;
                    while (i <= 400)
                    {
                        var selected = false;
                        if (i == 130)
                        {
                            selected = true;
                        }
                        double d = (double)i / 100;
                        OCRSize.Items.Add(new ComboBoxItem() { Content = String.Format("{0:0.00}", d), Tag = "" + d, IsSelected = selected });
                        i = i + skip;
                        if (i >= 200)
                        {
                            skip = 10;
                        }
                    }
                }                
                FileOpen.Focus();
                //SetAllInputTags();
            }
        }

        private void SetupContextMenu()
        {
            MenuItem subMenuItem = null;
            ContextMenu contextMenu;

            //contextMenu = FindResource("CMCtrlQ") as ContextMenu;//contextMenu = FindResource("CMCtrlPlus") as ContextMenu;
            //OCRPostUtils.SetupWordCuts(contextMenu);

            //contextMenu = FindResource("CMCtrlK") as ContextMenu;//contextMenu = FindResource("CMCtrlDot") as ContextMenu;
            //OCRPostUtils.SetupContextMenu(contextMenu);

            contextMenu = FindResource("CMSelectedText") as ContextMenu;
            OCRPostUtils.SetupContextMenu(contextMenu);

            contextMenu = FindResource("CMClearData") as ContextMenu;
            OCRPostUtils.SetupContextMenu(contextMenu);

            contextMenu = FindResource("CMDefault") as ContextMenu;
            if (contextMenu != null && contextMenu.Items != null && DCELMENTS != null)
            {
                foreach (var item in contextMenu.Items)
                {
                    var menuItem = item as MenuItem;
                    if (menuItem != null)
                    {
                        menuItem.VerticalContentAlignment = VerticalAlignment.Center;
                        menuItem.Height = 17;
                        menuItem.Padding = new Thickness(1);
                        menuItem.Margin = new Thickness(3, 0, 0, 0);
                        switch (menuItem.Name)
                        {
                            case "CMApplyGeneral":
                            case "CMAppendGeneral":
                            case "CMInsertGeneral":
                                menuItem.Items.Clear();
                                MenuItem packageMenuItem = null;
                                var sortedElements = DCELMENTS.OrderBy(p => p.Name).ToArray();
                                foreach (DataCaptureElement element in sortedElements)
                                {
                                    if (element != null && element.DCElementType != DataCaptureElementType.General)
                                    {
                                        subMenuItem = new MenuItem();
                                        if ("CMApplyGeneral".Equals(menuItem.Name) && !string.IsNullOrWhiteSpace(element.InputGestureText))
                                        {
                                            subMenuItem.InputGestureText = element.InputGestureText;
                                        }
                                        subMenuItem.Padding = new Thickness(1);
                                        subMenuItem.Margin = new Thickness(3, 0, 0, 0);
                                        subMenuItem.Height = 17;
                                        subMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                                        subMenuItem.Header = element.Name;
                                        subMenuItem.FontWeight = FontWeights.Normal;
                                        subMenuItem.Tag = element.DCElementType;
                                        subMenuItem.Name = menuItem.Name + "_" + element.DCElementType;
                                        subMenuItem.Click += subMenuItem_Click;
                                        if (element.Name != null && element.Name.StartsWith("Package", StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            if (packageMenuItem == null)
                                            {
                                                packageMenuItem = new MenuItem();
                                                packageMenuItem.FontWeight = FontWeights.Bold;
                                                packageMenuItem.Header = "Package";
                                                packageMenuItem.Padding = new Thickness(1);
                                                packageMenuItem.Margin = new Thickness(3, 0, 0, 0);
                                                packageMenuItem.Height = 17;
                                                packageMenuItem.VerticalContentAlignment = VerticalAlignment.Center;
                                                menuItem.Items.Add(packageMenuItem);
                                            }
                                            packageMenuItem.Items.Add(subMenuItem);
                                        }
                                        else
                                        {
                                            menuItem.Items.Add(subMenuItem);
                                        }
                                    }
                                }
                                break;
                        }
                    }
                }
            }
        }

        void subMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = sender as MenuItem;
            if (menuItem != null && menuItem.Name != null && menuItem.Tag is DataCaptureElementType)
            {
                var elementType = (DataCaptureElementType)menuItem.Tag;
                var parentMenu = menuItem.Parent as MenuItem;
                if (parentMenu != null)
                {
                    var ctx = parentMenu.GetContextMenu();
                    if (ctx != null)
                    {
                        string message = null;
                        var rectangle = ctx.PlacementTarget as Rectangle;
                        if (rectangle != null)
                        {
                            DataCaptureElementType blElementType = (DataCaptureElementType)menuItem.Tag;
                            bool append = menuItem.Name.StartsWith("CMAppend");
                            bool insert = menuItem.Name.StartsWith("CMInsert");
                            ApplyText(blElementType, rectangle, append, insert, true);
                        }
                    }
                }
            }
        }

        internal void HighlightAdorner(UIElement element, bool highlight)
        {
            if (element != null)
            {
                var adornerLayer = AdornerLayer.GetAdornerLayer(element);
                if (adornerLayer != null)
                {
                    Adorner[] adorners = adornerLayer.GetAdorners(element);
                    if (adorners != null)
                    {
                        foreach (Adorner adorner in adorners)
                        {
                            if (adorner is BoxAdorner)
                            {
                                ((BoxAdorner)adorner).Highlight(highlight);
                            }
                        }
                    }
                }
            }
        }

        private void SelectRectangle(FrameworkElement rectangle, bool isSelected = true, bool selectParentCanvas = false, Point point = new Point())
        {
            Canvas canvas = null;
            if (rectangle != null)
            {
                canvas = rectangle.Parent as Canvas;
            }
            if (isSelected && selectParentCanvas && canvas != null)
            {
                canvas.Focus();
            }
            if (Rectangle2Move != null)
            {
                if (Rectangle2Move == rectangle)
                {
                    HighlightAdorner(Rectangle2Move, isSelected);
                    RectangleXY2Move = point;
                    return;
                }
                else
                {
                    HighlightAdorner(Rectangle2Move, false);
                }
            }
            if (isSelected)
            {
                Rectangle2Move = rectangle;
            }
            else
            {
                Rectangle2Move = null;
            }
            RectangleXY2Move = point;
            HighlightAdorner(Rectangle2Move, isSelected);
        }

        public void InitUndoRedoRectangle(DataCaptureElement blElement)
        {
            if (blElement != null)
            {
                _UndoRedoRectangle = new UndoRedoRectangle(blElement, this, CurrentPage);
            }
            else
            {
                _UndoRedoRectangle = null;
            }
        }

        public void RegisterUnderRedoRectangle()
        {
            if (_UndoRedoRectangle != null)
            {
                if (_UndoRedoRectangle.UpdateNewValues())
                {
                    UndoRedoManager.Current.AddUndoAction(_UndoRedoRectangle);
                }
                _UndoRedoRectangle = null;
            }
        }

        private bool BrowseFile(TextBox textBox, string filter, Window window = null)
        {
            if (window == null)
            {
                window = this;
            }
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = filter;
            dlg.CheckFileExists = true;
            dlg.CheckPathExists = true;
            bool? result = dlg.ShowDialog(window);
            if (result == true)
            {
                textBox.Text = dlg.FileName;
            }
            return result == true;
        }

        private void TemplateOpen_Click(object sender, RoutedEventArgs e)
        {
            if (!BrowseFile(TemplatePath, TemplateExtension))
            {
                return;
            }
            OpenTemplateFile(TemplatePath.Text.Trim());
        }

        private void OpenTemplateFile(string filePath)
        {
            if (!string.IsNullOrWhiteSpace(filePath))
            {
                try
                {
                    XmlUtils.LoadTemplate(this, filePath, DCELMENTS, Dc);
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(this, "Could not find Template " + filePath + ".");
                }
                catch (InvalidCastException)
                {
                    MessageBox.Show(this, "File " + filePath + " does not contain a valid template.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Could not open Template " + filePath + ".\nException occurred " + ex.Message + "\n" + ex.ToString());
                    ex.LogException();
                }
            }
        }

        private void TemplateSave_Click(object sender, RoutedEventArgs e)
        {
            SaveTemplate(TemplatePath.Text.Trim());
        }

        private void TemplateSaveAs_Click(object sender, RoutedEventArgs e)
        {
            SaveTemplate("");
        }
        //private void ExportCsv_Click(object sender, RoutedEventArgs e)
        //{
        //    ExportToCsv();
        //}

        private void SaveTemplate(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
            {
                var dlg = new SaveFileDialog();
                dlg.OverwritePrompt = true;
                dlg.Filter = TemplateExtension;
                if (dlg.ShowDialog(this) == true)
                {
                    filePath = dlg.FileName;
                }
            }
            if (!string.IsNullOrWhiteSpace(filePath))
            {
                try
                {
                    XmlUtils.SaveTemplate(filePath, DCELMENTS, this);
                    TemplatePath.Text = filePath;
                    MessageBox.Show(this, "Saved to Template " + filePath + ".");
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(this, "Could not find Template " + filePath + ".");
                }
                catch (Exception e)
                {
                    MessageBox.Show(this, "Could not save Template " + filePath + ".\nException occurred " + e.Message + "\n" + e.ToString());
                    e.LogException();
                }
            }
        }       
        
        public Window RightPanelWindow
        {
            get
            {
                Window window = GLeftPanel.Parent as Window;
                if (window == null)
                {
                    window = this;
                }
                return window;
            }
        }

        private void FileOpen_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Multiselect = false;
            if (!string.IsNullOrWhiteSpace(DCFileExtension))
            {
                dlg.Filter = DCFileExtension;
            }
            if (dlg.ShowDialog(RightPanelWindow) == true)
            {
                FilePath.Text = dlg.FileName;
                OpenFile(dlg.FileName);
            }

        }

        public bool IsFileNameSupported(string fileName)
        {
            return GetSIReader(fileName, false) != null;
        }

        public IDCReader GetSIReader(string fileName, bool setCurrentReader = true)
        {
            if (setCurrentReader)
            {
                _SIReader = null;
            }
            IDCReader siReader = null;
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                FileInfo file = new FileInfo(fileName);
                string extension = file.Extension;
                if (extension != null)
                {
                    extension = extension.ToLowerInvariant().Trim();
                    if (extension.StartsWith("."))
                    {
                        extension = extension.Substring(1);
                    }
                    if (!string.IsNullOrWhiteSpace(extension))
                    {
                        foreach (IDCReader reader in DCREADERS)
                        {
                            string[] supportedExtensions = reader.SupportedExtensions;
                            if (supportedExtensions.Contains(extension))
                            {
                                if (setCurrentReader)
                                {
                                    _SIReader = reader;
                                }
                                siReader = reader;
                                break;
                            }
                        }
                    }
                }
            }
            return siReader;
        }

        IDCReader _SIReader;

        internal void OpenFile(string fileName)
        {
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                ClearCanvas(false);
                _ImageActions.Clear();
                _SIReader = GetSIReader(fileName);
                if (_SIReader == null)
                {
                    MessageBox.Show("Sorry! This file type is not supported.");
                    return;
                }
                int pages = 0;
                _SIReader.FilePath = fileName;
                if (!string.IsNullOrWhiteSpace(_SIReader.ErrorMessage))
                {
                    MessageBox.Show(_SIReader.ErrorMessage);
                }
                else
                {
                    pages = _SIReader.PageCount;
                }
                pager.SelectedIndex = -1;
                pager.Items.Clear();
                for (int x = 1; x <= pages; x++)
                {
                    ComboBoxItem cb = new ComboBoxItem();
                    cb.Content = x + " of " + pages;
                    pager.Items.Add(cb);
                }
                if (pages > 0)
                {
                    pager.SelectedIndex = 0;
                }
            }
        }

        internal void SetPageSize(double width, double height)
        {
            PageWidth = width;
            PageHeight = height;
            PdfBorder.Width = PageWidth + (PageWidth > 0 ? 2 : 0);
            PdfBorder.Height = PageHeight + (PageHeight > 0 ? 2 : 0);
            PdfCanvas.Width = PageWidth;
            PdfCanvas.Height = PageHeight;

            AdjustPageDimension();
        }

        internal void RenderCurrentPage()
        {
            if (Dc == null)
            {
                return;
            }
            if (pager == null)
            {
                return;
            }
            var pleaseWait = new PleaseWait();
            pleaseWait.Owner = this;
            pleaseWait.ShowDialog();
        }

        internal void RunRenderCurrentPage()
        {
            int currentPage = pager.SelectedIndex;
            if (currentPage > -1 && _SIReader != null)
            {
                //PdfCanvas.CanvasToImage();
                ResetPdfCanvas();
                try
                {
                    _SIReader.RenderPage(CurrentPage, PdfCanvas, this, imageDeskew.SelectedValue as string, 0);
                }
                catch (Exception e)
                {
                    MessageBox.Show("Failed to open the file " + FilePath.Text + ". Please report to support and send them a copy of the file you are trying to open.");
                    e.LogException();
                    Prepare4New(true);
                }
            }
        }

        private DataCaptureElement SelectedElement
        {
            get
            {
                DataCaptureElement selectedElement = null;
                foreach (DataCaptureElement element in DCELMENTS)
                {
                    if (element.Widget != null && element.Widget.IsChecked == true)
                    {
                        selectedElement = element;
                        break;
                    }
                }
                return selectedElement;
            }
        }
        
        private FrameworkElement SelectionBox
        {
            get
            {
                int currentPage = CurrentPage;
                if (currentPage != -1)
                {
                    DataCaptureElement selectedElement = SelectedElement;
                    if (selectedElement != null)
                    {
                        return selectedElement.GetRectangle(currentPage);
                    }
                }
                return null;
            }
        }

        public int CurrentPage
        {
            get
            {
                int pageNo = pager.SelectedIndex;
                if (pageNo > -1)
                {
                    return pageNo + 1;
                }
                return -1;
            }
        }

        internal void ClearCanvas(bool skipRectangles)
        {
            ImageExists = false;
            TextExists = false;            
            _DrawingPaths.Clear();
            _TextCollection.Clear();
            if (TextBitmap != null)
            {
                TextBitmap.Dispose();
            }
            TextBitmap = null;
            if (Bitmap != null)
            {
                Bitmap.Dispose();
            }
            Bitmap = null;
            GC.Collect();
            PdfCanvas.Children.Clear();

            if (_ActionRects == null)
            {
                _ActionRects = new List<Rectangle>();
            }
            else
            {
                _ActionRects.Clear();
            }

            if (ImageBox == null)
            {
                ImageBox = new Image();
            }
            ImageScaleWidth = 0;
            ImageScaleHeight = 0;
            ImageBox.Stretch = Stretch.None;
            ImageBox.Width = 0;
            ImageBox.Height = 0;
            ImageBox.Margin = new Thickness(0);
            Canvas.SetLeft(ImageBox, 0);
            Canvas.SetTop(ImageBox, 0);
            PdfCanvas.Children.Add(ImageBox);
            PdfCanvas.Children.Add(MouseEllipse);
            if (!skipRectangles)
            {
                foreach (DataCaptureElement element in DCELMENTS)
                {
                    if (element != null)
                    {
                        element.ClearRectangles();
                    }
                }
            }
        }

        internal void ResetPdfCanvas()
        {
            int currentPage = CurrentPage;
            if (currentPage != -1)
            {
                ClearCanvas(true);
                foreach (DataCaptureElement element in DCELMENTS)
                {
                    var rectangle = element.GetRectangle(currentPage);
                    if (rectangle == null)
                    {
                        rectangle = CreateRectangleForBLElement(element);
                        element.SetRectangle(currentPage, rectangle);
                    }
                    if (rectangle != null)
                    {
                        PdfCanvas.Children.Add(rectangle);
                        AdornerLayer.GetAdornerLayer(rectangle).Add(new BoxAdorner(rectangle));
                    }
                }
            }
        }

        internal FrameworkElement CreateRectangleForBLElement(DataCaptureElement element)
        {
            bool useFill = true;
            FrameworkElement rectangleElement = null;
            if (element.DCElementType == DataCaptureElementType.PackageGrid)
            {
                Grid packageGrid = new Grid();
                packageGrid.MainWindow = this;
                packageGrid.BorderBrush = element.GetBorderBrush();
                packageGrid.Background = element.GetFillBrush(false);
                rectangleElement = packageGrid;                
            }
            else
            {
                Rectangle rectangle = new Rectangle();
                rectangle.StrokeThickness = 1;
                rectangle.Stroke = element.GetBorderBrush();
                rectangle.Fill = element.GetFillBrush(useFill);
                rectangleElement = rectangle;
            }
            rectangleElement.Tag = element;
            rectangleElement.Width = 0;
            rectangleElement.Height = 0;

            Canvas.SetZIndex(rectangleElement, 10000);
            rectangleElement.MouseDown += rect_MouseDown;
            rectangleElement.MouseMove += rect_MouseMove;
            rectangleElement.MouseUp += rect_MouseUp;
            if (!string.IsNullOrWhiteSpace(element.MenuName))
            {
                rectangleElement.ContextMenu = (ContextMenu)FindResource(element.MenuName);
                rectangleElement.ContextMenuOpening += rectangle_ContextMenuOpening;
            }
            SetRectangleVisibility(rectangleElement, Visibility.Collapsed);
            return rectangleElement;

        }

        void rectangle_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            var rectangle = sender as FrameworkElement;
            if (rectangle != null && rectangle.ContextMenu != null && rectangle.ContextMenu.Items != null)
            {
                string message = null;
                string text;
                DataCaptureElement element = rectangle.Tag as DataCaptureElement;
                if (element != null)
                {
                    bool isGeneral = (element.DCElementType == DataCaptureElementType.General);
                    bool isPackageGrid = (element.DCElementType == DataCaptureElementType.PackageGrid);
                    foreach (var item in rectangle.ContextMenu.Items)
                    {
                        var frameWorkElement = item as FrameworkElement;
                        var menuItem = item as MenuItem;
                        if (frameWorkElement != null)
                        {
                            switch (frameWorkElement.Name)
                            {
                                case "CMSepPG1":
                                case "CMSepPG2":
                                case "CMSepPG3":
                                case "CMSepPG4":
                                case "CMSepPG5":
                                    if (element.DCElementType == DataCaptureElementType.PackageGrid)
                                    {
                                        frameWorkElement.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        frameWorkElement.Visibility = Visibility.Collapsed;
                                    }
                                    break;

                                case "CMContent":
                                    if (element.DCElementType == DataCaptureElementType.PackageGrid)
                                    {
                                        frameWorkElement.Visibility = Visibility.Collapsed;
                                    }
                                    else
                                    {
                                        frameWorkElement.Visibility = Visibility.Visible;
                                    }
                                    break;

                                case "CMApply":
                                case "CMAppend":
                                case "CMInsert":
                                    if (isGeneral)
                                    {
                                        frameWorkElement.Visibility = Visibility.Collapsed;
                                    }
                                    else
                                    {
                                        if (!isPackageGrid || "CMApply".Equals(frameWorkElement.Name))
                                        {
                                            frameWorkElement.Visibility = Visibility.Visible;
                                            if ("CMApply".Equals(frameWorkElement.Name) && menuItem != null)
                                            {
                                                if (isPackageGrid)
                                                {
                                                    menuItem.Header = "Process";
                                                }
                                                else
                                                {
                                                    menuItem.Header = "Apply";
                                                }
                                            }
                                        }
                                        else
                                        {
                                            frameWorkElement.Visibility = Visibility.Collapsed;
                                        }
                                    }
                                    break;

                                case "CMApplyGeneral":
                                case "CMAppendGeneral":
                                case "CMInsertGeneral":
                                case "CMImageSeparator":
                                //case "CMImageGeneralDeskew":
                                //case "CMImageGeneralRotate":
                                //case "CMImageGeneralErase":
                                //    if (isGeneral)
                                //    {
                                //        frameWorkElement.Visibility = Visibility.Visible;
                                //    }
                                //    else
                                //    {
                                //        frameWorkElement.Visibility = Visibility.Collapsed;
                                //    }
                                //    break;

                                case "CMRowPackage":
                                case "CMRowPkgPackage":
                                case "CMRowMksPackage":
                                case "CMRowGdsPackage":
                                case "CMRowEndsPackage":
                                case "CMColumnPackage":
                                case "CMColumnContentPackage":
                                case "CMColumnAllContents":
                                case "CMClearColumnsPackage":
                                case "CMClearColumnContentsPackage":
                                case "CMClearRowsPackage":
                                case "CMClearSplitsPackage":
                                case "CMCopyContentPackage":
                                    if (isPackageGrid)
                                    {
                                        frameWorkElement.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        frameWorkElement.Visibility = Visibility.Collapsed;
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
        }

        //XmlDocument xmlDocument;

        //public XmlDocument DataTree
        //{
        //    get
        //    {
        //        return xmlDocument;
        //    }
        //}

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }

        internal int ZoomValue()
        {
            int value = 100;
            if (zoomer != null)
            {
                string pct = "100";
                if (zoomer.SelectedValue != null)
                {
                    pct = zoomer.SelectedValue.ToString();
                }
                Int32.TryParse(pct, out value);
            }
            return value;
        }

        internal void AdjustPageDimension()
        {
            if (zoomer == null)
            {
                return;
            }
            int value = ZoomValue();
            double zoom = (double)value / 100;
            var width = PageWidth * zoom;
            var height = PageHeight * zoom;
            if (PdfBorder != null)
            {
                PdfBorder.Width = width + (width > 0 ? 2 : 0);
                PdfBorder.Height = height + (height > 0 ? 2 : 0);
            }
            if (PdfCanvas != null)
            {
                PdfCanvas.Width = width;
                PdfCanvas.Height = height;
            }
        }

        private Point SelectionBoxXY
        {
            get
            {
                double left = double.NaN;
                double top = double.NaN;
                var selectionBox = SelectionBox;
                if (selectionBox != null)
                {
                    left = Canvas.GetLeft(selectionBox);
                    top = Canvas.GetTop(selectionBox);
                }
                return new Point(left, top);
            }
        }

        bool AllowDrawing = false;

        private void PdfCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            RegisterUnderRedoRectangle();
            AllowDrawing = false;
            HighlightAdorner(SelectionBox, false);
        }

        private void PdfCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle2Move = null;
            var selectionBox = SelectionBox;
            if (selectionBox != null)
            {
                HighlightAdorner(selectionBox, true);
                Canvas canvas = sender as Canvas;
                if (canvas != null)
                {
                    if (e.LeftButton == MouseButtonState.Pressed)
                    {
                        AllowDrawing = (selectionBox.Width == 0 && selectionBox.Height == 0);
                        var blElement = selectionBox.Tag as DataCaptureElement;

                        if (blElement != null)
                        {
                            InitUndoRedoRectangle(blElement);
                            if (!AllowDrawing)
                            {
                                AllowDrawing = (blElement.DCElementType == DataCaptureElementType.General);
                            }
                        }
                        if (AllowDrawing)
                        {
                            SetRectangleVisibility(selectionBox, Visibility.Visible);
                            Point xy = e.GetPosition(canvas);
                            selectionBox.Width = 0;
                            selectionBox.Height = 0;
                            MoveSelectionBox(xy);
                            selectionBox.SetPositionInToolTip();
                        }
                    }
                }
            }
        }

        private void PdfCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            Canvas canvas = sender as Canvas;
            if (canvas != null)
            {
                //UpdateMagnifier();
                var point = e.GetPosition(canvas);
                XCo.Text = "" + string.Format("{0:f3}", point.X);
                YCo.Text = "" + string.Format("{0:f3}", point.Y);
                if (Rectangle2Move != null)
                {
                    rect_MouseMove(Rectangle2Move, e);
                    return;
                }
                if (!AllowDrawing)
                {
                    return;
                }
                if (SelectionBox != null)
                {
                    var xy = SelectionBoxXY;
                    if (e.LeftButton == MouseButtonState.Pressed)
                    {
                        var width = point.X - xy.X;
                        var height = point.Y - xy.Y;
                        var move = false;

                        // right to left
                        if (width < 0)
                        {
                            xy.X = point.X + 2;
                            width = Math.Abs(width) + SelectionBox.ActualWidth;
                            if (width > 0)
                            {
                                width--;
                            }
                            move = true;
                        }

                        // bottom to top
                        if (height < 0)
                        {
                            xy.Y = point.Y + 2;
                            height = Math.Abs(height) + SelectionBox.ActualHeight;
                            if (height > 0)
                            {
                                height--;
                            }
                            move = true;
                        }
                        if (move)
                        {
                            MoveSelectionBox(xy);
                        }
                        if (width > 1)
                        {
                            width = width - 1;
                        }
                        if (height > 1)
                        {
                            height = height - 1;
                        }
                        SelectionBox.Width = Math.Abs(width);
                        SelectionBox.Height = Math.Abs(height);
                        SelectionBox.SetPositionInToolTip();
                        if (_UndoRedoRectangle != null)
                        {
                            _UndoRedoRectangle.UpdateNewValues();
                            UndoRedoManager.Current.AddUndoAction(_UndoRedoRectangle);
                        }
                    }
                }
            }
        }

        void rect_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                return;
            }
            RegisterUnderRedoRectangle();
            SelectRectangle(null);
            //e.Handled = true;
        }

        void rect_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (
                Keyboard.IsKeyDown(Key.LeftAlt) ||
                Keyboard.IsKeyDown(Key.RightAlt) ||
                Keyboard.IsKeyDown(Key.LeftCtrl) ||
                Keyboard.IsKeyDown(Key.RightCtrl) ||
                Keyboard.IsKeyDown(Key.LeftShift) ||
                Keyboard.IsKeyDown(Key.RightShift)
                )
            {
                return;
            }
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                FrameworkElement rect = sender as FrameworkElement;
                if (rect != null)
                {
                    var blElement = rect.Tag as DataCaptureElement;
                    if (e.ClickCount == 2)
                    {
                        if (blElement != null)
                        {
                            ApplyText(blElement.DCElementType, rect, false, false, true);
                        }
                        return;
                    }
                    Point xy = new Point();
                    Canvas canvas = rect.Parent as Canvas;
                    if (canvas != null)
                    {
                        xy = e.GetPosition(canvas);
                    }

                    InitUndoRedoRectangle(blElement);

                    SelectRectangle(rect, true, true, xy);
                    e.Handled = true;
                }
            }
        }

        void rect_MouseMove(object sender, MouseEventArgs e)
        {
            //UpdateMagnifier();
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                FrameworkElement rect = sender as FrameworkElement;
                if (rect == Rectangle2Move)
                {
                    Canvas canvas = rect.Parent as Canvas;
                    if (canvas != null)
                    {
                        Point xy = e.GetPosition(canvas);
                        double left = Canvas.GetLeft(rect);
                        double top = Canvas.GetTop(rect);
                        left += (xy.X - RectangleXY2Move.X);
                        top += (xy.Y - RectangleXY2Move.Y);
                        if (left >= 0)
                        {
                            Canvas.SetLeft(rect, left);
                        }
                        if (top >= 0)
                        {
                            Canvas.SetTop(rect, top);
                        }
                        RectangleXY2Move.X = xy.X;
                        RectangleXY2Move.Y = xy.Y;
                        rect.SetPositionInToolTip();
                    }
                }
            }
            e.Handled = true;
        }


        private void ClearRectangle(FrameworkElement rectangle)
        {
            rectangle.Width = 0;
            rectangle.Height = 0;
            SetRectangleVisibility(rectangle, Visibility.Collapsed);
        }

        private void SetRectangleVisibility(FrameworkElement rectangle, Visibility visibility)
        {
            rectangle.Visibility = visibility;
            var layer = AdornerLayer.GetAdornerLayer(rectangle);
            if (layer != null)
            {
                var adorners = layer.GetAdorners(rectangle);
                if (adorners != null)
                {
                    foreach (Adorner adorner in adorners)
                    {
                        adorner.Visibility = visibility;
                    }
                }
            }
            if (visibility != Visibility.Collapsed)
            {
                rectangle.SetPositionInToolTip();
            }
        }

        private void MoveSelectionBox(Point xy)
        {
            Canvas.SetLeft(SelectionBox, xy.X);
            Canvas.SetTop(SelectionBox, xy.Y);
        }

        internal void SetImage(System.Drawing.Bitmap image, double scaleWidth, double scaleHeight)
        {
            if (scaleWidth > -1)
            {
                ImageScaleWidth = scaleWidth;
            }
            if (scaleHeight > -1)
            {
                ImageScaleHeight = scaleHeight;
            }

            if (_ImageActions != null)
            {
                var pageActions = _ImageActions.Where(p => p.Page == CurrentPage).ToArray();
                if (pageActions != null && pageActions.Length > 0)
                {
                    var bmp = ImageUtils.ApplyImageAction(image, pageActions.Where(p => p.IsCustom == false).ToArray());
                    if (bmp != image && bmp != null)
                    {
                        image.Dispose();
                        GC.Collect();
                        image = bmp;
                    }
                    bmp = ImageUtils.ApplyImageAction(image, pageActions.Where(p => p.IsCustom).ToArray());
                    if (bmp != image && bmp != null)
                    {
                        image.Dispose();
                        GC.Collect();
                        image = bmp;
                    }
                    ApplyActionRectangle(image, pageActions);
                }
            }
            FinalizeImage(image);
        }

        private System.Drawing.Bitmap BuildTextBitmap(System.Drawing.Bitmap backgroundImage)
        {
            if (_TextCollection != null && _TextCollection.Count() > 0)
            {
                try
                {
                    string colorName = "";                    
                    var textImage = ImageUtils.BuildTextImage(PageWidth, PageHeight, colorName, DrawingPaths, _TextCollection, backgroundImage);
                    var filepath = System.IO.Path.Combine(WorkingPath, "TextImage.png");
                    textImage.Save(filepath);
                    TextBitmap = textImage;
                    return textImage;
                }
                catch (Exception ex)
                {
                    ex.LogException();
                }
            }
            return backgroundImage;
        }

        public void RenderTextImage()
        {
            FinalizeImage(null);
        }

        private void FinalizeImage(System.Drawing.Bitmap image)
        {
            if (Bitmap != null && Bitmap != image)
            {
                Bitmap.Dispose();
                GC.Collect();
            }

            if (Bitmap != image)
            {
                Bitmap = image;
            }
            var tmpImage = Bitmap;
            bool dispose = false;
            if (tmpImage != null)
            {
                if (ImageScaleWidth > 0 && ImageScaleHeight > 0)
                {
                    dispose = true;
                    tmpImage = ImageUtils.ResizeImage(tmpImage, ImageScaleWidth, ImageScaleHeight, true);
                }
            }

            tmpImage = BuildTextBitmap(tmpImage);

            if (tmpImage != null)
            {
                var imageWPF = tmpImage.ToWPFImageSource();
                if (dispose)
                {
                    tmpImage.Dispose();
                    GC.Collect();
                }
                AddWPFImageToCanvas(imageWPF);
            }
        }

        internal void AddWPFImageToCanvas(ImageSource image)
        {
            if (image != null)
            {
                double width = image.Width;
                double height = image.Height;

                if (PageWidth < width || PageHeight < height)
                {
                    SetPageSize(Math.Max(width, PageWidth), Math.Max(height, PageHeight));
                }

                Image imageBox = ImageBox;
                if (imageBox.Source != image)
                {
                    var bmpImage = imageBox.Source as BitmapImage;
                    if (bmpImage != null && bmpImage.StreamSource != null)
                    {
                        bmpImage.StreamSource.Close();
                    }
                }
                imageBox.Source = image;
                imageBox.Width = width;
                imageBox.Height = height;
                imageBox.Stretch = Stretch.Fill;

                StringBuilder sbTip = new StringBuilder();
                sbTip.AppendLine("This is an image");
                sbTip.AppendLine("------------------");
                sbTip = sbTip.AppendLine("Left\t" + Math.Round(0d, 3));
                sbTip = sbTip.AppendLine("Top\t" + Math.Round(0d, 3));
                sbTip = sbTip.AppendLine("Width\t" + Math.Round(width, 3));
                sbTip = sbTip.AppendLine("Height\t" + Math.Round(height, 3));
                sbTip = sbTip.AppendLine("Right\t" + Math.Round(width, 3));
                sbTip = sbTip.AppendLine("Bottom\t" + Math.Round(height, 3));

                imageBox.ToolTip = sbTip.ToString();
                imageBox.SetBinding(ToolTipService.IsEnabledProperty, new Binding("EnableToolTip") { Source = this });
                Canvas.SetLeft(imageBox, 0);
                Canvas.SetTop(imageBox, 0);
                //Canvas.SetZIndex(imageBox, 100);
            }
        }

        internal string WorkingPath
        {
            get;
            set;
        }

        private void RectangleMenu_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menu = sender as MenuItem;
            if (menu != null)
            {
                var ctx = menu.GetContextMenu();
                if (ctx != null)
                {
                    string message = null;
                    var rectangle = ctx.PlacementTarget as FrameworkElement;
                    if (rectangle != null)
                    {
                        UpdateCurrentField();
                        var ocred = false;
                        double accuracy = 0;
                        var imageFile = "OCR.tif";
                        var textFile = "OCR.txt";
                        string text;
                        List<ImageSource> images = new List<ImageSource>();
                        Point mousePoint = Mouse.GetPosition(rectangle);
                        Grid packageGrid = null;
                        DataCaptureElementType elementType = DataCaptureElementType.General;
                        DataCaptureElement element = rectangle.Tag as DataCaptureElement;
                        if (element != null)
                        {
                            elementType = element.DCElementType;
                        }
                        if (menu.Tag is DataCaptureElementType)
                        {
                            elementType = (DataCaptureElementType)menu.Tag;
                        }
                        if (elementType == DataCaptureElementType.PackageGrid)
                        {
                            packageGrid = rectangle as Grid;
                        }
                        switch (menu.Name)
                        {
                            case "CMSupplyCordinates":
                                //CoOrdinageAdjustments(rectangle);
                                break;

                            case "CMKeyboard":
                                PrepareAndShowAdjustments(rectangle);
                                break;

                            case "CMColumnContentPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.AddColumnContent(-1, true);
                                }
                                break;

                            case "CMColumnAllContents":
                                if (packageGrid != null)
                                {
                                    packageGrid.ShowAllColumnContentsEditor();
                                }
                                break;


                            case "CMColumnPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.AddColumn();
                                }
                                break;

                            case "CMRowPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.AddRow();
                                }
                                break;

                            case "CMRowPkgPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.AddRowPackageCount();
                                }
                                break;                            

                            case "CMRowEndsPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.AddRowEnds();
                                }
                                break;

                            case "CMCopyContentPackage":
                                CopyPackageGrid(packageGrid);
                                break;

                            case "CMClearColumnsPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.ClearSplits(true, false);
                                }
                                break;

                            case "CMClearColumnContentsPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.ClearColumnContents();
                                }
                                break;

                            case "CMClearRowsPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.ClearSplits(false, true);
                                }
                                break;

                            case "CMClearSplitsPackage":
                                if (packageGrid != null)
                                {
                                    packageGrid.ClearSplits(true, true);
                                }
                                break;

                            case "CMClear":
                                UndoRedoManager.Current.AddUndoAction(new UndoRedoRectangle(element, this, CurrentPage));

                                rectangle.Width = 0;
                                rectangle.Height = 0;
                                SetRectangleVisibility(rectangle, Visibility.Collapsed);
                                break;

                            case "CMSelect":
                                SelectRectangle(rectangle, true, true);
                                break;

                            case "CMCopy":
                                text = TextOrOCRWithinZone(out ocred, out accuracy, rectangle.GetRect().ToHighlightRegion(), rectangle.Parent as Canvas, imageFile, textFile, element.DCElementType, images);
                                if (!string.IsNullOrEmpty(text))
                                {
                                    Clipboard.SetData(DataFormats.Text, text);
                                }
                                break;

                            case "CMContent":
                                text = TextOrOCRWithinZone(out ocred, out accuracy, rectangle.GetRect().ToHighlightRegion(), rectangle.Parent as Canvas, imageFile, textFile, element.DCElementType, images);
                                string[] textLinks = null;
                                if (text != null)
                                {
                                    var tabIndex = text.IndexOf("\t");
                                    if (tabIndex != -1)
                                    {
                                        var tabPost = text.Substring(tabIndex + 1);
                                        //text = text.Substring(0, tabIndex);
                                        textLinks = tabPost.Split(new string[] { "\t", Environment.NewLine, "\n", " " }, StringSplitOptions.RemoveEmptyEntries).Distinct().OrderBy(p => p).ToArray();
                                    }
                                }
                                ContentEditor editor = new ContentEditor();
                                editor.SetupBLElements(DCELMENTS, element.DCElementType);
                                editor.OCRed = ocred;
                                editor.BLInfo = Dc;
                                editor.Owner = RightPanelWindow;
                                editor.Text = text;
                                editor.Accuracy = accuracy;
                                if (images != null && images.Count() > 0 && images[0] != null)
                                {
                                    editor.OCRImage = images[0];
                                }
                                editor.ShowDialog();
                                break;

                            case "CMApply":
                                if (element != null)
                                {
                                    if (elementType == DataCaptureElementType.PackageGrid)
                                    {
                                        ApplyPackageGrid(rectangle as Grid);
                                    }
                                    else
                                    {
                                        ApplyText(elementType, rectangle, false, false, true);
                                    }
                                }
                                break;

                            case "CMAppend":
                                if (element != null)
                                {
                                    if (elementType == DataCaptureElementType.TextAreaElement1)
                                        ApplyText(elementType, rectangle, false, false, true);
                                    else
                                        ApplyText(elementType, rectangle, true, false, true);
                                }
                                break;

                            case "CMInsert":
                                if (element != null)
                                {
                                    if (elementType == DataCaptureElementType.TextAreaElement1)
                                        ApplyText(elementType, rectangle, false, false, true);
                                    else
                                        ApplyText(elementType, rectangle, false, true, true);
                                }
                                break;

                            //case "CMImageGeneralDeskew":
                            //    if (element != null)
                            //    {
                            //        ApplyImageAction(rectangle.GetRect().ToHighlightRegion(), ImageOperation.Deskew);
                            //    }
                            //    break;

                            //case "CMImageGeneralRotate":
                            //    if (element != null)
                            //    {
                            //        ApplyImageAction(rectangle.GetRect().ToHighlightRegion(), ImageOperation.Rotate);
                            //    }
                            //    break;

                            //case "CMImageGeneralErase":
                            //    if (element != null)
                            //    {
                            //        ApplyImageAction(rectangle.GetRect().ToHighlightRegion(), ImageOperation.Erase);
                            //    }
                            //    break;
                        }
                    }
                }
            }
        }

        private void CopyPackageGrid(Grid packageGrid)
        {
            if (packageGrid != null)
            {
                var currentPage = CurrentPage - 1;
                if (currentPage != -1)
                {
                    var pkgElement = DCELMENTS.Where(p => p.DCElementType == DataCaptureElementType.PackageGrid).FirstOrDefault();
                    if (pkgElement != null)
                    {
                        while (currentPage >= 0)
                        {
                            var pageGrid = pkgElement.GetRectangle(currentPage) as Grid;
                            if (pageGrid != null)
                            {
                                packageGrid.CopyFrom(pageGrid);
                                break;
                            }
                            currentPage--;
                        }
                    }
                }
            }
        }

        private void zoomer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AdjustPageDimension();
        }

        private void pager_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RenderCurrentPage();
        }

        private void BCapture_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            int currentPage = CurrentPage;
            foreach (DataCaptureElement element in DCELMENTS)
            {                               
                var rectangle = element.GetRectangle(currentPage);
                if (rectangle != null && rectangle.Visibility == Visibility.Visible && rectangle.ActualWidth > 0 && rectangle.ActualHeight > 0)
                {
                    var msg = ApplyText(element.DCElementType, rectangle, false, false, false);
                    if (!string.IsNullOrWhiteSpace(msg))
                    {
                        if (sb.Length > 0)
                        {
                            sb.AppendLine();
                            sb.AppendLine();
                        }
                        sb.AppendLine(element.DCElementType.ToString());
                        sb.Append(msg);
                    }
                }                
            }
            if (sb.Length > 0)
            {
                MessageBox.Show(sb.ToString(), "Capture Issues/Warnings");
            }
        }

        public string TextWithinZone(HighlightRegion highlightRegion, Canvas canvas, bool allowPartial, List<TextBlock> elements = null)
        {
            if (highlightRegion != null)//&& canvas != null
            {
                return TextRectsWithinZone(highlightRegion.Left, highlightRegion.Top, highlightRegion.Width, highlightRegion.Height, highlightRegion.InsetWidth, highlightRegion.InsetHeight, allowPartial);
                //return TextWithinZone(canvas, highlightRegion.Left, highlightRegion.Top, highlightRegion.Width, highlightRegion.Height, highlightRegion.InsetWidth, highlightRegion.InsetHeight, allowPartial, elements);
            }
            return null;
        }

        private string TextRectsWithinZone(double left, double top, double width, double height, double insetWidth, double insetHeight, bool allowPartial)
        {
            var textRects = TextCollection.TextRectsWithinZone(left, top, width, height, insetWidth, insetHeight, allowPartial);
            if (textRects != null && textRects.Count() > 0)
            {
                PDFTextRect lastTR = null;
                StringBuilder sb = new StringBuilder();
                Size stringSize;
                string currentText = "";
                string lastLine = "";
                double x = double.NaN;
                double y = double.NaN;
                double lastHeight = 0;
                double lastX = 0;
                double diffY;
                double diffX;

                foreach (XYCo point in textRects.Keys)
                {
                    try
                    {
                        if (!double.IsNaN(y)) // Check change in Y. Add as many empty lines as needed
                        {
                            diffY = point.Y - y;
                            if (diffY > 0)
                            {
                                if (string.IsNullOrWhiteSpace(currentText) || !currentText.EndsWith(Environment.NewLine))
                                {
                                    int lineCount = 1;
                                    if (lastHeight > 0)
                                    {
                                        lineCount = (int)Math.Floor((double)diffY / lastHeight);
                                        //if (lineCount == 0 && (point.X < lastX || point.X > x)) code may not be needed
                                        if (lineCount == 0)
                                        {
                                            if (" ".Equals(lastLine))
                                            {
                                                //sb.Length -= 1;
                                            }
                                            else
                                            {
                                                if (diffY > 5)
                                                {
                                                    lineCount = (int)Math.Ceiling((double)diffY / lastHeight);
                                                }
                                            }
                                        }
                                    }
                                    if (currentText != null && currentText.EndsWith(Environment.NewLine))
                                    {
                                        lineCount--;
                                    }

                                    if (lineCount > 0)
                                    {
                                        for (int i = 0; i < lineCount; i++)
                                        {
                                            sb.AppendLine();
                                        }
                                        lastLine = "";
                                    }
                                }
                            }
                        }

                        var pdfTR = textRects[point];
                        if (lastTR != null && !double.IsNaN(x)) // Check change in X. Add as many spaces as needed
                        {
                            var lastPdfTR = lastTR;
                            if (lastPdfTR == null || pdfTR == null || !pdfTR.MatchText(lastPdfTR))
                            {
                                diffX = point.X - x;
                                // Removing space calculation logic. this is only needed for BL Text and we removed BL Text currently

                                if (diffX > 0)
                                {
                                    stringSize = " ".StringSize(lastTR.FontFamily, lastTR.IsBold, lastTR.FontSize);
                                    if (stringSize.Width > 0 && diffX > stringSize.Width)
                                    {
                                        int spaceCount = (int)Math.Floor((double)diffX / stringSize.Width);
                                        for (int i = 0; i < spaceCount; i++)
                                        {
                                            sb.Append(" ");
                                        }
                                    }
                                }

                            }
                            else
                            {
                                if (lastPdfTR != null && lastPdfTR.IsRepeat(pdfTR))
                                {
                                    lastPdfTR = pdfTR;
                                    continue;
                                }
                                else
                                {
                                    lastPdfTR = pdfTR;
                                }
                            }
                        }
                        y = point.Y;
                        currentText = textRects[point].Text;
                        lastLine = lastLine + currentText;
                        lastTR = textRects[point];
                        lastHeight = lastTR.Height;
                        lastHeight = (float)lastTR.Height;
                        lastX = point.X;
                        if (pdfTR != null && pdfTR.Width > 0)
                        {
                            x = point.X + pdfTR.Width;
                        }
                        else
                        {
                            x = point.X + lastTR.Width;
                        }
                        sb.Append(currentText);
                    }
                    catch (Exception e)
                    {
                        //MessageBox.Show("Warning!!! System encountered an error while Reading the content. Please check the captured text.");                        
                        sb.Append("¶");
                    }
                }

                string text = sb.ToString();
                return text;
            }
            return null;
        }

        private string TextWithinZone(Canvas canvas, double left, double top, double width, double height, double insetWidth, double insetHeight, bool allowPartial, List<TextBlock> elements = null)
        {
            SortedDictionary<XYCo, TextBlock> tbs = new SortedDictionary<XYCo, TextBlock>();
            if (canvas != null)
            {
                tbs = canvas.ElementsWithinZone<TextBlock>(left, top, width, height, insetWidth, insetHeight, allowPartial, elements);
            }
            if (tbs != null && tbs.Count() > 0)
            {
                TextBlock lastTBL = null;
                StringBuilder sb = new StringBuilder();
                Size stringSize;
                string currentText = "";
                string lastLine = "";
                double x = double.NaN;
                double y = double.NaN;
                double lastHeight = 0;
                double lastX = 0;
                double diffY;
                double diffX;
                foreach (XYCo point in tbs.Keys)
                {
                    if (!double.IsNaN(y)) // Check change in Y. Add as many empty lines as needed
                    {
                        //diffY = Math.Abs(point.Y - y);
                        diffY = point.Y - y;
                        if (diffY > 0)
                        {
                            if (string.IsNullOrWhiteSpace(currentText) || !currentText.EndsWith(Environment.NewLine))
                            {
                                int lineCount = 1;
                                if (lastHeight > 0)
                                {
                                    lineCount = (int)Math.Floor((double)diffY / lastHeight);
                                    //if (lineCount == 0 && (point.X < lastX || point.X > x)) code may not be needed
                                    if (lineCount == 0)
                                    {
                                        if (" ".Equals(lastLine))
                                        {
                                            //sb.Length -= 1;
                                        }
                                        else
                                        {
                                            if (diffY > 5)
                                            {
                                                lineCount = (int)Math.Ceiling((double)diffY / lastHeight);
                                            }
                                        }
                                    }
                                }
                                if (currentText != null && currentText.EndsWith(Environment.NewLine))
                                {
                                    lineCount--;
                                }

                                if (lineCount > 0)
                                {
                                    for (int i = 0; i < lineCount; i++)
                                    {
                                        sb.AppendLine();
                                    }
                                    lastLine = "";
                                }
                            }
                        }
                    }
                    var pdfTR = tbs[point].Tag as PDFTextRect;
                    if (lastTBL != null && !double.IsNaN(x)) // Check change in X. Add as many spaces as needed
                    {
                        var lastPdfTR = lastTBL.Tag as PDFTextRect;

                        if (lastPdfTR == null | pdfTR == null || !pdfTR.MatchText(lastPdfTR))
                        {
                            diffX = point.X - x;
                            // Removing space calculation logic. this is only needed for BL Text and we removed BL Text currently

                            if (diffX > 0)
                            {
                                stringSize = lastTBL.SpaceSize();
                                if (stringSize.Width > 0 && diffX > stringSize.Width)
                                {
                                    int spaceCount = (int)Math.Floor((double)diffX / stringSize.Width);
                                    for (int i = 0; i < spaceCount; i++)
                                    {
                                        sb.Append(" ");
                                    }
                                }
                            }

                        }
                        else
                        {
                            lastPdfTR = pdfTR;
                        }
                    }
                    y = point.Y;
                    currentText = tbs[point].Text;
                    lastLine = lastLine + currentText;
                    lastTBL = tbs[point];
                    lastHeight = lastTBL.ActualHeight;
                    if (lastTBL.Tag is float)
                    {
                        lastHeight = (float)lastTBL.Tag;
                    }
                    lastX = point.X;
                    if (pdfTR != null && pdfTR.Width > 0)
                    {
                        x = point.X + pdfTR.Width;
                    }
                    else
                    {
                        x = point.X + lastTBL.ActualWidth;
                    }
                    sb.Append(currentText);
                }
                string text = sb.ToString();
                return text;
            }
            return null;
        }

        private HighlightRegion AdjustRectForImageScaling(HighlightRegion highlightRegion)
        {
            if (ImageBox != null && ImageBox.Source != null)
            {
                var imagewidth = ImageBox.Source.Width;
                var imageheight = ImageBox.Source.Height;
                if (Bitmap != null)
                {
                    imagewidth = Bitmap.Width;
                    imageheight = Bitmap.Height;
                }
                double xFactor = 1;
                if (ImageBox.Width > 0 && imagewidth > 0)
                {
                    xFactor = imagewidth / ImageBox.Width;
                }
                double yFactor = 1;
                if (ImageBox.Height > 0 && imageheight > 0)
                {
                    yFactor = imageheight / ImageBox.Height;
                }
                if (xFactor != 1 || yFactor != 1)
                {
                    double left = highlightRegion.Left * xFactor;
                    double top = highlightRegion.Top * yFactor;
                    double width = highlightRegion.Width * xFactor;
                    double height = highlightRegion.Height * yFactor;
                    double insetWidth = highlightRegion.InsetWidth * xFactor;
                    double insetHeight = highlightRegion.InsetHeight * yFactor;
                    highlightRegion = new HighlightRegion(left, top, width, height, insetWidth, insetHeight);
                }
            }
            return highlightRegion;
        }

        public string OCRWithinZone(out double accuracy, HighlightRegion highlightRegion, string imageFile, string textFile, List<ImageSource> images = null)
        {
            accuracy = 0;
            string text = "";
            if (ImageBox != null && ImageBox.Source != null && Bitmap != null)
            {
                string characterList = "";                

                double left = highlightRegion.Left;
                double top = highlightRegion.Top;
                double width = highlightRegion.Width;
                double height = highlightRegion.Height;
                double insetWidth = highlightRegion.InsetWidth;
                double insetHeight = highlightRegion.InsetHeight;

                double x = Canvas.GetLeft(ImageBox);
                double y = Canvas.GetTop(ImageBox);

                if (x > 0 && x != left)
                {
                    if (x > left)
                    {
                        left = 0;
                        if (insetWidth > 0)
                        {
                            insetWidth = insetWidth - (x - left);
                        }
                        width = width - (x - left);
                    }
                    else
                    {
                        left = left - x;
                    }
                }

                if (y > 0 && y != top)
                {
                    if (y > top)
                    {
                        top = 0;
                        if (insetHeight > 0)
                        {
                            insetHeight = insetHeight - (y - height);
                        }
                        height = height - (y - top);
                    }
                    else
                    {
                        top = top - y;
                    }
                }

                highlightRegion = new HighlightRegion(left, top, width, height, insetWidth, insetHeight);
                highlightRegion = AdjustRectForImageScaling(highlightRegion);
                ImageRegion iRegion = null;
                var imageRegion = new HighlightRegion(0, 0, ImageBox.Source.Width, ImageBox.Source.Height);
                if (Bitmap != null)
                {
                    imageRegion = new HighlightRegion(0, 0, Bitmap.Width, Bitmap.Height, highlightRegion.InsetWidth, highlightRegion.InsetHeight);
                }
                if (imageRegion.IntersectsWith(highlightRegion))
                {
                    imageRegion.Intersect(highlightRegion);
                    iRegion = new ImageRegion(ImageBox, Bitmap, imageRegion, CurrentOCRSize);
                }
                if (iRegion != null)
                {
                    var deskew = imageDeskew.SelectedValue as string;
                    ImageSource image = null;
                    text = iRegion.GetText(out image, out accuracy, characterList, imageFile, textFile, deskew, CurrentOCRLevel);
                    if (images != null)
                    {
                        images.Add(image);
                    }
                }
            }
            return text;
        }

        public string TextOrOCRWithinZone(out bool ocred, out double accuracy, HighlightRegion highlightRegion, Canvas canvas, string imageFile, string textFile, DataCaptureElementType? dcElementType, List<ImageSource> images = null)
        {
            string imageFilePath = System.IO.Path.Combine(WorkingPath, imageFile);
            string textFilePath = System.IO.Path.Combine(WorkingPath, textFile);
            ocred = false;
            var text = TextWithinZone(highlightRegion, canvas, AllowPartial);
            if (text == null && (!TextExists))
            {
                text = OCRWithinZone(out accuracy, highlightRegion, imageFilePath, textFilePath, images);
                ocred = !string.IsNullOrEmpty(text);
            }
            else
            {
                accuracy = 100;
            }
            if (!string.IsNullOrWhiteSpace(text))
            {
                text = text.ConvertUmlautAccents();
                if (!CaptureExtendedChars || (dcElementType != null && dcElementType.Value != DataCaptureElementType.General))
                {
                    text = text.RemoveExtendedCharacters();
                }
                
                if (dcElementType.HasValue)
                {
                    var element = dcElementType.Value.ToString();
                    var numericFields = ConfigurationManager.AppSettings["NumericFields"].Split(',');
                    var spaceAllowedInFields = ConfigurationManager.AppSettings["AllowedSpaceFields"].Split(',');
                    var onlyAlphaNumericFields = ConfigurationManager.AppSettings["OnlyAlphaNumericFields"].Split(',');

                    if (numericFields.Contains(element))
                        text = text.ReplaceAlphabetsbyNumbers();
                    
                    if (!spaceAllowedInFields.Contains(element))
                        text = text.RemoveSpaces();

                    if (onlyAlphaNumericFields.Contains(element))
                        text = text.ToAlphaNumeric();

                    if(element == "TAN" || element== "PANNo")
                    {
                        if (text.Trim().Length >= 10)
                        {
                            var firstPart = text.Substring(0, 5).ReplaceNumbersbyAlphabets();
                            var middlePart = text.Substring(5, 4).ReplaceAlphabetsbyNumbers();
                            var lastPart = text.Substring(9).ReplaceNumbersbyAlphabets();

                            text = "";//$"{firstPart}{middlePart}{lastPart}";
                        }
                    }
                }
            }

            if (!string.IsNullOrEmpty(text))
            {
                text = ApplyReplacements(text);
            }            

            return text;
        }

        public bool CaptureExtendedChars
        {
            get
            {                
                return false;
            }
        }

        public string ApplyReplacements(string text)
        {
            if (!string.IsNullOrEmpty(text) && _Replacements != null)
            {
                foreach (var replaceInfo in _Replacements)
                {
                    if (replaceInfo != null && replaceInfo.IsAll)
                    {
                        text = replaceInfo.Apply(text);
                    }
                }
            }
            return text;
        }

        public int GetCaretIndex(DataCaptureElementType blElementType)
        {
            var element = GetElement(blElementType);
            if (element is MultilineBox)
            {
                return ((MultilineBox)element).GetCaretIndex();
            }            
            if (element is TextBox)
            {
                return ((TextBox)element).CaretIndex;
            }
            return -1;
        }

        public FrameworkElement GetElement(DataCaptureElementType blElementType)
        {
            switch (blElementType)
            {
                //case DataCaptureElementType.MultilineElement1:
                //    return MBMultilineElement1;                                

                case DataCaptureElementType.CertificateAmt:
                    return TBCertificateAmt;

                case DataCaptureElementType.CertificateNo:
                    return TBCertificateNo;

                case DataCaptureElementType.PrescribedRate:
                    return TBPrescribedRate;

                case DataCaptureElementType.Nature:
                    return TBNature;

                //case DataCaptureElementType.IntCol4:
                //    return TBPkgMeasure;

                case DataCaptureElementType.ToDate:
                    return TBToDate;
                
                case DataCaptureElementType.ChallanNo:
                    return TBChallanNo;

                case DataCaptureElementType.SectionCode:
                    return TBSectionCode;

                case DataCaptureElementType.TAN:
                    return TBTAN;

                case DataCaptureElementType.AssessmentYear:
                    return TBAssessmentYear;

                case DataCaptureElementType.TDS:
                    return TBTDS;

                case DataCaptureElementType.Surcharge:
                    return TBSurcharge;

                case DataCaptureElementType.EducationCess:
                    return TBEducationCess;

                case DataCaptureElementType.Interest:
                    return TBInterest;

                case DataCaptureElementType.Fee:
                    return TBFee;

                case DataCaptureElementType.Others:
                    return TBOthers;

                case DataCaptureElementType.TotalTax:
                    return TBTotalTax;

                case DataCaptureElementType.BranchCode:
                    return TBBranchCode;

                case DataCaptureElementType.BankName:
                    return TBBankName;

                case DataCaptureElementType.DepositDate:
                    return TBDepositDate;

                case DataCaptureElementType.MinorHead:
                    return TBMinorHead;

                case DataCaptureElementType.Remarks:
                    return TBRemarks;

                case DataCaptureElementType.CertAckNo:
                    return TBCertAckNo;

                case DataCaptureElementType.CertDate:
                    return TBCertDate;

                case DataCaptureElementType.PANNo:
                    return TBPANNo;

                case DataCaptureElementType.CertName:
                    return TBCertName;

                //case DataCaptureElementType.IntCol3:
                //    return TBPkgNetWeight;

                case DataCaptureElementType.FromDate:
                    return TBFromDate;

                //case DataCaptureElementType.PackageNetMeasure:
                //    return TBPkgNetMeasure;

                //case DataCaptureElementType.PackageNetMeasureUM:
                //    return TBPkgNetUMMeasure;                
            }
            return null;
        }

        private void ApplyPackageGrid(Grid packageGrid)
        {
            if (packageGrid != null)
            {
                bool ocred = false;
                bool tmpocred = false;
                List<GridColumnContent> columnList = new List<GridColumnContent>();
                var regions = packageGrid.GetGridRects(columnList);
                if (regions != null && regions.Length > 0)
                {
                    int rc = regions.GetLength(0);
                    int cc = regions.GetLength(1);
                    string[,] texts = new string[rc, cc];
                    double[,] pcts = new double[rc, cc];
                    for (int r = 0; r < rc; r++)
                    {
                        for (int c = 0; c < cc; c++)
                        {
                            texts[r, c] = TextOrOCRWithinZone(out tmpocred, out pcts[r, c], regions[r, c], PdfCanvas, "OCR_" + r + "_" + c + ".tif", "OCR_" + r + "_" + c + ".txt", null);
                            if (tmpocred)
                            {
                                ocred = true;
                            }
                        }
                    }
                    var popup = new PackageViewer();
                    popup.Owner = this;
                    popup.SetData(texts, pcts, columnList);
                    popup.DataContext = Dc;
                    packageGrid.OCRed = ocred;
                    popup.ShowPackageViewer(packageGrid);
                }
            }
        }

        public void SetImageActionsForPage(ImageAction[] actions, int pageNo)
        {
            if (_ImageActions == null)
            {
                _ImageActions = new List<ImageAction>();
            }
            _ImageActions.RemoveAll(p => p.Page == pageNo && p.IsCustom == true);
            if (actions != null)
            {
                _ImageActions.AddRange(actions);
            }
        }

        private void RemoveImageEdit_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = sender as MenuItem;
            if (menuItem != null)
            {
                var ctx = menuItem.GetContextMenu();
                if (ctx != null)
                {
                    string message = null;
                    var rectangle = ctx.PlacementTarget as Rectangle;
                    if (rectangle != null)
                    {
                        var action = rectangle.Tag as ImageAction;
                        if (action != null)
                        {
                            UndoRedoManager.Current.AddUndoAction(new UndoRedoImageAction(action, _ImageActions.IndexOf(action), true));
                            RemoveImageEdit(action);
                        }
                    }
                }
            }
        }

        public void RemoveImageEdit(ImageAction action)
        {
            if (action != null)
            {
                if (_ImageActions != null)
                {
                    if (action.IsCustom)
                    {
                        action.Skip = true;
                    }
                    else
                    {
                        _ImageActions.Remove(action);
                    }
                }
                var rectangle = action.Rectangle;
                if (rectangle != null)
                {
                    if (_ActionRects != null)
                    {
                        _ActionRects.Remove(rectangle);
                    }
                    if (PdfCanvas != null)
                    {
                        PdfCanvas.Children.Remove(rectangle);
                    }
                    if (action.Page == CurrentPage)
                    {
                        RenderCurrentPage();
                    }
                }
            }
        }

        private void ImageEditSetup_Click(object sender, RoutedEventArgs e)
        {
            var refreshPage = false;
            MenuItem menuItem = sender as MenuItem;
            if (menuItem != null)
            {
                var ctx = menuItem.GetContextMenu();
                if (ctx != null)
                {
                    string message = null;
                    var rectangle = ctx.PlacementTarget as Rectangle;
                    if (rectangle != null)
                    {
                        var action = rectangle.Tag as ImageAction;
                        if (action != null)
                        {
                            var name = menuItem.Name;
                            switch (name)
                            {
                                case "CMImageEditsRegular":
                                    action.IsCustom = false;
                                    action.UpdateRectangeBrush();
                                    UndoRedoManager.Current.AddUndoAction(new UndoRedoImageActionSwitch(action));
                                    break;

                                case "CMImageEditsChange":
                                    var oldRotation = action.Rotation;
                                    if (ApplyImageActionRotate(action) != null)
                                    {
                                        UndoRedoManager.Current.AddUndoAction(new UndoRedoImageActionRotation(action, oldRotation, action.Rotation, action.IsCustom, false));
                                        action.IsCustom = false;
                                        action.UpdateRectangeBrush();
                                        RenderCurrentPage();
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
        }

        private void ApplyActionRectangle(System.Drawing.Bitmap image, params ImageAction[] actions)
        {
            if (actions != null && actions.Length > 0)
            {
                if (_ActionRects == null)
                {
                    _ActionRects = new List<Rectangle>();
                }
                ContextMenu cm = FindResource("CMImageEdits") as ContextMenu;
                var currentPage = CurrentPage;
                double xscale = 1;
                double yscale = 1;
                if (ImageScaleWidth > 0)
                {
                    xscale = (double)ImageScaleWidth / image.Width;
                }
                if (ImageScaleHeight > 0)
                {
                    yscale = (double)ImageScaleHeight / image.Height;
                }
                foreach (var action in actions)
                {
                    if (action != null && action.Page == currentPage && !action.Skip)
                    {
                        var imageEditRect = new Rectangle();
                        action.Rectangle = imageEditRect;
                        action.UpdateRectangeBrush();
                        imageEditRect.Fill = Brushes.Transparent;
                        imageEditRect.Width = (double)action.Width * xscale;
                        imageEditRect.Height = (double)action.Height * yscale;
                        imageEditRect.Tag = action;
                        imageEditRect.ContextMenu = cm;
                        imageEditRect.ContextMenuOpening += imageEditRect_ContextMenuOpening;
                        //imageEditRect.SetBinding(Rectangle.VisibilityProperty, new Binding("IsChecked") { Source = CShowImageEdits, Converter = new BooleanToVisibilityConverter() });
                        Canvas.SetLeft(imageEditRect, (double)action.Left * xscale);
                        Canvas.SetTop(imageEditRect, (double)action.Top * yscale);
                        PdfCanvas.Children.Add(imageEditRect);
                    }
                }
            }
        }

        void imageEditRect_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            var rectangle = sender as FrameworkElement;
            if (rectangle != null && rectangle.ContextMenu != null && rectangle.ContextMenu.Items != null)
            {
                var action = rectangle.Tag as ImageAction;
                if (action != null)
                {
                    foreach (var item in rectangle.ContextMenu.Items)
                    {
                        var frameWorkElement = item as FrameworkElement;
                        var menuItem = item as MenuItem;
                        if (frameWorkElement != null)
                        {
                            switch (frameWorkElement.Name)
                            {
                                case "CMImageEditsRemove":
                                    if (action.Operation == ImageOperation.Erase)
                                    {
                                        menuItem.Header = "Undo Erase";
                                    }
                                    else if (action.Operation == ImageOperation.Deskew)
                                    {
                                        menuItem.Header = "Undo Deskew";
                                    }
                                    else if (action.Operation == ImageOperation.Rotate)
                                    {
                                        menuItem.Header = "Undo Rotate";
                                    }
                                    else
                                    {
                                        menuItem.Header = "Remove Edit";
                                    }
                                    break;

                                case "CMImageEditsRegular":
                                    if (action.IsCustom)
                                    {
                                        frameWorkElement.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        frameWorkElement.Visibility = Visibility.Collapsed;
                                    }
                                    break;

                                case "CMImageEditsChange":
                                    if (action.Operation != ImageOperation.Erase)
                                    {
                                        frameWorkElement.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        frameWorkElement.Visibility = Visibility.Collapsed;
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
        }

        private void ApplyImageAction(HighlightRegion region, ImageOperation imageOperation)
        {
            if (Bitmap != null && Bitmap.Width > 0 && Bitmap.Height > 0)
            {
                region = AdjustRectForImageScaling(region);
                if (Bitmap.Width < (region.Left + region.Width) || Bitmap.Height < (region.Top + region.Height))
                {
                    MessageBox.Show("No underlying image found. Selection is probably outside the image bounds.");
                    return;
                }

                var action = new ImageAction();
                action.Left = region.Left;
                action.Top = region.Top;
                action.Width = region.Width;
                action.Height = region.Height;
                action.Page = CurrentPage;
                action.Operation = imageOperation;

                if (imageOperation == ImageOperation.Rotate)
                {
                    action = ApplyImageActionRotate(action);
                }
                if (action != null)
                {
                    ApplyActionRectangle(Bitmap, action);
                    UndoRedoManager.Current.AddUndoAction(new UndoRedoImageAction(action, _ImageActions.Count(), false));
                }
                AddImageAction(action);
            }
        }

        internal void AddImageAction(ImageAction action, int index = -1)
        {
            if (action != null && !_ImageActions.Contains(action))
            {
                if (index >= 0 && index < _ImageActions.Count())
                {
                    _ImageActions.Insert(index, action);
                }
                else
                {
                    _ImageActions.Add(action);
                }
            }
            if (action.Page == CurrentPage)
            {
                var image = ImageUtils.ApplyImageAction(Bitmap, action);
                FinalizeImage(image);
            }
        }

        private ImageAction ApplyImageActionRotate(ImageAction action)
        {
            var croppedImage = ImageUtils.CropImage(Bitmap, (int)action.Left, (int)action.Top, (int)action.Width, (int)action.Height);
            if (croppedImage != null)
            {
                var rotator = new RotateImage();
                rotator.Rotation = action.Rotation;
                rotator.Owner = this;
                double scaleWidth = 0;
                double scaleHeight = 0;
                if (ImageScaleWidth > 0 && ImageScaleHeight > 0)
                {
                    scaleWidth = (double)ImageScaleWidth / Bitmap.Width * croppedImage.Width;
                    scaleHeight = (double)ImageScaleHeight / Bitmap.Height * croppedImage.Height;
                }
                rotator.SetImage4Rotation(croppedImage, scaleWidth, scaleHeight);
                if (rotator.ShowDialog() == true && rotator.Rotation != 0)
                {
                    action.Rotation = rotator.Rotation;
                    if (action.Operation != ImageOperation.Rotate)
                    {
                        action.Operation = ImageOperation.Rotate;
                    }
                }
                else
                {
                    action = null;
                }
                croppedImage.Dispose();
                GC.Collect();
            }
            return action;
        }

        public void ClearOCRed()
        {
            if (DCELMENTS != null)
            {
                foreach (var element in DCELMENTS)
                {
                    if (element != null)
                    {
                        SetOCRed(element.DCElementType, false);
                    }
                }
            }
        }

        public void SetOCRed(DataCaptureElementType elementType, bool ocred)
        {
            var element = GetElement(elementType);
            if (element != null)
            {
                Brush brush = Brushes.White;
                if (ocred)
                {
                    brush = Brushes.LightYellow;
                }
                if (element is TextBox)
                {
                    ((TextBox)element).Background = brush;
                }
                else if (element is MultilineBox)
                {
                    ((MultilineBox)element).SetTextBrush(brush);
                }                
            }
        }

        public string ApplyText(DataCaptureElementType elementType, FrameworkElement rectangle, bool append, bool insert, bool showMessage)
        {
            string message = null;
            var ocred = false;
            double accuracy = 0;
            var text = TextOrOCRWithinZone(out ocred, out accuracy, rectangle.GetRect().ToHighlightRegion(), rectangle.Parent as Canvas, "OCR.tif", "OCR.txt", elementType);
            if (!string.IsNullOrWhiteSpace(text))
            {
                SetOCRed(elementType, ocred);                
                if (insert || append)
                {
                    string currentValue = Dc.GetElementValue(elementType);
                    int cursorAt = -1;
                    if (insert)
                    {
                        cursorAt = GetCaretIndex(elementType);
                    }                                       
                    
                    text = text.InsertText(currentValue, cursorAt, true);
                }                
                message = Dc.ApplyElement(elementType, accuracy, text, false);
                if (showMessage && !string.IsNullOrWhiteSpace(message))
                {
                    MessageBox.Show(this, message);
                }
            }            

            return message;
        }

        private void TABMain_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RBGeneral.IsChecked != true)
            {
                RBGeneral.IsChecked = true;
            }
        }

        private void BCollapseRight_Click(object sender, RoutedEventArgs e)
        {
            if (GridMainLeftColumn.Width.Value == 0)
            {
                GridMainLeftColumn.Width = new GridLength(LeftColumnWidth, GridUnitType.Pixel);
            }
            else if (GridMainRightColumn.ActualWidth > 0)
            {
                RightColumnWidth = GridMainRightColumn.ActualWidth;
                GridMainRightColumn.Width = new GridLength(0, GridUnitType.Pixel);
                GridMainLeftColumn.Width = new GridLength(1, GridUnitType.Star);
            }
        }

        private void BCollapseLeft_Click(object sender, RoutedEventArgs e)
        {
            if (GridMainRightColumn.Width.Value == 0)
            {
                GridMainRightColumn.Width = new GridLength(RightColumnWidth, GridUnitType.Pixel);
            }
            else if (GridMainLeftColumn.ActualWidth > 0)
            {
                LeftColumnWidth = GridMainLeftColumn.ActualWidth;
                GridMainLeftColumn.Width = new GridLength(0, GridUnitType.Pixel);
                GridMainRightColumn.Width = new GridLength(1, GridUnitType.Star);
            }

        }

        private void BClearBL_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("This will clear all data. Are you sure you want to proceed?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                UndoRedoManager.Current.Clear();
                Dc.Clear();
                ClearOCRed();
            }
        }

        private void BClearSelection_Click(object sender, RoutedEventArgs e)
        {
            ClearSelections();
        }

        private void ClearSelections()
        {
            UndoRedoCollection actions = new UndoRedoCollection();

            foreach (DataCaptureElement element in DCELMENTS)
            {

                var rectangles = element._Rectangles;
                if (rectangles != null)
                {
                    int count = rectangles.Count();
                    for (int i = 0; i < count; i++)
                    {
                        if (rectangles[i] != null)
                        {
                            var undo = new UndoRedoRectangle(element, this, i);
                            actions.Actions.Add(undo);

                            rectangles[i].Width = 0;
                            rectangles[i].Height = 0;
                            Canvas.SetLeft(rectangles[i], 0);
                            Canvas.SetTop(rectangles[i], 0);
                            rectangles[i].Visibility = Visibility.Collapsed;
                        }
                    }
                }
            }
            UndoRedoManager.Current.AddUndoAction(actions);
        }

        //private decimal AgentId
        //{
        //    get
        //    {
        //        if (CurrentUser != null && CurrentUser.CurrentAgent != null)
        //        {
        //            return CurrentUser.CurrentAgent.AgentUid;
        //        }
        //        return -1;
        //    }
        //}

        //private string LogonId
        //{
        //    get
        //    {
        //        if (CurrentUser != null && CurrentUser.LogonId != null)
        //        {
        //            return CurrentUser.LogonId;
        //        }
        //        return string.Empty;
        //    }
        //}

        private void BCreate_Click(object sender, RoutedEventArgs e)
        {            
            try
            {
                var res = (new DbUtility()).SaveInDatabase(Dc, _capturedChallans);
                var msgString = "Data Saved";

                var results = res.Split(',');
                if (results[0] == "1" && results[1] != "1")
                {
                    msgString = "Challan Saved,";                    
                }
                if(results[1] == "-1")
                {
                    msgString += " No Vendor Found to save the Certificate Details";
                }


                MessageBox.Show(msgString);
            }
            catch (Exception ex) {
                string msg = "Insert Error:";
                msg += ex.Message;
                MessageBox.Show(msg);
            }            
        }
       
        private void UpdateCurrentField()
        {

            var currentField = Keyboard.FocusedElement as FrameworkElement;
            if (currentField is TextBox)
            {
                var binding = currentField.GetBindingExpression(TextBox.TextProperty);
                if (binding != null)
                {
                    binding.UpdateSource();
                }
            }
        }

        public double CurrentOCRSize
        {
            get
            {
                double size = 0.0;
                if (OCRSize != null && OCRSize.SelectedValue != null)
                {
                    Double.TryParse(OCRSize.SelectedValue.ToString(), out size);
                }
                if (size == 0.0)
                {
                    size = 1.0;
                }
                return size;
            }
        }

        public int CurrentOCRLevel
        {
            get
            {
                int level = 0;
                if (OCRLevel != null && OCRLevel.SelectedValue != null)
                {
                    Int32.TryParse(OCRLevel.SelectedValue.ToString(), out level);
                }
                if (level < 0)
                {
                    level = 0;
                }
                return level;
            }
        }       

        bool _enableToolTip;
        public bool EnableToolTip
        {
            get
            {
                return _enableToolTip;
            }
            set
            {
                _enableToolTip = value;
                RaisePropertyChanged("EnableToolTip");
            }
        }       

        private void PrepareAndShowAdjustments(params FrameworkElement[] rectangles)
        {
            double minLeft = -1;
            double minTop = -1;
            double maxRight = 0;
            double maxBottom = 0;
            AdjustElements.Clear();
            foreach (var rectangle in rectangles)
            {
                if (rectangle != null && rectangle.IsVisible)
                {
                    var left = Canvas.GetLeft(rectangle);
                    var top = Canvas.GetTop(rectangle);
                    if (rectangle.ActualWidth > 0 && rectangle.ActualHeight > 0 && left > 0 && top > 0)
                    {
                        if (minLeft == -1 || left < minLeft)
                        {
                            minLeft = left;
                        }
                        if (minTop == -1 || top < minTop)
                        {
                            minTop = top;
                        }
                        if (maxRight < (left + rectangle.ActualWidth))
                        {
                            maxRight = left + rectangle.ActualWidth;
                        }
                        if (maxBottom < (top + rectangle.ActualHeight))
                        {
                            maxBottom = top + rectangle.ActualHeight;
                        }
                        AdjustElements.Add(rectangle);
                        HighlightAdorner(rectangle, true);
                    }
                }
            }
            if (AdjustElements.Count() > 0)
            {
                var point = SIZone.PointToScreen(new Point(0, 0));
                var source = PresentationSource.FromVisual(this);
                var xy = source.CompositionTarget.TransformFromDevice.Transform(point);
                var adjust = new AdjustBoxes();
                adjust.SICapture = this;
                adjust.MinLeft = minLeft;
                adjust.MinTop = minTop;
                adjust.MaxRight = maxRight;
                adjust.MaxBottom = maxBottom;
                adjust.CanvasWidth = PdfCanvas.ActualWidth;
                adjust.CanvasHeight = PdfCanvas.ActualHeight;
                adjust.Left = xy.X;
                adjust.Top = xy.Y;
                adjust.ShowDialog();
            }
        }

        internal void AdjustElementsXY(double x, double y)
        {
            if (AdjustElements != null && AdjustElements.Count() > 0)
            {
                foreach (var element in AdjustElements)
                {
                    if (x != 0)
                    {
                        Canvas.SetLeft(element, Canvas.GetLeft(element) + x);
                    }
                    if (y != 0)
                    {
                        Canvas.SetTop(element, Canvas.GetTop(element) + y);
                    }
                }
            }
        }

        internal bool AdjustElementsCoOrdinates(double x, double y, double width, double height)
        {
            if (AdjustElements != null && AdjustElements.Count() > 0)
            {
                if (x < 0)
                {
                    return false;
                }
                if (y < 0)
                {
                    return false;
                }
                if ((x + width) > PdfCanvas.ActualWidth)
                {
                    return false;
                }
                if ((y + height) > PdfCanvas.ActualHeight)
                {
                    return false;
                }
                foreach (var element in AdjustElements)
                {
                    if (x != 0)
                    {
                        Canvas.SetLeft(element, x);
                    }
                    if (y != 0)
                    {
                        Canvas.SetTop(element, y);
                    }
                    element.Width = width;
                    element.Height = height;
                }
                return true;
            }
            return true;
        }

        internal void AdjustElementsOver()
        {
            if (AdjustElements != null && AdjustElements.Count() > 0)
            {
                foreach (var rectangle in AdjustElements)
                {
                    if (SelectionBox != rectangle)
                    {
                        HighlightAdorner(rectangle, false);
                    }
                }
                AdjustElements.Clear();
            }
        }        

        private void BClosePopup_Click(object sender, RoutedEventArgs e)
        {
            BoxPopup.IsOpen = false;
            PdfCanvas.AllowDrop = false;
        }

        private void ShortCuts_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            DragDrop.DoDragDrop(sender as DependencyObject, sender, DragDropEffects.Move);
        }

        private void PdfCanvas_Drop(object sender, DragEventArgs e)
        {
            var selectionBox = SelectionBox;
            if (selectionBox != null && e != null && e.Data != null && e.Data.GetDataPresent(typeof(Rectangle)))
            {
                var box = (Rectangle)e.Data.GetData(typeof(Rectangle));
                if (box != null)
                {
                    var width = box.ActualWidth;
                    var height = box.ActualHeight;
                    var point = e.GetPosition(PdfCanvas);
                    double x = (double)point.X - (double)(width / 2);
                    double y = (double)point.Y - (double)(height / 2);

                    if (x < 0 || y < 0 || x + width >= PdfCanvas.ActualWidth || y + height >= PdfCanvas.ActualHeight)
                    {
                        MessageBox.Show("Skipped as this will result in an overflow");
                        return;
                    }
                    else
                    {
                        Canvas.SetLeft(SelectionBox, x);
                        Canvas.SetTop(SelectionBox, y);
                        SelectionBox.Width = width;
                        SelectionBox.Height = height;
                        SelectionBox.SetPositionInToolTip();
                        SelectionBox.Visibility = Visibility.Visible;
                    }
                }
                BoxPopup.IsOpen = false;
                PdfCanvas.AllowDrop = false;
            }
            return;
        }            

        internal void RotateMainImage(float angle)
        {
            //var rotatedImage = ImageUtils.RotateAndReSize(RotateImage, angle, RotateImage.Width, RotateImage.Height);
            //SetImage(rotatedImage, -1, -1);
        }

        //private void CoOrdinageAdjustments(FrameworkElement rectangle)
        //{
        //    AdjustElements.Clear();
        //    if (rectangle != null && rectangle.IsVisible)
        //    {
        //        var left = Canvas.GetLeft(rectangle);
        //        var top = Canvas.GetTop(rectangle);
        //        var width = rectangle.ActualWidth;
        //        var height = rectangle.ActualHeight;
        //        if (rectangle.ActualWidth > 0 && rectangle.ActualHeight > 0 && left > 0 && top > 0)
        //        {
        //            AdjustElements.Add(rectangle);
        //            HighlightAdorner(rectangle, true);

        //            var point = SIZone.PointToScreen(new Point(0, 0));
        //            var source = PresentationSource.FromVisual(this);
        //            var xy = source.CompositionTarget.TransformFromDevice.Transform(point);

        //            var cobox = new CoOrdinateBoxes();
        //            cobox.SICapture = this;
        //            cobox.Owner = this;
        //            cobox.MaxValues = "[Page] Width: " + PdfCanvas.ActualWidth + ", Height: " + PdfCanvas.ActualHeight;
        //            cobox.BoxLeft = left;
        //            cobox.BoxTop = top;
        //            cobox.BoxWidth = width;
        //            cobox.BoxHeight = height;
        //            cobox.Left = xy.X;
        //            cobox.Top = xy.Y;
        //            cobox.ShowDialog();
        //            AdjustElements.Clear();
        //        }
        //    }
        //}

        private void ClearElementData_Click(object sender, RoutedEventArgs e)
        {
            if (Dc != null)
            {
                MenuItem menu = sender as MenuItem;
                if (menu != null)
                {
                    var ctx = menu.GetContextMenu();
                    if (ctx != null)
                    {
                        string message = null;
                        var rb = ctx.PlacementTarget as RadioButton;
                        if (rb != null)
                        {
                            var blElement = rb.Tag as DataCaptureElement;
                            if (blElement != null)
                            {
                                if ("CMClearElementSelection".Equals(menu.Name))
                                {
                                    var rectangle = blElement.GetRectangle(CurrentPage);
                                    if (rectangle != null)
                                    {
                                        ClearRectangle(rectangle);
                                    }
                                }
                                else
                                {
                                    Dc.Clear(blElement.DCElementType);
                                    SetOCRed(blElement.DCElementType, false);
                                }
                            }
                        }
                    }
                }
            }
        }        

        private void ClearText_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menu = sender as MenuItem;
            if (menu != null)
            {
                var ctx = menu.GetContextMenu();
                if (ctx != null)
                {
                    var tb = ctx.PlacementTarget as TextBox;
                    if (tb != null)
                    {
                        tb.Clear();
                        if (tb == TemplatePath)
                        {
                            ClearSelections();
                        }
                    }

                }
            }
        }

        private void OCRFix_Click(object sender, RoutedEventArgs e)
        {
            (sender as MenuItem).ExecuteOCRFix(this);
        }       

        public DataCaptureInfo DCInfo
        {
            get
            {
                return Dc;
            }
        }

        private void Prepare4New(bool confirm)
        {
            if (!confirm)
            {
                confirm = MessageBox.Show("This will clear everything. Are you sure you want to start over?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes;
            }
            if (confirm)
            {
                UndoRedoManager.Current.Clear();
                TemplatePath.Text = "";                
                Dc.Clear();
                ClearOCRed();
                ClearSelections();
                FilePath.Text = "";
                pager.SelectedIndex = -1;
                pager.Items.Clear();
                ClearCanvas(false);
                SetPageSize(0, 0);                            
            }
        }

        private void BNew_Click(object sender, RoutedEventArgs e)
        {
            Prepare4New(false);
        }

        private void BCopyPackageGrid_Click(object sender, RoutedEventArgs e)
        {
            var currentPage = CurrentPage;
            if (currentPage != -1)
            {
                var pkgElement = DCELMENTS.Where(p => p.DCElementType == DataCaptureElementType.PackageGrid).FirstOrDefault();
                if (pkgElement != null)
                {
                    var packageGrid = pkgElement.GetRectangle(currentPage) as Grid;
                    if (packageGrid != null)
                    {
                        CopyPackageGrid(packageGrid);
                        if (packageGrid.Visibility != Visibility.Visible)
                        {
                            packageGrid.Visibility = Visibility.Visible;
                        }
                        return;
                    }
                }
            }
            MessageBox.Show("No Information available to copy package grid.");
        }

        private void imageFlip_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RenderCurrentPage();
        }

        private void imageDeskew_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BDeskewCustom != null)
            {
                var deskew = imageDeskew.SelectedValue as string;
                if (Constants.DESKEWCUSTOM.Equals(deskew))
                {
                    BDeskewCustom.Visibility = Visibility.Visible;
                }
                else
                {
                    BDeskewCustom.Visibility = Visibility.Collapsed;
                }
            }
            RenderCurrentPage();
        }
               
        private void DataGridRow_PreviewMouseLeftButtonDownEvent(object sender, MouseButtonEventArgs e)
        {
            var dgr = sender as DataGridRow;
            if (sender != null)
            {
                DragDrop.DoDragDrop(dgr, dgr, DragDropEffects.Move | DragDropEffects.Copy);
            }
        }

        private void DataGridRow_Drop(object sender, DragEventArgs e)
        {
            var dgr = sender as DataGridRow;
            if (sender != null && e.Data != null && e.Data.GetDataPresent(typeof(DataGridRow)))
            {
                var sourceDGR = e.Data.GetData(typeof(DataGridRow)) as DataGridRow;
                if (sourceDGR != null)
                {
                    var copy = (e.KeyStates & DragDropKeyStates.ControlKey) == DragDropKeyStates.ControlKey;
                    if (!Dc.CopyOrMovePackageInfo(copy, sourceDGR.DataContext as GridInfo, dgr.DataContext as GridInfo))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void BDeskewCustom_Click(object sender, RoutedEventArgs e)
        {
            var custom = new CustomDeskew();
            custom.Owner = this;
            custom.SetTBValues(DeskewInfo);
            if (custom.ShowDialog() == true)
            {
                RenderCurrentPage();
            }
        }

        //private void AlternateFont_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    RenderCurrentPage();
        //}        

        private void DataGrid_Drop(object sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(typeof(DataGridRow)))
            {
                var sourceDGR = e.Data.GetData(typeof(DataGridRow)) as DataGridRow;
                if (sourceDGR != null)
                {
                    var copy = (e.KeyStates & DragDropKeyStates.ControlKey) == DragDropKeyStates.ControlKey;
                    if (!Dc.CopyOrMovePackageInfo(copy, sourceDGR.DataContext as GridInfo, null))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        //private void CYDoor_Click(object sender, RoutedEventArgs e)
        //{
        //    var button = sender as Button;
        //    if (button != null)
        //    {
        //        var suffs = new string[] { "CY", "DOOR" };
        //        var suffix = button.Content as string;
        //        var target = button.Tag as string;
        //        var et = BLElementType.PlaceReceipt;
        //        if ("PD".Equals(target))
        //        {
        //            et = BLElementType.PlaceDelivery;
        //        }
        //        var value = Bl.GetElementValue(et);
        //        if (!string.IsNullOrWhiteSpace(value))
        //        {
        //            foreach (var suff in suffs)
        //            {
        //                //var idx = value.IndexOf(", " + suff, StringComparison.InvariantCultureIgnoreCase);
        //                var idx = value.IndexOf(" - " + suff, StringComparison.InvariantCultureIgnoreCase);
        //                if (idx == -1)
        //                {
        //                    //idx = value.IndexOf("," + suff, StringComparison.InvariantCultureIgnoreCase);
        //                    idx = value.IndexOf(" -" + suff, StringComparison.InvariantCultureIgnoreCase);
        //                }
        //                if (idx != -1)
        //                {
        //                    value = value.Substring(0, idx);
        //                }
        //            }
        //            //value = value + ", " + suffix;
        //            value = value + " - " + suffix;
        //            Bl.ApplyElement(et, -1, value, false);
        //        }
        //    }
        //}           

        private void TrySetupDirectories()
        {
            if (TrySetupDirectory(@"C:\DataCaptureData"))
            {
                return;
            }
            if (TrySetupDirectory(@"D:\DataCaptureData"))
            {
                return;
            }
            var dir = Directory.GetCurrentDirectory();
            if (TrySetupDirectory(dir) && IsDirectoryOnFixedDrive(dir))
            {
                return;
            }
            MessageBox.Show("You do not have the required permissions to run this application in the current folder or the current folder is not a local drive. Please contact local helpdesk to set you up properly. Ideally they may create a folder named C:\\BLCaptureData or D:\\BLCaptureData on your local machine. They would also need to give you full access to this folder.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            Application.Current.Shutdown(-1);
        }

        private bool TrySetupDirectory(string directory)
        {
            if (Directory.Exists(directory))
            {
                try
                {
                    var access = Directory.GetAccessControl(directory);
                    var tmp = System.IO.Path.Combine(directory, "tmp.txt");
                    File.WriteAllText(tmp, "");
                    File.Delete(tmp);

                    var instance = CurrentInstance;
                    if (!string.IsNullOrWhiteSpace(instance))
                    {
                        var tmpDir = System.IO.Path.Combine(directory, instance);
                        if (!Directory.Exists(tmpDir))
                        {
                            Directory.CreateDirectory(tmpDir);
                        }
                        directory = tmpDir;
                    }

                    WorkingPath = directory;
                    return true;
                }
                catch
                {
                }
            }
            return false;
        }

        private bool IsDirectoryOnFixedDrive(string directory)
        {
            var isFixed = false;
            var drives = DriveInfo.GetDrives().Where(p => p.DriveType == DriveType.Fixed);
            if (drives != null)
            {
                foreach (var drive in drives)
                {
                    if (directory.StartsWith(drive.RootDirectory.Name, StringComparison.InvariantCultureIgnoreCase))
                    {
                        isFixed = true;
                        break;
                    }
                }
            }
            return isFixed;
        }

        private void BUndo_Click(object sender, RoutedEventArgs e)
        {
            UndoRedoManager.Current.Undo();
        }

        private void BRedo_Click(object sender, RoutedEventArgs e)
        {
            UndoRedoManager.Current.Redo();
        }

        private void TB_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            UndoRedoManager.Current.HandlePreviewKeyDown(sender, e);
        }

        private void BCopyPackageMap_Click(object sender, RoutedEventArgs e)
        {
            //var mapper = new PackageMapper();
            //mapper.Owner = this;
            //mapper.Bl = Dc;
            //mapper.ShowDialog();
        }

        public string GetSourceSubFolder()
        {
            return GetSubFolder("Source", " for storing local copy of Shipping Instruction");
        }

        public string GetConvertSubFolder()
        {
            return GetSubFolder("Convert", " for storing converted PDF version of of Shipping Instruction");
        }

        public string GetLogSubFolder()
        {
            return GetSubFolder("Log", "");
        }

        private string GetSubFolder(string subFolder, string msgSuffix)
        {
            var dirPath = System.IO.Path.Combine(WorkingPath, subFolder);
            if (!Directory.Exists(dirPath))
            {
                try
                {
                    Directory.CreateDirectory(dirPath);
                }
                catch (Exception e)
                {
                    if (!string.IsNullOrWhiteSpace(msgSuffix))
                    {
                        MessageBox.Show("Could not create/access sub folder " + dirPath + msgSuffix, "Error");
                    }
                    e.LogException();
                    dirPath = "";
                }
            }
            return dirPath;
        }            

        public string CurrentInstance
        {
            get
            {                
                return _Instance;
            }
        }

        public IEnumerable<PDFTextRect> TextCollection
        {
            get
            {
                return _TextCollection;
            }
        }

        public IEnumerable<DrawingPath> DrawingPaths
        {
            get
            {
                return _DrawingPaths;
            }
            internal set
            {
                _DrawingPaths.Clear();
                _DrawingPaths.AddRange(value);
            }
        }

        public void PopulateTextCollection(IEnumerable<PDFTextRect> pdfTextRects)
        {
            _TextCollection.Clear();
            if (pdfTextRects != null)
            {
                PDFTextRect last = null;
                foreach (var text in pdfTextRects)
                {
                    try
                    {
                        if (last == null || !last.IsRepeat(text))
                        {
                            _TextCollection.Add(text);
                        }
                        last = text;
                    }
                    catch (Exception e)
                    {
                    }
                }
            }
        }
        
        private void BTMerge_Click(object sender, RoutedEventArgs e)
        {            
        }

        private void BTClearContainersSealNos_Click(object sender, RoutedEventArgs e)
        {            
        }

        //private void ExportToCsv()
        //{
        //    if (Bl != null && Bl.PackageList != null)
        //    {
        //        StringBuilder sb = new StringBuilder();
        //        sb.Append("Count,Type,G/W ,UM, N/W ,UM,G/M,UM,N/M,UM,\"     Mark & Numbers         \" ,\"       Goods Description       \"\n");
        //        foreach (var pkg in Bl.PackageList)
        //        {
        //            sb.Append(FormatCSVData(pkg.PackageCount));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageType));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageWeight));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageWeightUM));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageNetWeight));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageNetWeightUM));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageMeasure));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageMeasureUM));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageNetMeasure));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.PackageNetMeasureUM));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.MarksNos));
        //            sb.Append(",");
        //            sb.Append(FormatCSVData(pkg.GoodsDescription));
        //            sb.Append("\n");
        //        }

        //        string filePath = "";

        //        var dlg = new SaveFileDialog();
        //        dlg.OverwritePrompt = true;
        //        dlg.Filter = "CSV files (*.csv)|*.csv;|All files (*.*)|*.*";//"CSV files (*.csv)";
        //        if (dlg.ShowDialog(this) == true)
        //        {
        //            filePath = dlg.FileName;
        //        }

        //        if (!string.IsNullOrWhiteSpace(filePath))
        //        {
        //            try
        //            {
        //                File.WriteAllText(@filePath, sb.ToString());
        //                MessageBox.Show(this, "Saved the CSV file " + filePath + ".");
        //            }
        //            catch (Exception e)
        //            {
        //                MessageBox.Show(this, "Could not save CSV file " + filePath + ".\nException occurred " + e.Message);
        //                e.LogException();
        //            }
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show(this, "Noting to Save.");
        //    }
        //}

        private string FormatCSVData(string input)
        {
            string output;

            if (input == null)
                output = ",";
            else
                output = "\"" + input.Replace("\"", "\"\"") + "\"";

            return output;
        }

        private void btnAutomate_Click(object sender, RoutedEventArgs e)
        {
            Automate atm = new Automate(this);
            atm.ShowDialog();
        }

        private void BAddChallan_Click(object sender, RoutedEventArgs e)
        {
            AddChallanRowinGrid(Dc);
        }

        private void btnSelectSourceFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Multiselect = false;

            //dlg.Filter = "Zip File| *.zip | Adobe Acrobat PDF";

            if (dlg.ShowDialog() == true)
            {
                tbSourceFile.Text = dlg.FileName;
            }
        }

        private void btnSelectSourceTemplate_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Multiselect = false;

            dlg.Filter = "Template (*.dct)|*.dct";

            if (dlg.ShowDialog() == true)
            {
                tbSourceTemplate.Text = dlg.FileName;
            }
        }

        private void BProcess_Click(object sender, RoutedEventArgs e)
        {
            var zipFilePath = tbSourceFile.Text;
            var templatePath = tbSourceTemplate.Text;
            var extractPath = System.IO.Path.Combine(WorkingPath, "Unzipped");

            if(string.IsNullOrEmpty(zipFilePath) || string.IsNullOrEmpty(templatePath))
            {
                MessageBox.Show("Select Source files and Template");
                return;
            }


            if (!Directory.Exists(extractPath))
                Directory.CreateDirectory(extractPath);

            var di = new DirectoryInfo(extractPath);
            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }

            
            ZipFile.ExtractToDirectory(zipFilePath, extractPath);
            var unzippedFiles = Directory.GetFiles(extractPath);

            foreach (var filePath in unzippedFiles)
            {
                var _reader = GetSIReader(filePath);
                var template = XmlUtils.LoadFile<DCTemplate>(templatePath);
                var tempDc = new DataCaptureInfo();
                XmlUtils.ReadFromTemplate(Current, template, DCELMENTS, tempDc, true);

                if (_reader == null)
                {
                    MessageBox.Show("The Input file type for Filename {filePath} is not supported.");
                    continue;
                }

                int pages = 0;
                _reader.FilePath = filePath;
                if (!string.IsNullOrWhiteSpace(_reader.ErrorMessage))
                {
                    MessageBox.Show(_reader.ErrorMessage);
                    continue;
                }
                else
                    pages = _reader.PageCount;


                for (int i = 1; i <= pages; i++)
                {
                    _reader.RenderPage(i, null, Current, "0", 0, true);
                    var templateInThisPage = template.TemplateElements.Where(x => x.PageNo == i);
                    foreach (var element in DCELMENTS)
                    {
                        var currentTemplate = templateInThisPage.FirstOrDefault(m => m.ElementType == element.DCElementType);
                        if (currentTemplate != null && currentTemplate.Height > 0 && currentTemplate.Width > 0)
                        {
                            bool ocRed = false;
                            double accuracy = 100;
                            var imageFile = "OCR.tif";
                            var textFile = "OCR.txt";
                            var highlightRegion = new HighlightRegion(currentTemplate.Left, currentTemplate.Top, currentTemplate.Width, currentTemplate.Height);
                            var text = TextOrOCRWithinZone(out ocRed, out accuracy, highlightRegion, null, imageFile, textFile, element.DCElementType); //TextWithinZone(highlightRegion, null, true);
                           
                            if (!string.IsNullOrEmpty(text))
                            {
                                //if(element.DCElementType.ToString() == DataCaptureFields.TAN)
                                //{
                                //    tempDc.SetPropertyValue(currentTemplate.ElementType.ToString(), text.RemoveSpaces(), false);
                                //}
                                //else 
                                if(element.DCElementType.ToString() == DataCaptureFields.SectionCode)
                                {
                                    if (!text.Equals("195"))
                                        text = text.Length >= 3 ? text.Substring(0, 3) : text;
                                    tempDc.SetPropertyValue(currentTemplate.ElementType.ToString(), text, false);
                                }
                                else if (element.DCElementType.ToString() == DataCaptureFields.MinorHead)
                                {
                                    tempDc.SetPropertyValue(currentTemplate.ElementType.ToString(), text.ReplaceAndTrim("-", ""), false);
                                }
                                else
                                {
                                    tempDc.SetPropertyValue(currentTemplate.ElementType.ToString(), text, false);
                                }
                                
                            }
                            
                        }
                    }
                }

                File.Delete(filePath);

                AddChallanRowinGrid(tempDc);
            }


        }

        private void capturedChallan_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {

        }

        private void AddChallanRowinGrid(DataCaptureInfo dc)
        {
            var dr = _capturedChallans.NewRow();
            dr["ChallanNo"] = dc.ChallanNo;
            dr["DepositeDate"] = dc.DepositDate;
            dr["AssessmentYear"] = dc.AssessmentYear;
            dr["Tan"] = dc.TAN;
            dr["Section"] = dc.SectionCode;
            dr["MinorHead"] = dc.MinorHead;
            dr["BankName"] = dc.BankName;
            dr["BranchCode"] = dc.BranchCode;
            dr["TDS"] = dc.TDS;
            dr["Surcharge"] = dc.Surcharge;
            dr["Ecess"] = dc.EducationCess;
            dr["Interest"] = dc.Interest;
            dr["Fee(234E)"] = dc.Fee;
            dr["TotalTax"] = dc.TotalTax;
            dr["Others"] = dc.Others;

            _capturedChallans.Rows.Add(dr);
            capturedChallan.ItemsSource = _capturedChallans.DefaultView;
        }        

    }
}