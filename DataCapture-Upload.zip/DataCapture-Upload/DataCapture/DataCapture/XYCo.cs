﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class XYCo : IComparable
    {
        public double X
        {
            get;
            set;
        }

        public double Y
        {
            get;
            set;
        }

        public int CompareTo(object obj)
        {
            XYCo xy = obj as XYCo;
            if (xy != null)
            {

                if (Math.Abs(xy.Y - Y) > 1)
                {
                    if (Y > xy.Y)
                    {
                        return 1;
                    }
                    else if (Y < xy.Y)
                    {
                        return -1;
                    }
                    else
                    {
                        if (X > xy.X)
                        {
                            return 1;
                        }
                        else if (X < xy.X)
                        {
                            return -1;
                        }
                    }
                }
                else
                {
                    if (X > xy.X)
                    {
                        return 1;
                    }
                    else if (X < xy.X)
                    {
                        return -1;
                    }
                }                
            }
            return 0;
        }
    }
}
