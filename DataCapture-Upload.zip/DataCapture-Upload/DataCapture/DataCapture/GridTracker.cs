﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class GridTracker
    {
        public GridTracker()
        {
            PackageGrid = null;
            TrackerType = -1;
            Pos = -1;
        }

        public Grid PackageGrid
        {
            get;
            set;
        }

        public int Pos
        {
            get;
            set;
        }

        public short TrackerType
        {
            get;
            set;
        }

        public GridColumnContent PackageGridColumnContent
        {
            get;
            set;
        }
    }
}
