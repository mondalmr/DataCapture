﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DataCapture
{
    public class TBValidationRule : ValidationRule
    {
        public TBValidationRule()
        {
        }

        public int MaxLength
        {
            get;
            set;
        }

        public bool IsNumber
        {
            get;
            set;
        }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var text = "";
            if (value != null)
            {
                text = value.ToString();
            }
            if (MaxLength > 0)
            {
                if (text.Length > MaxLength)
                {
                    return new ValidationResult(false, "Length can at max be " + MaxLength + " characters. Validated value has " + text.Length + " characters.");
                }
            }
            if (IsNumber)
            {
            }
            return new ValidationResult(true, null);
        }
    }
}
