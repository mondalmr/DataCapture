﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for ExportReference.xaml
    /// </summary>
    public partial class ExportRef : UserControl
    {
        public ExportRef()
        {
            InitializeComponent();
        }

        public void SetTextBrush(Brush brush)
        {
            TBExpRef01.Background = brush;
            TBExpRef02.Background = brush;
            TBExpRef03.Background = brush;
            TBExpRef04.Background = brush;            
        }

        public int GetCaretIndex()
        {
            return -1;
        }

        internal bool AreTBsValid()
        {
            var valid = true;
            if (!TBExpRef01.ValidateText()) { valid = false; }
            if (!TBExpRef02.ValidateText()) { valid = false; }
            if (!TBExpRef03.ValidateText()) { valid = false; }
            if (!TBExpRef04.ValidateText()) { valid = false; }
            
            return valid;
        }
        private void TB_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            UndoRedoManager.Current.HandlePreviewKeyDown(sender, e);
        }

    }
}
