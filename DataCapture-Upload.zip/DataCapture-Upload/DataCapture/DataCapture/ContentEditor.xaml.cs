﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for ContentDisplay.xaml
    /// </summary>
    public partial class ContentEditor : Window
    {
        double LeftColumnWidth;
        double RightColumnWidth;

        public ContentEditor()
        {
            InitializeComponent();
            Loaded += ContentEditor_Loaded;
        }

        void ContentEditor_Loaded(object sender, RoutedEventArgs e)
        {
            //OCRPostUtils.SetupWordCuts(FindResource("CMCtrlQ") as ContextMenu);
            //OCRPostUtils.SetupContextMenu(FindResource("CMCtrlK") as ContextMenu);
            //OCRPostUtils.SetupContextMenu(FindResource("CMSelectedText") as ContextMenu);

            //Title = "Content Editor (OCR Accuracy " + Accuracy + "%)";

            TBContent.Focus();
        }

        public string Text
        {
            get
            {
                return TBContent.Text;
            }
            set
            {
                TBContent.Text = value;
            }
        }

        public ImageSource OCRImage
        {
            get
            {
                return IOCRImage.Source;
            }
            set
            {
                IOCRImage.Source = value;
                if (value != null)
                {
                    ContentRightColumn.Width = new GridLength(1, GridUnitType.Star);
                    ContentSplitter.Width = new GridLength(1, GridUnitType.Auto);
                }
            }
        }

        public DataCaptureInfo BLInfo
        {
            get;
            set;
        }

        public bool EuropeanFormat
        {
            get;
            set;
        }

        public DataCaptureElementType BLElementType
        {
            get
            {
                if (CBElements != null && CBElements.SelectedItem is ComboBoxItem && ((ComboBoxItem)CBElements.SelectedItem).Tag is DataCaptureElementType)
                {
                    return (DataCaptureElementType)((ComboBoxItem)CBElements.SelectedItem).Tag;
                }
                return DataCaptureElementType.General;
            }
        }

        public double Accuracy
        {
            get;
            set;
        }       
        
        private void BApply_Click(object sender, RoutedEventArgs e)
        {
            var ble = BLElementType;
            if (BLInfo != null && ble != null)
            {
                if (ble == DataCaptureElementType.General)
                {
                    MessageBox.Show("Please select an Apply Type other than General");
                    return;
                }
                var text = TBContent.Text;
                if (!string.IsNullOrWhiteSpace(text))
                {
                    var message = BLInfo.ApplyElement(BLElementType, Accuracy, text, EuropeanFormat);
                    if (!string.IsNullOrWhiteSpace(message))
                    {
                        MessageBox.Show(this, message);
                    }
                }
            }
        }

        private void BCopy_Click(object sender, RoutedEventArgs e)
        {
            var text = TBContent.Text;
            if (!string.IsNullOrEmpty(text))
            {
                Clipboard.SetData(DataFormats.Text, text);
            }
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            dlg.OverwritePrompt = true;
            dlg.CheckFileExists = false;
            bool? result = dlg.ShowDialog(this);
            if (result == true)
            {
                string filePath = dlg.FileName;
                if (!string.IsNullOrWhiteSpace(filePath))
                {
                    File.WriteAllText(filePath, TBContent.Text);
                }

            }

        }

        private void BCollapseRight_Click(object sender, RoutedEventArgs e)
        {
            if (ContentLeftColumn.Width.Value == 0)
            {
                ContentLeftColumn.Width = new GridLength(LeftColumnWidth, GridUnitType.Pixel);
            }
            else if (ContentRightColumn.ActualWidth > 0)
            {
                RightColumnWidth = ContentRightColumn.ActualWidth;
                ContentRightColumn.Width = new GridLength(0, GridUnitType.Pixel);
                ContentLeftColumn.Width = new GridLength(1, GridUnitType.Star);
            }
        }

        private void BCollapseLeft_Click(object sender, RoutedEventArgs e)
        {
            if (ContentRightColumn.Width.Value == 0)
            {
                ContentRightColumn.Width = new GridLength(RightColumnWidth, GridUnitType.Pixel);
            }
            else if (ContentLeftColumn.ActualWidth > 0)
            {
                LeftColumnWidth = ContentLeftColumn.ActualWidth;
                ContentLeftColumn.Width = new GridLength(0, GridUnitType.Pixel);
                ContentRightColumn.Width = new GridLength(1, GridUnitType.Star);
            }

        }

        public bool OCRed
        {
            get;
            set;
        }
       
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            OCRPostUtils.ShowOCRFixContext(sender, e);
        }

        public void SetupBLElements(DataCaptureElement[] blElements, DataCaptureElementType currentElement)
        {
            if (CBElements != null && blElements != null)
            {
                CBElements.Items.Clear();

                foreach (var ble in blElements)
                {
                    if (ble != null && ble.DCElementType != DataCaptureElementType.PackageGrid)
                    {
                        CBElements.Items.Add(new ComboBoxItem() { Tag = ble.DCElementType, Content = ble.Name, IsSelected = ble.DCElementType == currentElement });
                    }
                }
                if (currentElement != DataCaptureElementType.General)
                {
                    CBElements.IsEnabled = false;
                }
            }
        }
    }
}
