﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for WordCutEditor.xaml
    /// </summary>
    public partial class WordCutEditor : Window
    {
        public WordCutEditor()
        {
            InitializeComponent();
        }

        private void BClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        public string WordCuts
        {
            get
            {
                return TBWordCuts.Text;
            }
            set
            {
                TBWordCuts.Text = value;
            }
        }
    }
}
