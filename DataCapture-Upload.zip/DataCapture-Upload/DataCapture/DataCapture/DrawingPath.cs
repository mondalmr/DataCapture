﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class DrawingPath
    {
        public DrawingPath(float thickness, Color stroke, Color nonStroke)
        {
            Pen = new Pen(new SolidBrush(stroke), thickness);
            FillBrush = new SolidBrush(nonStroke);
            Path = new GraphicsPath();
        }

        public Pen Pen
        {
            get;
            set;
        }

        public Brush FillBrush
        {
            get;
            set;
        }

        public GraphicsPath Path
        {
            get;
            set;
        }

        public string FillCode
        {
            get;
            set;
        }

        public bool IsFill
        {
            get
            {
                var fill = false;
                switch (FillCode)
                {
                    case PDFOperators.FillStrokeEvenOdd:
                    case PDFOperators.FillStrokeNonZero:
                    case PDFOperators.CloseFillStrokeEvenOdd:
                    case PDFOperators.CloseFillStrokeNonZero:
                    case PDFOperators.FillPathNonZero:
                    case PDFOperators.FillEvenOdd:
                    case PDFOperators.FillPathNonZeroObsolete:
                        fill = true;
                        break;
                }
                return fill;
            }
        }

        public bool IsStroke
        {
            get
            {
                var stroke = !IsFill;
                if (!stroke)
                {
                    stroke = !string.IsNullOrWhiteSpace(FillCode) && (FillCode.IndexOf("Stroke", StringComparison.InvariantCultureIgnoreCase) != -1);
                }
                return stroke;
            }
        }

    }
}
