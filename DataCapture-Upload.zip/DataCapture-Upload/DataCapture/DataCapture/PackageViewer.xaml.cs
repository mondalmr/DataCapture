﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataCapture.DTO;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for PackageViewer.xaml
    /// </summary>
    public partial class PackageViewer : Window
    {
        const string PCTCOLUMNPREFIX = "PCT_";

        List<GridColumnContent> mColumnList;
        DataTable mTable;
        public DataTable mParsedTable;
        DataTable mDataTable;
        Grid mPackageGrid;
        Dictionary<string, GridColumnContent> mColumnContent;

        public PackageViewer()
        {
            InitializeComponent();
            mColumnList = new List<GridColumnContent>();
            mColumnContent = new Dictionary<string, GridColumnContent>();
            mTable = new DataTable();
            mParsedTable = new DataTable();

            Loaded += PackageViewer_Loaded;
        }

        void PackageViewer_Loaded(object sender, RoutedEventArgs e)
        {
            OCRPostUtils.SetupWordCuts(FindResource("CMCtrlQ") as ContextMenu);
            //OCRPostUtils.SetupWordCuts(FindResource("CMCtrlPlus") as ContextMenu);
            OCRPostUtils.SetupContextMenu(FindResource("CMCtrlK") as ContextMenu);
            //OCRPostUtils.SetupContextMenu(FindResource("CMCtrlDot") as ContextMenu);
            OCRPostUtils.SetupContextMenu(FindResource("CMSelectedText") as ContextMenu);
        }

        private void SetDataTable(DataTable dataTable)
        {
            mDataTable = dataTable;
            dgPackage.ItemsSource = mDataTable.DefaultView;
        }

        public void SetData(string[,] textData, double[,] pcts, List<GridColumnContent> columnList)
        {
            string columnHeader = "";
            string columnName = "";
            mColumnContent.Clear();
            dgPackage.Columns.Clear();
            mParsedTable.Clear();
            mParsedTable.Columns.Clear();
            mTable.Clear();
            mTable.Columns.Clear();
            mColumnList = columnList;
            if (textData != null && textData.Length > 0)
            {
                int rows = textData.GetLength(0);
                int cols = textData.GetLength(1);
                for (int c = 0; c < cols; c++)
                {
                    columnName = "COLUMN" + c;
                    columnHeader = "";
                    if (columnList.Count() > c && columnList[c] != null)
                    {
                        mColumnContent[columnName] = columnList[c];
                        if (columnList[c].ColumnList != null)
                        {
                            foreach (var cn in columnList[c].ColumnList)
                            {
                                if (!string.IsNullOrWhiteSpace(cn) && !Grid.DISCARD.Equals(cn))
                                {
                                    string valueColumn = null;
                                    string unitColumn = null;
                                    if (Grid.IsValueUnitColumn(cn, out valueColumn, out unitColumn))
                                    {
                                        mParsedTable.Columns.Add(new DataColumn(PCTCOLUMNPREFIX + valueColumn, typeof(double)) { Caption = "%" });
                                        mParsedTable.Columns.Add(new DataColumn(valueColumn) { Caption = valueColumn });
                                        mParsedTable.Columns.Add(new DataColumn(PCTCOLUMNPREFIX + unitColumn, typeof(double)) { Caption = "%" });
                                        mParsedTable.Columns.Add(new DataColumn(unitColumn) { Caption = unitColumn });
                                    }
                                    else
                                    {
                                        mParsedTable.Columns.Add(new DataColumn(PCTCOLUMNPREFIX + cn, typeof(double)) { Caption = "%" });
                                        mParsedTable.Columns.Add(new DataColumn(cn) { Caption = cn });
                                    }
                                }
                            }
                            columnHeader = string.Join(Environment.NewLine, columnList[c].ColumnList);
                        }
                    }
                    if (string.IsNullOrWhiteSpace(columnHeader))
                    {
                        columnHeader = columnName;
                    }
                    mTable.Columns.Add(new DataColumn(PCTCOLUMNPREFIX + columnName, typeof(double)) { Caption = "%" });
                    mTable.Columns.Add(new DataColumn(columnName) { Caption = columnHeader });
                }
                for (int r = 0; r < rows; r++)
                {
                    DataRow row = mTable.NewRow();
                    for (int c = 0; c < cols; c++)
                    {
                        columnName = "COLUMN" + c;
                        row[columnName] = textData[r, c];
                        row[PCTCOLUMNPREFIX + columnName] = pcts[r, c];
                    }
                    mTable.Rows.Add(row);
                }
                SetDataTable(mTable);
            }
        }

        public bool? ShowPackageViewer(Grid packageGrid)
        {
            if (packageGrid != null)
            {
                mPackageGrid = packageGrid;
                return ShowDialog();
            }
            return false;
        }

        public void ParseTable()
        {
            UnitList unitList = null;
            var euroFormat = false;
            var captureExtendedChars = false;
            var siCapture = Owner as MainWindow;
            if (siCapture != null)
            {
                euroFormat = false;
                captureExtendedChars = siCapture.CaptureExtendedChars;
            }
            mParsedTable.Clear();
            if (mTable != null && mTable.Rows != null && mParsedTable.Columns != null)
            {
                foreach (DataRow row in mTable.Rows)
                {
                    if (row != null)
                    {
                        bool dataFound = false;
                        var newRow = mParsedTable.NewRow();
                        foreach (DataColumn colInfo in mTable.Columns)
                        {
                            if (colInfo != null && !string.IsNullOrWhiteSpace(colInfo.ColumnName))
                            {
                                var cn = colInfo.ColumnName;

                                if (mColumnContent.ContainsKey(cn) && row[cn] != null && row[cn] != DBNull.Value)
                                {
                                    var data = mColumnContent[cn].Parse(row[cn].ToString(), euroFormat, captureExtendedChars, unitList);
                                    if (data != null && data.Keys != null)
                                    {
                                        foreach (var key in data.Keys)
                                        {
                                            if (mParsedTable.Columns.Contains(key))
                                            {
                                                var columnValue = data[key];
                                                if (unitList != null)
                                                {
                                                    switch (key)
                                                    {
                                                        case Grid.CertificateNo:
                                                            columnValue = unitList.MappedCode(UnitType.PackageType, columnValue);
                                                            break;

                                                        case Grid.Nature:
                                                        case Grid.FromDate:
                                                            columnValue = unitList.MappedCode(UnitType.Weight, columnValue);
                                                            break;

                                                        case Grid.ToDate:
                                                        //case Grid.NETMEASUREUM:
                                                            columnValue = unitList.MappedCode(UnitType.Measure, columnValue);
                                                            break;
                                                    }
                                                }
                                                newRow[key] = columnValue;
                                                newRow[PCTCOLUMNPREFIX + key] = row[PCTCOLUMNPREFIX + cn];
                                                dataFound = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (dataFound)
                        {
                            mParsedTable.Rows.Add(newRow);
                        }
                    }
                }
            }
            SetDataTable(mParsedTable);
        }

        private void BPrevious_Click(object sender, RoutedEventArgs e)
        {
            BPrevious.IsEnabled = false;
            BApply.IsEnabled = false;
            BInsert.IsEnabled = false;
            BAppend.IsEnabled = false;
            BNext.IsEnabled = true;

            SetDataTable(mTable);
        }

        private void BNext_Click(object sender, RoutedEventArgs e)
        {
            ParseTable();
            bool applyEnabled = (mParsedTable.Rows != null && mParsedTable.Rows.Count > 0);
            BPrevious.IsEnabled = true;
            BApply.IsEnabled = applyEnabled;
            BInsert.IsEnabled = applyEnabled;
            BAppend.IsEnabled = applyEnabled;
            BNext.IsEnabled = false;
        }

        private void BApply_Click(object sender, RoutedEventArgs e)
        {
            var dcInfo = DataContext as DataCaptureInfo;
            if (dcInfo != null && mParsedTable.Rows != null && mParsedTable.Rows.Count > 0 && dcInfo.PackageList!=null)
            {
                var actions = new UndoRedoCollection();
                var dummyActions = new UndoRedoCollection(); // Used to discard undo redo for individual package info update. Instead entire package value is stored using UndoRedoAddPackage
                var pkgs = dcInfo.PackageList;
                var selIdx = -1;
                var appendIdx = -1;
                if (sender == BInsert && dcInfo.SelectedPackage != null)
                {
                    selIdx = pkgs.IndexOf(dcInfo.SelectedPackage);
                    appendIdx = selIdx - 1;
                }
                if (sender == BAppend)
                {
                    appendIdx = pkgs.Count() - 1;
                }
                if (sender == BApply)
                {
                    if (pkgs.Count() > 0)
                    {
                        //if (MessageBox.Show("Apply will remove existing rows. If you want to keep existing rows, choose Append or Insert. Are you sure you want to remove existing rows and add these rows?", "Warning", MessageBoxButton.YesNo) == MessageBoxResult.No)
                        //{
                        //    return;
                        //}
                    }
                    dcInfo.ClearPackages(actions, true);
                }
                bool goodC = false;
                var appendPrevious = CFirstRowAppend.IsChecked == true;
                if (appendPrevious)
                {
                    if (appendIdx == -1 || appendIdx >= pkgs.Count())
                    {
                        appendPrevious = false;
                    }
                }
                var sbContainers = new StringBuilder();
                foreach (DataRow row in mParsedTable.Rows)
                {
                    if (row != null)
                    {
                        bool goodP = false;
                        bool goodO = false;
                        var pkg = dcInfo.NewPackage(dummyActions);
                        foreach (DataColumn column in mParsedTable.Columns)
                        {
                            if (column != null && !string.IsNullOrWhiteSpace(column.ColumnName) && !column.ColumnName.StartsWith(PCTCOLUMNPREFIX) && row[column] != null && row[column] != DBNull.Value)
                            {
                                var text = row[column].ToString();
                                var pct = "";
                                if (row[PCTCOLUMNPREFIX + column.ColumnName] is double)
                                {
                                    pct = "" + (double)row[PCTCOLUMNPREFIX + column.ColumnName] + "";                                    
                                }

                                if (!string.IsNullOrWhiteSpace(text))
                                {
                                    switch (column.ColumnName)
                                    {                                        
                                        case Grid.CertificateAmt:
                                            pkg.SetPropertyValue(GridInfoFields.CertificateAmt, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageCount, pct, false);
                                            goodP = true;
                                            break;

                                        case Grid.CertificateNo:
                                            pkg.SetPropertyValue(GridInfoFields.CertificateNo, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageType, pct, false);
                                            goodP = true;
                                            break;
                                     
                                        case Grid.PrescribedRate:
                                            pkg.SetPropertyValue(GridInfoFields.PrescribedRate, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageWeight, pct, false);
                                            goodP = true;
                                            break;

                                        case Grid.Nature:
                                            pkg.SetPropertyValue(GridInfoFields.Nature, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageWeightUM, pct, false);
                                            goodP = true;
                                            break;

                                        case Grid.INTCOL3:
                                            pkg.SetPropertyValue(GridInfoFields.IntCol3, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageNetWeight, pct, false);
                                            goodP = true;
                                            break;

                                        case Grid.FromDate:
                                            pkg.SetPropertyValue(GridInfoFields.FromDate, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageNetWeightUM, pct, false);
                                            goodP = true;
                                            break;

                                        case Grid.INTCOL4:
                                            pkg.SetPropertyValue(GridInfoFields.IntCol4, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageMeasure, pct, false);
                                            goodP = true;
                                            break;

                                        case Grid.ToDate:
                                            pkg.SetPropertyValue(GridInfoFields.ToDate, text, false);
                                            //pkg.SetPropertyValue(GridInfoFields.PCTPackageMeasureUM, pct, false);
                                            goodP = true;
                                            break;

                                        //case Grid.NETMEASURE:
                                        //    pkg.SetPropertyValue(GridInfoFields.PackageNetMeasure, text, false);
                                        //    //pkg.SetPropertyValue(GridInfoFields.PCTPackageNetMeasure, pct, false);
                                        //    goodP = true;
                                        //    break;

                                        //case Grid.NETMEASUREUM:
                                        //    pkg.SetPropertyValue(GridInfoFields.PackageNetMeasureUM, text, false);
                                        //    //pkg.SetPropertyValue(GridInfoFields.PCTPackageNetMeasureUM, pct, false);
                                        //    goodP = true;
                                        //    break;
                                    }
                                }
                            }
                        }
                        if (goodP||goodO)
                        {
                            if (appendPrevious)
                            {
                                if (goodP || !goodO)
                                {
                                    appendPrevious = false;
                                }
                                else if (pkgs[appendIdx] == null)
                                {
                                    pkgs[appendIdx] = dcInfo.NewPackage(dummyActions);
                                }
                                if (appendPrevious)
                                {                                    
                                }
                            }
                            if (!appendPrevious)
                            {
                                if (selIdx != -1)
                                {
                                    actions.Actions.Add(new UndoRedoAddPackage(dcInfo, pkg, selIdx));
                                    pkgs.Insert(selIdx, pkg);
                                    selIdx++;
                                }
                                else
                                {
                                    actions.Actions.Add(new UndoRedoAddPackage(dcInfo, pkg, pkgs.Count()));
                                    pkgs.Add(pkg);
                                }
                            }
                        }
                        appendPrevious = false;
                    }
                }
                UndoRedoManager.Current.AddUndoAction(actions);


                var seq = 1;
                pkgs.ToList().ForEach(m => {
                    m.SeqNo = seq.ToString();
                    seq++;
                });

                Close();
            }
        }

        private string MergeText(string text, string appendText)
        {
            var result = text;
            if (string.IsNullOrEmpty(result))
            {
                return appendText;
            }
            if (!result.EndsWith(Environment.NewLine))
            {
                return result + Environment.NewLine + appendText;
            }
            return result + appendText;
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void dgPackage_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (mDataTable != null && mDataTable.Columns != null)
            {
                var dgColumn = e.Column;
                if (dgColumn != null)
                {
                    var name = e.PropertyName;
                    if (!string.IsNullOrWhiteSpace(name))
                    {
                        if (name.StartsWith(PCTCOLUMNPREFIX))
                        {
                            dgColumn.IsReadOnly = true;
                            dgColumn.CellStyle = (Style)FindResource("AccuracyCell");
                        }
                        else
                        {
                            dgColumn.CellStyle = (Style)FindResource("FixableCell");
                        }
                        if (dgColumn is DataGridTextColumn)
                        {
                            ((DataGridTextColumn)dgColumn).EditingElementStyle = (Style)FindResource("FixableEditCell");
                        }
                        var header = name.ToUpper();
                        if (mDataTable.Columns.Contains(name))
                        {
                            header = mDataTable.Columns[name].Caption;
                            dgColumn.Header = header;
                            header = header.ToUpper();
                        }
                        if (header.Contains("MARKS") || header.Contains("GOODS"))
                        {
                            dgColumn.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
                        }
                        else
                        {
                            dgColumn.Width = new DataGridLength(1, DataGridLengthUnitType.Auto);
                        }
                    }
                    else
                    {
                        dgColumn.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
                    }
                }
            }
        }

        private void OCRFix_Click(object sender, RoutedEventArgs e)
        {
            (sender as MenuItem).ExecuteOCRFix(this);
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            OCRPostUtils.ShowOCRFixContext(sender, e);
        }
    }
}
