﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DataCapture
{
    public class AesValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var text = "";

            if (value != null)
            {
                text = value.ToString();
            }

            if (!string.IsNullOrWhiteSpace(text))
            {
                string[] old = text.Split(new string[] { "~" }, StringSplitOptions.RemoveEmptyEntries);
                List<string> oldlist = old.ToList();
                List<string> invalidList = new List<string>();

                foreach (string eqp in oldlist)
                {
                    if (eqp.Length > 25)
                    {
                        invalidList.Add(eqp);
                    }
                }

                if (invalidList.Count > 0)
                {
                    return new ValidationResult(false, "Following Entries have length more than 25: " + string.Join(Environment.NewLine, invalidList.ToArray()));
                }
            }

            return new ValidationResult(true, null);
        }
    }
}
