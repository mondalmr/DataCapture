﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;

namespace DataCapture
{
    public class ShortCutKeyInfo : NotifyInfo
    {
        public ShortCutKeyInfo()
        {
        }

        public ShortCutKeyInfo(string code, string value, Color color, object tag = null)
        {
            Key = code;
            Info = value;
            Background = new SolidColorBrush(color);
            Tag = tag;
        }

        string _key;
        public string Key
        {
            get
            {
                return _key;
            }
            set
            {
                _key = value;
                RaisePropertyChanged("Key");
            }
        }

        string _info;
        public string Info
        {
            get
            {
                return _info;
            }
            set
            {
                _info = value;
                RaisePropertyChanged("Info");
            }
        }

        Brush _brush;
        public Brush Background
        {
            get
            {
                return _brush;
            }
            set
            {
                _brush = value;
                RaisePropertyChanged("Background");
            }
        }

        object _tag;
        public object Tag
        {
            get
            {
                return _tag;
            }
            set
            {
                _tag = value;
                RaisePropertyChanged("Tag");
                RaisePropertyChanged("Cursor");
            }
        }

        public Cursor Cursor
        {
            get
            {
                if (Tag != null)
                {
                    return Cursors.Hand;
                }
                return Cursors.Arrow;
            }
        }


    }
}
