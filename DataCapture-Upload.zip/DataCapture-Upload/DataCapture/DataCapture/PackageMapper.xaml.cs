﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
//using DataCapture.Client;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for PackageMapper.xaml
    /// </summary>
    public partial class PackageMapper : Window
    {
        CreateDataInfo _createBLInfo;

        public PackageMapper()
        {
            _createBLInfo = null;
            InitializeComponent();
        }

        public DataCaptureInfo Bl
        {
            get;
            set;
        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            var dataCapture = Owner as MainWindow;
            if (dataCapture == null)
            {
                return;
            }
            //_createBLInfo = new CreateBLInfo();
            //var msg = "";
            //var unitList = siCapture.FetchUnitList(out msg);
            //if (!string.IsNullOrWhiteSpace(msg) || unitList == null || unitList.Units == null)
            //{
            //    MessageBox.Show("Could not fetch data. Exception occurred. " + msg);
            //    Close();
            //    return;
            //}
            //_createBLInfo.SetupUMs(unitList.Units);
            //if (unitList.Units.Count(p => p.IsMappedValue) > 0)
            //{
            //    TBProgress.Text = "Values in Green are mapped values.";
            //    TBProgress.Foreground = Brushes.Green;
            //}
            //else
            //{
            //    TBProgress.Text = "";
            //}
            _createBLInfo.UpdateValues(Bl.PackageList);
            DataContext = _createBLInfo;
        }

        private void BApply_Click(object sender, RoutedEventArgs e)
        {
            if (_createBLInfo != null && Bl != null)
            {
                _createBLInfo.UpdatePackages(Bl.PackageList);
            }
            DialogResult = true;
            Close();
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Validate()
        {
            if (_createBLInfo != null)
            {
                if (_createBLInfo.PackageUnits != null && _createBLInfo.PackageUnits.Count(p => p.MappedUnit != null) > 0)
                {
                    MessageBox.Show("Please provide missing values for Map Package Units.");
                    return;
                }
                if (_createBLInfo.WeightUnits != null && _createBLInfo.WeightUnits.Count(p => p.MappedUnit != null && !string.IsNullOrWhiteSpace(p.Value)) > 0)
                {
                    MessageBox.Show("Please provide missing values for Map Weight Units.");
                    return;
                }
                if (_createBLInfo.MeasureUnits != null && _createBLInfo.MeasureUnits.Count(p => p.MappedUnit != null && !string.IsNullOrWhiteSpace(p.Value)) > 0)
                {
                    MessageBox.Show("Please provide missing values for Map Measure Units.");
                    return;
                }
            }
        }
    }
}
