﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace DataCapture
{
    public class ReplaceInfo : NotifyInfo, IOCRPostRule
    {
        public const string ALL = "";
        public const string MENU = "M";
        public const string PACKAGETYPE = "PKG";
        public const string PACKAGEWEIGHT = "WGT";
        public const string PACKAGEMEASURE = "MSR";


        public ReplaceInfo()
            : this("", "", true)
        {
        }

        public ReplaceInfo(string search, string replace, bool ignore = true)
        {
            ReplaceCategory = ALL;
            SearchText = search;
            ReplaceText = replace;
            IgnoreCase = ignore;
        }

        string _searchText;
        public string SearchText
        {
            get
            {
                return _searchText;
            }
            set
            {
                _searchText = value;
                RaisePropertyChanged("SearchText");
            }
        }

        string _replaceText;
        public string ReplaceText
        {
            get
            {
                return _replaceText;
            }
            set
            {
                _replaceText = value;
                RaisePropertyChanged("ReplaceText");
            }
        }

        bool _ignoreCase;
        public bool IgnoreCase
        {
            get
            {
                return _ignoreCase;
            }
            set
            {
                _ignoreCase = value;
                RaisePropertyChanged("IgnoreCase");
            }
        }

        public bool IsAll
        {
            get
            {
                return string.IsNullOrWhiteSpace(ReplaceCategory);
            }
        }

        public bool OCRFix
        {
            get
            {
                return MENU.Equals(ReplaceCategory);
            }
            set
            {
                ReplaceCategory = value ? MENU : PACKAGETYPE;
            }
        }

        string _replaceCategory;
        public string ReplaceCategory
        {
            get
            {
                return _replaceCategory;
            }
            set
            {
                _replaceCategory = value;
                RaisePropertyChanged("ReplaceCategory");
                RaisePropertyChanged("OCRFix");
            }
        }

        internal ReplaceInfo MakeClone()
        {
            var repl = new ReplaceInfo();
            repl.SearchText = SearchText;
            repl.ReplaceText = ReplaceText;
            repl.IgnoreCase = IgnoreCase;
            return repl;
        }

        public string Description
        {
            get
            {
                if (string.IsNullOrEmpty(SearchText))
                {
                    return "Do Nothing";
                }
                var search = SearchText;
                var ic = IgnoreCase ? "" : " (matching case)";
                if (" ".Equals(search))
                {
                    search = "space";
                    ic = "";
                }
                if (Environment.NewLine.Equals(search))
                {
                    search = "new line";
                    ic = "";
                }
                if (string.IsNullOrEmpty(ReplaceText))
                {
                    return "Remove " + search;
                }
                return "Replace " + search + " with " + ReplaceText + ic;
            }
        }

        public string Apply(string text)
        {
            return new List<ReplaceInfo> { this }.ReplaceTexts(text);
        }
    }
}
