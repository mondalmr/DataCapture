﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class UndoRedoCollection : IUndoRedo
    {
        public UndoRedoCollection()
        {
            Actions = new List<IUndoRedo>();
        }

        public IList<IUndoRedo> Actions
        {
            get;
            private set;
        }

        public bool HasUndoRedoInfo
        {
            get
            {
                if (Actions != null && Actions.Count() > 0)
                {
                    return true;
                }
                return false;
            }
        }

        public void Undo()
        {
            if (Actions != null)
            {
                var len = Actions.Count() - 1;
                for (int i = len; i >= 0; i--)
                {
                    if (Actions[i] != null)
                    {
                        Actions[i].Undo();
                    }
                }

            }
        }

        public void Redo()
        {
            foreach (var action in Actions)
            {
                action.Redo();
            }
        }
    }
}
