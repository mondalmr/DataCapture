﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class UndoRedoClearPackages : IUndoRedo
    {
        public UndoRedoClearPackages(DataCaptureInfo blInfo)
        {
            BLInfo = blInfo;
            Packages = blInfo.PackageList.ToArray();
        }

        private DataCaptureInfo BLInfo
        {
            get;
            set;
        }

        private GridInfo[] Packages
        {
            get;
            set;
        }

        public bool HasUndoRedoInfo
        {
            get
            {
                if (BLInfo != null && Packages != null && Packages.Length > 0)
                {
                    return true;
                }
                return false;
            }
        }

        public void Undo()
        {
            if (BLInfo != null && BLInfo.PackageList != null && Packages != null && Packages.Length > 0)
            {
                var len = Packages.Length - 1;
                for (int i = len; i >= 0; i--)
                {

                    if (Packages[i] != null && !BLInfo.PackageList.Contains(Packages[i]))
                    {
                        BLInfo.PackageList.Insert(0, Packages[i]);
                    }
                }
            }
        }

        public void Redo()
        {
            if (BLInfo != null && BLInfo.PackageList != null && BLInfo.PackageList.Count() > 0 && Packages != null && Packages.Length > 0)
            {
                foreach (var package in Packages)
                {
                    if (BLInfo.PackageList.Contains(package))
                    {
                        BLInfo.PackageList.Remove(package);
                    }
                }
            }
        }
    }
}
