﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class UndoRedoAddPackage : IUndoRedo
    {
        public UndoRedoAddPackage(DataCaptureInfo blInfo)
        {
            BLInfo = blInfo;
            if (BLInfo != null)
            {
                PackageInfo = BLInfo.SelectedPackage;
                PackageIndex = BLInfo.SelectedPackageIndex;
            }
            else
            {
                PackageInfo = null;
                PackageIndex = -1;
            }
        }

        public UndoRedoAddPackage(DataCaptureInfo blInfo, GridInfo packageInfo, int packageIndex)
        {
            BLInfo = blInfo;
            PackageInfo = packageInfo;
            PackageIndex = packageIndex;
        }

        private DataCaptureInfo BLInfo
        {
            get;
            set;
        }

        private int PackageIndex
        {
            get;
            set;
        }

        private GridInfo PackageInfo
        {
            get;
            set;
        }

        public bool HasUndoRedoInfo
        {
            get
            {
                if (BLInfo != null && PackageIndex >= 0 && PackageInfo != null)
                {
                    return true;
                }
                return false;
            }
        }

        public void Undo()
        {
            if (BLInfo != null && BLInfo.PackageList != null)
            {
                var count = BLInfo.PackageList.Count();
                if (count > PackageIndex)
                {
                    if (BLInfo.PackageList[PackageIndex] == PackageInfo)
                    {
                        BLInfo.PackageList.RemoveAt(PackageIndex);
                    }
                }
            }
        }

        public void Redo()
        {
            if (BLInfo != null && BLInfo.PackageList != null)
            {
                var count = BLInfo.PackageList.Count();
                if (count > PackageIndex)
                {
                    BLInfo.PackageList.Insert(PackageIndex, PackageInfo);
                }
                else
                {
                    PackageIndex = count;
                    BLInfo.PackageList.Add(PackageInfo);
                }
            }
        }
    }
}
