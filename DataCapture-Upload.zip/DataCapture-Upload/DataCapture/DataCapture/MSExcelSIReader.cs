﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using Microsoft.Office.Interop.Excel;

namespace DataCapture
{
    public class MSExcelSIReader : PDFSIReader
    {

        public MSExcelSIReader(MainWindow siCapture)
            : base(siCapture)
        {
        }

        public override string Description
        {
            get
            {
                return "Microsoft Excel";
            }
        }

        public override string[] SupportedExtensions
        {
            get
            {
                return new string[] { "xlsx", "xls" };
            }
        }

        public override string FilePath
        {
            get
            {
                return base.FilePath;
            }
            set
            {
                if (string.Compare(base.FilePath, value, true) != 0)
                {
                    if (File.Exists(value))
                    {
                        FileInfo fi = new FileInfo(value);
                        if (_Window == null)
                        {
                            _ErrorMessage = "Could not access RootWindow.";
                        }
                        else
                        {
                            var convertFolder = _Window.GetConvertSubFolder();
                            if (string.IsNullOrWhiteSpace(convertFolder))
                            {
                                _ErrorMessage = "Could not access converted version storage folder.";
                            }
                            else
                            {
                                string targetFileName = Path.Combine(convertFolder, fi.Name + ".pdf");
                                
                                if (File.Exists(targetFileName))
                                {
                                    int i = 1;
                                    while (File.Exists(targetFileName.Substring(0, targetFileName.LastIndexOf('.')) + "_" + i + targetFileName.Substring(targetFileName.LastIndexOf('.'))))
                                        i++;
                                    targetFileName = targetFileName.Substring(0, targetFileName.LastIndexOf('.')) + "_" + i + targetFileName.Substring(targetFileName.LastIndexOf('.'));
                                }

                                string message = MSOfficeUtils.MSExcelToPdf(value, targetFileName);
                                if (!string.IsNullOrWhiteSpace(message))
                                {
                                    _ErrorMessage = message;
                                }
                                else
                                {
                                    base.FilePath = targetFileName;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
