﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for ExportReference.xaml
    /// </summary>
    public partial class ExportReference : UserControl
    {
        public ExportReference()
        {
            InitializeComponent();
        }

        public void SetTextBrush(Brush brush)
        {
            TBAnXr01.Background = brush;
            TBAnXr02.Background = brush;
            TBAnXr03.Background = brush;
            TBAnXr04.Background = brush;
            TBAnXr05.Background = brush;
            TBAnXr06.Background = brush;
            TBAnXr07.Background = brush;
            TBAnXr08.Background = brush;
            TBAnXr09.Background = brush;
            TBAnXr10.Background = brush;
        }

        public int GetCaretIndex()
        {
            return -1;
        }

        internal bool AreTBsValid()
        {
            var valid = true;
            if (!TBAnXr01.ValidateText()) { valid = false; }
            if (!TBAnXr02.ValidateText()) { valid = false; }
            if (!TBAnXr03.ValidateText()) { valid = false; }
            if (!TBAnXr04.ValidateText()) { valid = false; }
            if (!TBAnXr05.ValidateText()) { valid = false; }
            if (!TBAnXr05.ValidateText()) { valid = false; }
            if (!TBAnXr07.ValidateText()) { valid = false; }
            if (!TBAnXr08.ValidateText()) { valid = false; }
            if (!TBAnXr09.ValidateText()) { valid = false; }
            if (!TBAnXr10.ValidateText()) { valid = false; }
            return valid;
        }

        private void TB_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            UndoRedoManager.Current.HandlePreviewKeyDown(sender, e);
        }

    }
}
