﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public static class GridInfoFields
    {
        //public const string MarksNos = "MarksNos";
        //public const string GoodsDescription = "GoodsDescription";

        public const string CertificateAmt = "CertificateAmt";
        public const string PackageCountError = "PackageCountError";
        public const string PackageCountHasError = "PackageCountHasError";

        public const string CertificateNo = "CertificateNo";
        public const string PackageTypeError = "PackageTypeError";
        public const string PackageTypeHasError = "PackageTypeHasError";

        public const string PrescribedRate = "PrescribedRate";
        public const string PackageWeightError = "PackageWeightError";
        public const string PackageWeightHasError = "PackageWeightHasError";

        public const string Nature = "Nature";
        public const string PackageWeightUMError = "PackageWeightUMError";
        public const string PackageWeightUMHasError = "PackageWeightUMHasError";

        public const string IntCol4 = "IntCol4";
        public const string PackageMeasureError = "PackageMeasureError";
        public const string PackageMeasureHasError = "PackageMeasureHasError";

        public const string ToDate = "ToDate";
        public const string PackageMeasureUMError = "PackageMeasureUMError";
        public const string PackageMeasureUMHasError = "PackageMeasureUMHasError";

        public const string IntCol3 = "IntCol3";
        public const string PackageNetWeightError = "PackageNetWeightError";
        public const string PackageNetWeightHasError = "PackageNetWeightHasError";

        public const string FromDate = "FromDate";
        public const string PackageNetWeightUMError = "PackageNetWeightUMError";
        public const string PackageNetWeightUMHasError = "PackageNetWeightUMHasError";

        //public const string PackageNetMeasure = "PackageNetMeasure";
        public const string PackageNetMeasureError = "PackageNetMeasureError";
        public const string PackageNetMeasureHasError = "PackageNetMeasureHasError";

        //public const string PackageNetMeasureUM = "PackageNetMeasureUM";
        public const string PackageNetMeasureUMError = "PackageNetMeasureUMError";
        public const string PackageNetMeasureUMHasError = "PackageNetMeasureUMHasError";


        public const string SeqNo = "SeqNo";
        public const string PackageSeqNoError = "PackageSeqNoError";
        public const string PackageSeqNoHasError = "PackageSeqNoHasError";
        //public const string PackageEqpNo = "PackageEqpNo";
        //public const string PackageEqpNoError = "PackageEqpNoError";
        //public const string PackageEqpNoHasError = "PackageEqpNoHasError";

        //public const string PCTMarksNos = "PCTMarksNos";
        //public const string PCTGoodsDescription = "PCTGoodsDescription";
        public const string PCTPackageCount = "PCTPackageCount";
        public const string PCTPackageType = "PCTPackageType";
        public const string PCTPackageWeight = "PCTPackageWeight";
        public const string PCTPackageWeightUM = "PCTPackageWeightUM";
        public const string PCTPackageMeasure = "PCTPackageMeasure";
        public const string PCTPackageMeasureUM = "PCTPackageMeasureUM";
        public const string PCTPackageNetWeight = "PCTPackageNetWeight";
        public const string PCTPackageNetWeightUM = "PCTPackageNetWeightUM";
        public const string PCTPackageNetMeasure = "PCTPackageNetMeasure";
        public const string PCTPackageNetMeasureUM = "PCTPackageNetMeasureUM";
    }
}
