﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class OCRPostRemoveRule : IOCRPostRule
    {
        public OCRPostRemoveRule(string description, string characterList)
        {
            Description = description;
            CharacterList = characterList;
        }

        public string CharacterList
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }

        public string Apply(string text)
        {
            if (text == null || string.IsNullOrWhiteSpace(CharacterList))
            {
                return text;
            }
            var list = CharacterList.ToArray();
            var chars = text.ToCharArray();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < chars.Length; i++)
            {
                if (!list.Contains(chars[i]))
                {
                    sb.Append(chars[i]);
                }
            }
            return sb.ToString();
        }
    }
}
