﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public static class DataCaptureFields
    {
        public const string DefaultPkgCode = "DefaultPkgCode";
        public const string DefaultGWUM = "DefaultGWUM";
        public const string DefaultNWUM = "DefaultNWUM";
        public const string DefaultGMUM = "DefaultGMUM";
        public const string DefaultNMUM = "DefaultNMUM";
        
        public const string ChallanNo = "ChallanNo";
        public const string SectionCode = "SectionCode";
        public const string TAN = "TAN";
        public const string AssessmentYear = "AssessmentYear";
        public const string TDS = "TDS";
        public const string Surcharge = "Surcharge";
        public const string EducationCess = "EducationCess";
        public const string Interest = "Interest";
        public const string Fee = "Fee";
        public const string Others = "Others";
        public const string TotalTax = "TotalTax";
        public const string BranchCode = "BranchCode";
        public const string BankName = "BankName";
        public const string DepositDate = "DepositDate";
        public const string MinorHead = "MinorHead";
        public const string Remarks = "Remarks";

        public const string CertAckNo = "CertAckNo";
        public const string CertDate = "CertDate";
        public const string PANNo = "PANNo";
        public const string CertName = "CertName";

        //public const string BLTextBody = "BLTextBody";
        //public const string PreCarriage = "PreCarriage";
        //public const string PlaceReceipt = "PlaceReceipt";
        //public const string OceanVessel = "OceanVessel";
        //public const string OceanVoyage = "OceanVoyage";
        //public const string PortLoading = "PortLoading";
        //public const string PortDischarge = "PortDischarge";
        //public const string PlaceDelivery = "PlaceDelivery";
        //public const string AnpXr01 = "AnpXr01";
        //public const string AnpXr02 = "AnpXr02";
        //public const string AnpXr03 = "AnpXr03";
        //public const string AnpXr04 = "AnpXr04";
        //public const string AnpXr05 = "AnpXr05";
        //public const string AnpXr06 = "AnpXr06";
        //public const string AnpXr07 = "AnpXr07";
        //public const string AnpXr08 = "AnpXr08";
        //public const string AnpXr09 = "AnpXr09";
        //public const string AnpXr10 = "AnpXr10";
        //public const string Containers = "Containers";

        //public const string SealNos = "SealNos";
        //public const string ContainersSealNos = "ContainersSealNos";

        //public const string PCTBLNo = "PCTBLNo";
        //public const string PCTPrimaryBookingNo = "PCTPrimaryBookingNo";
        //public const string PCTAdditionalBookingNos = "PCTAdditionalBookingNos";
        //public const string PCTBLTextBody = "PCTBLTextBody";
        //public const string PCTPreCarriage = "PCTPreCarriage";
        //public const string PCTPlaceReceipt = "PCTPlaceReceipt";
        //public const string PCTOceanVessel = "PCTOceanVessel";
        //public const string PCTOceanVoyage = "PCTOceanVoyage";
        //public const string PCTPortLoading = "PCTPortLoading";
        //public const string PCTPortDischarge = "PCTPortDischarge";
        //public const string PCTPlaceDelivery = "PCTPlaceDelivery";
        //public const string PCTAnpXr = "PCTAnpXr";
        //public const string PCTContainers = "PCTContainers";

        //public const string PCTSealNos = "PCTSealNos";

        //public const string NoOfContainersSealNos = "NoOfContainersSealNos";

        //public const string ExpRef01 = "ExpRef01";
        //public const string ExpRef02 = "ExpRef02";
        //public const string ExpRef03 = "ExpRef03";
        //public const string ExpRef04 = "ExpRef04";
        //public const string PCTExpref = "PCTExpref";

        public const string TextAreaElement1 = "TextAreaElement1";
        //public const string PCTAESNo = "PCTAESNo";

        //public const string Por = "Por";
        //public const string PCTPor = "PCTPor";

        //public const string Pori = "Pori";
        //public const string PCTPori = "PCTPori";

        //public const string PorType = "PorType";

        //public const string OriginPlace = "OriginPlace";
        //public const string PCTOrigin = "PCTOrigin";
        //public const string FinalDestination = "FinalDestination";
        //public const string PCTFinalDestination = "PCTFinalDestination";        
    }
}
