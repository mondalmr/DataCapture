﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    public class BoxAdorner : Adorner
    {
        Thumb North;
        Thumb South;
        Thumb East;
        Thumb West;
        Thumb NorthEast;
        Thumb NorthWest;
        Thumb SouthEast;
        Thumb SouthWest;
        VisualCollection Visuals;
        double BoxThickness;

        public static MainWindow RootWindow
        {
            get;
            set;
        }

        public BoxAdorner(UIElement adornedElement, bool setHorizontal = true, bool setVertical = true)
            : base(adornedElement)
        {
            if (setHorizontal && setVertical)
            {
                BoxThickness = 3;
            }
            else
            {
                BoxThickness = 1;
            }
            //Visibility = adornedElement.Visibility;
            SetupThumbs(setHorizontal, setVertical);

        }

        private Thumb AddThumb(Cursor cursor)
        {
            Thumb thumb = new Thumb();
            if (RootWindow != null)
            {
                thumb.Style = (Style)RootWindow.FindResource("ThumbStyle");
            }
            thumb.Opacity = 0.4;
            thumb.Padding = new Thickness(0);
            thumb.BorderThickness = new Thickness(0);
            thumb.Background = Brushes.Transparent;
            thumb.Cursor = cursor;
            thumb.DragStarted += thumb_DragStarted;
            thumb.DragCompleted += thumb_DragCompleted;
            thumb.DragDelta += thumb_DragDelta;
            Visuals.Add(thumb);
            return thumb;
        }

        void thumb_DragCompleted(object sender, DragCompletedEventArgs e)
        {
            FrameworkElement rectangle = AdornedElement as FrameworkElement;
            if (rectangle != null)
            {
                var blElement = rectangle.Tag as DataCaptureElement;
                if (blElement != null)
                {
                    RootWindow.RegisterUnderRedoRectangle();
                }
            }
        }

        void thumb_DragStarted(object sender, DragStartedEventArgs e)
        {
            FrameworkElement rectangle = AdornedElement as FrameworkElement;
            if (rectangle != null)
            {
                var blElement = rectangle.Tag as DataCaptureElement;
                if (blElement != null)
                {
                    RootWindow.InitUndoRedoRectangle(blElement);
                }
            }
        }

        void thumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            FrameworkElement rectangle = AdornedElement as FrameworkElement;
            Thumb thumb = sender as Thumb;
            if (rectangle != null && thumb != null)
            {
                if (RootWindow != null)
                {
                    //RootWindow.UpdateMagnifier();
                }
                double left = Canvas.GetLeft(rectangle);
                double top = Canvas.GetTop(rectangle);
                double width = rectangle.ActualWidth;
                double height = rectangle.Height;
                bool changeX = false;
                bool changeY = false;
                var tracker = rectangle.Tag as GridTracker;
                var x = e.HorizontalChange;
                var y = e.VerticalChange;
                if (thumb == South || thumb == SouthEast || thumb == SouthWest)
                {
                    height += y;
                }
                if (thumb == North || thumb == NorthEast || thumb == NorthWest)
                {
                    if (South != null) // for full box
                    {
                        height -= y;
                    }
                    if (height > 0)
                    {
                        top += y;
                        if (top < 0)
                        {
                            top = 0;
                        }
                        changeY = true;
                    }
                }
                if (thumb == East || thumb == NorthEast || thumb == SouthEast)
                {
                    width += x;
                }
                if (thumb == West || thumb == NorthWest || thumb == SouthWest)
                {
                    if (East != null) // for full box
                    {
                        width -= x;
                    }
                    if (width > 0)
                    {
                        left += x;
                        if (left < 0)
                        {
                            left = 0;
                        }
                        changeX = true;
                    }
                }
                if (height > 0 && South != null)
                {
                    rectangle.Height = height;
                }
                if (changeY)
                {
                    Canvas.SetTop(rectangle, top);
                    if (tracker != null && tracker.PackageGrid != null)
                    {
                        tracker.PackageGrid.UpdateNewValue(tracker.TrackerType, tracker.Pos, top);
                    }
                }
                if (width > 0 && East != null)
                {
                    rectangle.Width = width;
                }
                if (changeX)
                {
                    Canvas.SetLeft(rectangle, left);
                    if (tracker != null && tracker.PackageGrid != null)
                    {
                        tracker.PackageGrid.UpdateNewValue(tracker.TrackerType, tracker.Pos, left);
                    }
                }
                rectangle.SetPositionInToolTip();
            }
        }

        public void Highlight(bool highlight)
        {
            Brush brush = Brushes.Transparent;
            if (highlight)
            {
                brush = Brushes.Black;
                if (RootWindow != null)
                {
                    brush = (Brush)RootWindow.FindResource("StripedBrush");
                }
            }
            North.Background = brush;
            NorthWest.Background = brush;
            NorthEast.Background = brush;
            South.Background = brush;
            SouthWest.Background = brush;
            SouthEast.Background = brush;
            West.Background = brush;
            East.Background = brush;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            double left = Math.Max(BoxThickness, 0);
            double top = Math.Max(BoxThickness, 0);
            double right = Math.Max(finalSize.Width - BoxThickness, 0);
            double bottom = Math.Max(finalSize.Height - BoxThickness, 0);
            double width = Math.Max(right - BoxThickness, 0);
            double height = Math.Max(bottom - BoxThickness, 0);

            if (NorthWest != null)
            {
                NorthWest.Arrange(new Rect(0, 0, BoxThickness, BoxThickness));
            }
            if (NorthEast != null)
            {
                NorthEast.Arrange(new Rect(right, 0, BoxThickness, BoxThickness));
            }
            if (SouthWest != null)
            {
                SouthWest.Arrange(new Rect(0, bottom, BoxThickness, BoxThickness));
            }
            if (SouthEast != null)
            {
                SouthEast.Arrange(new Rect(right, bottom, BoxThickness, BoxThickness));
            }
            if (North != null)
            {
                North.Arrange(new Rect(left, 0, width, BoxThickness));
            }
            if (South != null)
            {
                South.Arrange(new Rect(left, bottom, width, BoxThickness));
            }
            if (West != null)
            {
                West.Arrange(new Rect(0, top, BoxThickness, height));
            }
            if (East != null)
            {
                East.Arrange(new Rect(right, top, BoxThickness, height));
            }
            return finalSize;
        }

        private void SetupThumbs(bool setHorizontal, bool setVertical)
        {
            Visuals = new VisualCollection(this);
            if (setHorizontal)
            {
                North = AddThumb(Cursors.SizeNS);
                if (setVertical)
                {
                    South = AddThumb(Cursors.SizeNS);
                }
            }
            if (setVertical)
            {
                West = AddThumb(Cursors.SizeWE);
                if (setHorizontal)
                {
                    East = AddThumb(Cursors.SizeWE);
                }
            }
            if (setHorizontal && setVertical)
            {
                NorthEast = AddThumb(Cursors.SizeNESW);
                NorthWest = AddThumb(Cursors.SizeNWSE);
                SouthEast = AddThumb(Cursors.SizeNWSE);
                SouthWest = AddThumb(Cursors.SizeNESW);
            }
        }

        protected override int VisualChildrenCount
        {
            get
            {
                if (Visuals != null)
                {
                    return Visuals.Count;
                }
                return base.VisualChildrenCount;
            }
        }

        protected override Visual GetVisualChild(int index)
        {
            if (Visuals != null && Visuals.Count > index)
            {
                return Visuals[index];
            }
            return base.GetVisualChild(index);
        }
    }
}