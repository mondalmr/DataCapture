﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataCapture
{
    
    public class Grid : Control
    {

        const short ROW = 0;
        const short COLUMN = 1;
        const short COLUMNCONTENT = 2;        
        const short ROWPKG = 5;
        const short ROWEND = 6;

        public const string DISCARD = "<Discard>";
        
        public const string CertificateAmt = "CertificateAmt";
        public const string CertificateNo = "CertificateNo";        
        public const string PrescribedRate = "PrescribedRate";
        public const string Nature = "Nature";        
        public const string INTCOL3 = "IntCol3";
        public const string FromDate = "FromDate";        
        public const string INTCOL4 = "IntCol4";
        public const string ToDate = "ToDate";
        
        static Grid()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Grid), new FrameworkPropertyMetadata(typeof(Grid)));
        }

        public static bool IsValueUnitColumn(string columnName, out string valueColumn, out string unitColumn)
        {
            valueColumn = null;
            unitColumn = null;            
            return false;
        }


        public static bool IsDecimalColumn(string columnName)
        {
            switch (columnName)
            {
                case CertificateAmt:
                case PrescribedRate:
                case INTCOL3:
                case INTCOL4:                
                    return true;
            }
            return false;
        }

        public static bool IsMultiLineColumn(string columnName)
        {
            switch (columnName)
            {
                case "":                
                    return true;
            }
            return false;
        }

        Panel _canvas;
        Point _lastMousePoint;

        ObservableCollection<string> _columnAvailable;
        List<GridColumnContent> _columnContents;

        List<double> _columns;
        List<double> _rows;        
        List<double> _rowsPkg;
        List<double> _rowsEnd;

        public Grid()
        {
            _canvas = null;
            SetupProperties();
            SetupAvailableColumns();
            PreviewMouseDown += PackageGrid_PreviewMouseDown;
            MouseDoubleClick += PackageGrid_MouseDoubleClick;
            SizeChanged += PackageGrid_SizeChanged;
        }

        internal void SetupProperties()
        {
            if (_columnContents == null)
            {
                _columnContents = new List<GridColumnContent>();
            }
            if (_columns == null)
            {
                _columns = new List<double>();
            }

            if (_rows == null)
            {
                _rows = new List<double>();
            }
            
            if (_rowsPkg == null)
            {
                _rowsPkg = new List<double>();
            }

            if (_rowsEnd == null)
            {
                _rowsEnd = new List<double>();
            }
        }

        internal void SetupAvailableColumns()
        {

            if (_columnAvailable == null)
            {
                _columnAvailable = new ObservableCollection<string>();
            }
            _columnAvailable.Clear();

            _columnAvailable.Add(DISCARD);
            
            _columnAvailable.Add(CertificateAmt);
            _columnAvailable.Add(CertificateNo);            
            
            _columnAvailable.Add(PrescribedRate);
            _columnAvailable.Add(Nature);

            //_columnAvailable.Add(INTCOL3);
            _columnAvailable.Add(FromDate);

            //_columnAvailable.Add(INTCOL4);
            _columnAvailable.Add(ToDate);

            if (_columnContents != null)
            {
                foreach (var cc in _columnContents)
                {
                    if (cc != null && cc.ColumnList != null)
                    {
                        foreach (var c in cc.ColumnList)
                        {
                            RemoveAvailableColumns(c);
                        }
                    }
                }
            }

            SortAvailableColumns();

        }

        public Window MainWindow
        {
            get;
            set;
        }

        internal double[] SerializeRows
        {
            get
            {
                return _rows.ToArray();
            }
            set
            {
                _rows.Clear();
                if (value != null)
                {
                    _rows.AddRange(value);
                }
            }
        }

        internal double[] SerializeRowsPkg
        {
            get
            {
                return _rowsPkg.ToArray();
            }
            set
            {
                _rowsPkg.Clear();
                if (value != null)
                {
                    _rowsPkg.AddRange(value);
                }
            }
        }
        
        internal double[] SerializeRowsEnd
        {
            get
            {
                return _rowsEnd.ToArray();
            }
            set
            {
                _rowsEnd.Clear();
                if (value != null)
                {
                    _rowsEnd.AddRange(value);
                }
            }
        }

        internal double[] SerializeColumns
        {
            get
            {
                return _columns.ToArray();
            }
            set
            {
                _columns.Clear();
                if (value != null)
                {
                    _columns.AddRange(value);
                }
            }
        }

        internal GridColumnContent[] SerializeColumnContents
        {
            get
            {
                return _columnContents.ToArray();
            }
            set
            {
                _columnContents.Clear();
                if (value != null)
                {
                    foreach (var cc in value)
                    {
                        if (cc != null)
                        {
                            cc.PackageGrid = this;
                        }
                    }
                    _columnContents.AddRange(value);
                }
            }
        }

        internal string[] SerializeAvailableColumns
        {
            get
            {
                return _columnAvailable.ToArray();
            }
            set
            {
                _columnAvailable.Clear();
                if (value != null)
                {
                    Array.Sort(value);
                    foreach (var text in value)
                    {
                        if (text != null)
                        {
                            _columnAvailable.Add(text);
                        }
                    }
                }
            }
        }

        public ObservableCollection<string> AvailableColumns
        {
            get
            {
                return _columnAvailable;
            }
        }

        public HighlightRegion[,] GetGridRects(List<GridColumnContent> columnList)
        {
            StringBuilder sb = new StringBuilder();

            _rows.Sort();
            _rowsEnd.Sort();
            _rowsPkg.Sort();
            //_rowsMks.Sort();
            //_rowsGds.Sort();
            _columns.Sort();
            _columnContents.Sort((cc1, cc2) => cc1.X.CompareTo(cc2.X));

            LayoutElements();
            columnList.Clear();

            double xfrom = 0;
            double xto = 0;
            bool columnContentFound = false;
            int nonDiscardCounts = 0;
            for (int i = 0; i <= _columns.Count(); i++)
            {
                if (_columns.Count() > i)
                {
                    xto = _columns[i];
                }
                else
                {
                    xto = ActualWidth;
                }
                GridColumnContent columnContent = null;
                for (int j = 0; j < _columnContents.Count(); j++)
                {
                    if (xfrom <= _columnContents[j].X && xto >= _columnContents[j].X)
                    {
                        if (columnContent != null)
                        {
                            MessageBox.Show("Column #" + (i + 1) + " has more than one column content. Please fix and try again.");
                            return null;
                        }
                        columnContent = _columnContents[j];
                        if (!columnContentFound && columnContent != null && columnContent.ColumnList != null)
                        {
                            nonDiscardCounts = columnContent.ColumnList.Count(p => !DISCARD.Equals(p));
                            if (nonDiscardCounts > 0)
                            {
                                columnContentFound = true;
                            }
                        }
                    }
                }
                if (columnContent != null)
                {
                    columnList.Add(columnContent);
                }
                else
                {
                    columnList.Add(null);
                }
                xfrom = xto + 1;
            }
            if (!columnContentFound)
            {
                MessageBox.Show("No column contents found that can be used to map to Packages. In order to proceed you will need to specify atleast one target attribute that is other than discard.");
                return null;
            }

            double pr; // previous row
            double nr; // next row

            double xx;
            double yy;
            double ww;
            double hh;
            double iw;
            double ih;

            var left = Canvas.GetLeft(this);
            var top = Canvas.GetTop(this);
            var width = ActualWidth;
            var height = ActualHeight;
            var x = left;
            var y = top;
            double w = 0;
            double h = 0;
            var rc = RowCount;
            var cc = ColumnCount;
            var regions = new HighlightRegion[rc, cc];

            // pr and nr are used to find the rows for mks, gds and pkgs for current row
            // it is evaluated to beginning and end of row 
            pr = 0; // initiate to 0
            nr = 0; // initate to 0;

            // looping through rows first (rc is always total rows plus one
            for (int i = 0; i < rc; i++)
            {
                width = ActualWidth; // reset width to width of grid
                x = left; // reset x to left co-ordinate of grid

                if (i > 0)
                {
                    pr = _rows[i - 1]; // pr is set as value of previous row
                }
                else
                {
                    pr = 0; // pr is set as 0
                }

                // last row gets remaining height or 0
                if (i == (rc - 1))
                {
                    if (height > 0)
                    {
                        h = height;
                    }
                    else
                    {
                        h = 0;
                    }
                    //nr = h; // nr is set as remaining height for last row
                    nr = ActualHeight ; // nr is set as remaining height for last row
                }
                else
                {
                    nr = _rows[i]; // nr is set to current row
                    h = _rows[i] + top - y; // row height is row position + top of grid - row position of last row (0 if first row)
                    height = height - h;
                }

                // moved here as it is the same for all columns
                yy = y - 1; // adjust divider row's height
                hh = h;
                if (yy < 0)
                {
                    yy = 0;
                    hh += 1;
                }
                else
                {
                    hh += 2;
                }
                var rowEnd = _rowsEnd.Where(p => p > pr && p < nr).Select(p => p).FirstOrDefault();
                if (rowEnd > 0)
                {
                    nr = rowEnd;
                    hh = nr - pr;
                }
                // end of moved part

                var pkgRow = _rowsPkg.Where(p => p > pr && p < nr).Select(p => p).FirstOrDefault();
                var pkgCol = 0;

                //var mksRow = _rowsMks.Where(p => p > pr && p < nr).Select(p => p).FirstOrDefault();
                var mksCol = 0;

                //var gdsRow = _rowsGds.Where(p => p > pr && p < nr).Select(p => p).FirstOrDefault();
                var gdsCol = 0;

                var rh = hh;

                // loop through all columns for each row
                for (int j = 0; j < cc; j++)
                {
                    iw = 0;
                    ih = 0;
                    rh = hh;

                    // set width to remaining grid width if last column
                    if (j == (cc - 1))
                    {
                        if (width > 0)
                        {
                            w = width;
                        }
                        else
                        {
                            w = 0;
                        }
                    }
                    else
                    {
                        w = _columns[j] + left - x; // column position + column width is left of grid - column position of last column (0 if first column)
                        width = width - w;
                    }
                    xx = x - 1; // adjust divider column's width
                    ww = w;
                    
                    // adjust for less than 0 for x
                    if (xx < 0)
                    {
                        xx = 0;
                        w += 1;
                    }
                    else
                    {
                        ww += 2;
                    }

                    if (columnList.Count() > j && columnList[j] != null)
                    {

                        double spanX = 0;
                        int spanC = 0;

                        var adjHeight = 0d;
                        // check if any of the columns on the left are overflowing to
                        // this column. if so adjust height of current column getting
                        // the lowest value of pkg, mks or gds row begin marker
                        if (pkgCol > 1)
                        {
                            adjHeight = ((adjHeight == 0) ? pkgRow : Math.Min(adjHeight, pkgRow));
                            pkgCol--;
                        }
                        //if (mksCol > 1)
                        //{
                        //    adjHeight = ((adjHeight == 0) ? mksRow : Math.Min(adjHeight, mksRow));
                        //    mksCol--;
                        //}
                        //if (gdsCol > 1)
                        //{
                        //    adjHeight = ((adjHeight == 0) ? gdsRow : Math.Min(adjHeight, gdsRow));
                        //    gdsCol--;
                        //}
                        if (adjHeight > 0 && adjHeight >= pr)
                        {
                            rh = adjHeight - pr;
                            ih = 0;
                        }
                        // End of adjust height logic
                        spanX = -1;
                        int pkgCC = 0;
                        int mksCC = 0;
                        int gdsCC = 0;
                        if (columnList[j].IsPackageCount(out pkgCC))
                        {
                            if (pkgCC > 1)
                            {
                                if (spanC < pkgCC)
                                {
                                    spanC = pkgCC;
                                }
                                if (spanX == -1 || spanX > pkgRow)
                                {
                                    spanX = pkgRow;
                                }
                                pkgCol = spanC;
                            }
                        }
                        //if (columnList[j].IsMarksNos(out mksCC))
                        //{
                        //    if (mksCC > 1)
                        //    {
                        //        if (spanC < mksCC)
                        //        {
                        //            spanC = mksCC;
                        //        }
                        //        if (spanX == -1 || spanX > mksRow)
                        //        {
                        //            spanX = mksRow;
                        //        }
                        //        mksCol = spanC;
                        //    }
                        //}
                        //if (columnList[j].IsGoodsDescription(out gdsCC))
                        //{
                        //    if (gdsCC > 0)
                        //    {
                        //        if (spanC < gdsCC)
                        //        {
                        //            spanC = gdsCC;
                        //        }
                        //        if (spanX == -1 || spanX > gdsRow)
                        //        {
                        //            spanX = gdsRow;
                        //        }
                        //        gdsCol = spanC;
                        //    }
                        //}

                        if (spanX < 0)
                        {
                            spanX = 0;
                        }

                        if (spanC > 1 && spanX > 0)
                        {
                            spanC--;
                            ih = spanX - pr;
                            if (cc > (j + spanC + 1))
                            {
                                iw = _columns[j + spanC] - _columns[j];
                            }
                            else
                            {
                                iw = ActualWidth - _columns[j];
                            }
                            ww += iw;
                        }
                    }

                    regions[i, j] = new HighlightRegion(xx, yy, ww, rh, iw, ih);
                    x = x + w;

                }
                y = y + h;
            }
            return regions;
        }

        void PackageGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                AddRow();
            }
            else if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
            {
                AddColumnContent(-1, true);
            }
            else if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
            {
                AddColumn();
            }
        }


        void PackageGrid_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            bool updateLayout = false;
            if (RemoveOutsideElements(_columns, true))
            {
                updateLayout = true;
            }
            if (RemoveOutsideColumnContents(_columnContents))
            {
                updateLayout = true;
            }
            if (RemoveOutsideElements(_rows, false))
            {
                updateLayout = true;
            }
            //if (RemoveOutsideElements(_rowsMks, false))
            //{
            //    updateLayout = true;
            //}
            //if (RemoveOutsideElements(_rowsGds, false))
            //{
            //    updateLayout = true;
            //}
            if (RemoveOutsideElements(_rowsPkg, false))
            {
                updateLayout = true;
            }
            if (RemoveOutsideElements(_rowsEnd, false))
            {
                updateLayout = true;
            }
            if (updateLayout)
            {
                LayoutElements();
            }
        }

        private bool RemoveOutsideColumnContents(List<GridColumnContent> elements)
        {
            bool removed = false;
            if (elements != null)
            {
                var count = elements.Count() - 1;
                if (count >= 0)
                {
                    var width = ActualWidth;
                    for (int i = count; i >= 0; i--)
                    {
                        if (elements[i].X > width)
                        {
                            RemoveColumnContent(i, false);
                            removed = true;
                        }
                    }
                }
            }
            return removed;
        }

        private bool RemoveOutsideElements(List<double> elements, bool isWidth)
        {
            bool removed = false;
            if (elements != null)
            {
                var count = elements.Count() - 1;
                if (count >= 0)
                {
                    var widthOrHeight = ActualHeight;
                    if (isWidth)
                    {
                        widthOrHeight = ActualWidth;
                    }
                    for (int i = count; i >= 0; i--)
                    {
                        if (elements[i] > widthOrHeight)
                        {
                            elements.RemoveAt(i);
                            removed = true;
                        }
                    }
                }
            }
            return removed;
        }

        void PackageGrid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.RightButton == MouseButtonState.Pressed || e.LeftButton == MouseButtonState.Pressed)
            {
                var point = Mouse.GetPosition(this);
                _lastMousePoint = new Point(point.X - 2, point.Y - 2);
            }
        }

        #region overrides
        /// <summary>
        /// Initialize members on Apply Template
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            InitializeComponents();
        }

        /// <summary>
        /// Property changed
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            UpdateProperty(e.Property);
        }
        #endregion

        /// <summary>
        /// Initialize members
        /// </summary>
        private void InitializeComponents()
        {
            UpdateProperty(null);
            LayoutElements();
        }

        /// <summary>
        /// Code for property change and initialization
        /// </summary>
        /// <param name="property"></param>
        private void UpdateProperty(DependencyProperty property)
        {
        }

        private bool UpdateColumnContentPosition(List<GridColumnContent> columnContents, int idx, double newValue)
        {
            if (idx > -1 && columnContents != null && columnContents.Count() > idx)
            {
                columnContents[idx].X = newValue;
                if (newValue > ActualWidth) // Remove if outside width
                {
                    RemoveColumnContent(idx, false);
                    return true;
                }
            }
            return false;
        }

        private bool UpdateElementPosition(List<double> elements, bool isWidth, int idx, double newValue)
        {
            if (idx > -1 && elements != null && elements.Count() > idx)
            {
                elements[idx] = newValue;
                if (newValue > (isWidth ? ActualWidth : ActualHeight)) // Remove if outside width or height
                {
                    elements.RemoveAt(idx);
                    return true;
                }
            }
            return false;
        }

        public void UpdateNewValue(short contentType, int idx, double newValue)
        {
            bool updateLayout = false;
            object item = null;
            if (idx > -1)
            {
                switch (contentType)
                {
                    case COLUMN:
                        updateLayout = UpdateElementPosition(_columns, true, idx, newValue);
                        break;

                    case COLUMNCONTENT:
                        updateLayout = UpdateColumnContentPosition(_columnContents, idx, newValue);
                        break;

                    case ROW:
                        updateLayout = UpdateElementPosition(_rows, false, idx, newValue);
                        break;

                    case ROWPKG:
                        updateLayout = UpdateElementPosition(_rowsPkg, false, idx, newValue);
                        break;

                    //case ROWMKS:
                    //    updateLayout = UpdateElementPosition(_rowsMks, false, idx, newValue);
                    //    break;

                    //case ROWGDS:
                    //    updateLayout = UpdateElementPosition(_rowsGds, false, idx, newValue);
                    //    break;

                    case ROWEND:
                        updateLayout = UpdateElementPosition(_rowsEnd, false, idx, newValue);
                        break;
                }
            }

            if (updateLayout)
            {
                LayoutElements();
            }
        }

        public void AddRow()
        {
            _rows.Add(_lastMousePoint.Y);
            AddElement(ROW, _lastMousePoint.Y, _rows.Count() - 1);
        }

        public void AddRowPackageCount()
        {
            _rowsPkg.Add(_lastMousePoint.Y);
            AddElement(ROWPKG, _lastMousePoint.Y, _rowsPkg.Count() - 1);
        }

        public void AddRowEnds()
        {
            _rowsEnd.Add(_lastMousePoint.Y);
            AddElement(ROWEND, _lastMousePoint.Y, _rowsEnd.Count() - 1);
        }
        
        public GridColumnContent AddColumnContent(double x, bool showEditor)
        {
            if (x == -1)
            {
                x = _lastMousePoint.X;
            }
            var columnContent = new GridColumnContent() { X = x, PackageGrid = this };
            _columnContents.Add(columnContent);
            AddElement(COLUMNCONTENT, x, _columnContents.Count() - 1);
            if (showEditor)
            {
                ShowColumnContentEditor(columnContent);
            }
            return columnContent;
        }

        public void AddColumn()
        {
            _columns.Add(_lastMousePoint.X);
            AddElement(COLUMN, _lastMousePoint.X, _columns.Count() - 1);
        }

        private void AddElement(short contentType, double pos, int idx)
        {
            Panel canvas = FindCanvas();
            if (canvas != null)
            {
                if (contentType == COLUMNCONTENT)
                {
                    Button button = new Button();
                    if (MainWindow != null)
                    {
                        button.Style = (Style)MainWindow.FindResource("PackageGridButton");
                    }
                    button.Cursor = Cursors.Hand;
                    button.Tag = new GridTracker() { TrackerType = contentType, PackageGrid = this, Pos = idx, PackageGridColumnContent = _columnContents[idx] };
                    _columnContents[idx].Button = button;
                    button.Click += button_Click;
                    Canvas.SetLeft(button, pos);
                    Canvas.SetTop(button, 2);
                    _canvas.Children.Add(button);
                }
                else
                {
                    bool setHorizontal = false;
                    bool setVertical = false;
                    Rectangle separator = new Rectangle();
                    separator.Stroke = BorderBrush;
                    separator.Stroke = Brushes.Red;
                    separator.Margin = new Thickness(0);
                    if (contentType == COLUMN)
                    {
                        separator.Width = 0.5;
                        Binding binding = new Binding("ActualHeight");
                        binding.Source = canvas;
                        separator.SetBinding(Rectangle.HeightProperty, binding);
                        Canvas.SetLeft(separator, pos);
                        Canvas.SetTop(separator, 0);
                        setVertical = true;
                        separator.Tag = new GridTracker() { TrackerType = contentType, PackageGrid = this, Pos = idx };
                    }
                    else
                    {
                        if (contentType == ROWPKG)
                        {
                            separator.Stroke = Brushes.Teal;
                        }
                        //else if (contentType == ROWMKS)
                        //{
                        //    separator.Stroke = Brushes.Blue;
                        //}
                        //else if (contentType == ROWGDS)
                        //{
                        //    separator.Stroke = Brushes.Orange;
                        //}
                        else if (contentType == ROWEND)
                        {
                            separator.Stroke = Brushes.RosyBrown;
                        }
                        separator.Height = 0.5;
                        Binding binding = new Binding("ActualWidth");
                        binding.Source = canvas;
                        separator.SetBinding(Rectangle.WidthProperty, binding);
                        Canvas.SetTop(separator, pos);
                        Canvas.SetLeft(separator, 0);
                        setHorizontal = true;
                        separator.Tag = new GridTracker() { TrackerType = contentType, PackageGrid = this, Pos = idx };
                    }

                    _canvas.Children.Add(separator);
                    AdornerLayer.GetAdornerLayer(separator).Add(new BoxAdorner(separator, setHorizontal, setVertical));
                }

            }
        }

        void button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                GridTracker tracker = button.Tag as GridTracker;
                if (tracker != null)
                {
                    ShowColumnContentEditor(tracker.PackageGridColumnContent);
                }
            }
        }

        public void ShowAllColumnContentsEditor()
        {
            if (_columns == null)
            {
                MessageBox.Show("No columns have been defined. Please define columns first and try again.");
                return;
            }
            _columns.Sort();
            _columnContents.Sort((cc1, cc2) => cc1.X.CompareTo(cc2.X));

            GridColumnContent cc = null;
            var len = _columns.Count;
            var ccs = new GridColumnContent[len + 1];

            double xfrom = 0;
            double xto = 0;
            for (int i = 0; i <= len; i++)
            {
                if (len > i)
                {
                    xto = _columns[i];
                }
                else
                {
                    xto = ActualWidth;
                }

                cc = null;
                for (int j = 0; j < _columnContents.Count(); j++)
                {
                    if (xfrom <= _columnContents[j].X && xto >= _columnContents[j].X)
                    {
                        if (cc != null)
                        {
                            MessageBox.Show("Column #" + (i + 1) + " has more than one column content. Please fix and try again.");
                            return;
                        }
                        cc = _columnContents[j];
                    }
                }
                ccs[i] = cc;

                xfrom = xto + 1;
            }

            var resort = false;
            for (int i = 0; i <= len; i++)
            {
                if (ccs[i] == null)
                {
                    double x = i == 0 ? 0 : _columns[i - 1] + 1;
                    ccs[i] = AddColumnContent(x, false);
                    resort = true;
                }
            }

            if (resort)
            {
                _columnContents.Sort((cc1, cc2) => cc1.X.CompareTo(cc2.X));
            }

            var window = new GridColumnEditor();
            window.Owner = MainWindow;
            window.SetupListBox(ccs);
            window.ShowDialog();


        }

        private void ShowColumnContentEditor(GridColumnContent contentColumn)
        {
            if (contentColumn != null)
            {
                var buttton = contentColumn.Button;
                var window = new GridColumnEditor();
                window.Owner = MainWindow;
                window.DataContext = contentColumn;
                window.ShowDialog();
                if (window.RemoveOnExit)
                {
                    RemoveColumnContent(contentColumn, true);
                }
                else
                {
                    if (buttton != null)
                    {
                        var columnList = contentColumn.ColumnList;
                        if (columnList != null && columnList.Count() > 0)
                        {
                            buttton.ToolTip = string.Join(Environment.NewLine, contentColumn.ColumnList);
                        }
                        else
                        {
                            buttton.ToolTip = "<No columns defined>";
                        }
                    }
                }
            }
        }

        internal void LayoutElements()
        {
            Panel canvas = FindCanvas();
            if (canvas != null)
            {
                canvas.Children.Clear();
                int count = _columnContents.Count();
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        AddElement(COLUMNCONTENT, _columnContents[i].X, i);
                    }
                }
                count = _columns.Count();
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        AddElement(COLUMN, _columns[i], i);
                    }
                }
                count = _rows.Count();
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        AddElement(ROW, _rows[i], i);
                    }
                }
                count = _rowsPkg.Count();
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        AddElement(ROWPKG, _rowsPkg[i], i);
                    }
                }
                count = _rowsEnd.Count();
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        AddElement(ROWEND, _rowsEnd[i], i);
                    }
                }
                //count = _rowsMks.Count();
                //if (count > 0)
                //{
                //    for (int i = 0; i < count; i++)
                //    {
                //        AddElement(ROWMKS, _rowsMks[i], i);
                //    }
                //}
                //count = _rowsGds.Count();
                //if (count > 0)
                //{
                //    for (int i = 0; i < count; i++)
                //    {
                //        AddElement(ROWGDS, _rowsGds[i], i);
                //    }
                //}
            }
        }

        public void ClearColumnContents()
        {
            if (_columnContents != null)
            {
                int count = _columnContents.Count() - 1;
                if (count >= 0)
                {
                    for (int i = count; i >= 0; i--)
                    {
                        RemoveColumnContent(i, false);
                    }
                    LayoutElements();
                }
            }
        }

        public void ClearSplits(bool columns, bool rows)
        {
            if (columns)
            {
                _columns.Clear();
            }
            if (rows)
            {
                //_rowsGds.Clear();
                //_rowsMks.Clear();
                _rowsPkg.Clear();
                _rowsEnd.Clear();
                _rows.Clear();
            }
            LayoutElements();
        }

        private Panel FindCanvas()
        {
            try
            {
                if (_canvas == null)
                {
                    _canvas = this.Template.FindName("INNER_Canvas", this) as Panel;
                }
            }
            catch(Exception ex)
            {

            }
            
            return _canvas;
        }

        public int ColumnCount
        {
            get
            {
                if (_columns != null)
                {
                    return _columns.Count() + 1;
                }
                return 0;
            }
        }

        public int RowCount
        {
            get
            {
                if (_rows != null)
                {
                    return _rows.Count() + 1;
                }
                return 0;
            }
        }

        public void RemoveAvailableColumns(string value)
        {
            if (!string.IsNullOrWhiteSpace(value) && !Grid.DISCARD.Equals(value, StringComparison.InvariantCultureIgnoreCase))
            {
                _columnAvailable.Remove(value);
                if (!AdjustForValueUnit(value, true))
                {
                    SortAvailableColumns();
                }
            }
        }

        private void SortAvailableColumns()
        {
            if (_columnAvailable != null)
            {
                var values = _columnAvailable.ToArray();
                if (values != null && values.Length > 0)
                {
                    Array.Sort(values);
                    _columnAvailable.Clear();
                    foreach (var value in values)
                    {
                        _columnAvailable.Add(value);
                    }
                }
            }
        }

        public void AddAvailableColumns(string value)
        {
            _columnAvailable.Add(value);
            if (!AdjustForValueUnit(value, false))
            {
                SortAvailableColumns();
            }
        }

        public void RemoveColumnContent(int idx, bool updateLayout)
        {
            if (idx >= 0 && _columnContents.Count() > idx)
            {
                if (_columnContents[idx] != null && _columnContents[idx].ColumnList != null)
                {
                    foreach (var col in _columnContents[idx].ColumnList)
                    {
                        if (!string.IsNullOrWhiteSpace(col) && !DISCARD.Equals(col))
                        {
                            AddAvailableColumns(col);
                        }
                    }
                }
                _columnContents.RemoveAt(idx);
                if (updateLayout)
                {
                    LayoutElements();
                }
            }
        }

        public void RemoveColumnContent(GridColumnContent columnContent, bool updateLayout)
        {
            if (columnContent != null)
            {
                RemoveColumnContent(_columnContents.IndexOf(columnContent), updateLayout);
            }
        }

        public void CopyFrom(Grid grid)
        {
            if (grid != null)
            {
                Canvas.SetLeft(this, Canvas.GetLeft(grid));
                Width = grid.Width;
                Canvas.SetTop(this, Canvas.GetTop(grid));
                Height = grid.Height;

                _columns.Clear();
                _columns.AddRange(grid._columns);

                _columnContents.Clear();
                foreach (var cc in grid._columnContents)
                {
                    _columnContents.Add(cc.MakeClone(this));
                }
                _columnAvailable.Clear();
                foreach (var ca in grid._columnAvailable)
                {
                    _columnAvailable.Add(ca);
                }
                SortAvailableColumns();
                LayoutElements();
            }
        }

        public bool OCRed
        {
            get;
            set;
        }

        private bool AdjustForValueUnit(string column, bool deleted)
        {
            //if (AdjustForValueUnit(PACKAGECOUNT, PACKAGETYPE, PACKAGECOUNTANDTYPE, column, deleted))
            //{
            //    return true;
            //}
            //if (AdjustForValueUnit(GROSSWEIGHT, GROSSWEIGHTUM, GROSSWEIGHTANDUM, column, deleted))
            //{
            //    return true;
            //}
            //if (AdjustForValueUnit(NETWEIGHT, NETWEIGHTUM, NETWEIGHTANDUM, column, deleted))
            //{
            //    return true;
            //}
            //if (AdjustForValueUnit(GROSSMEASURE, GROSSMEASUREUM, GROSSMEASUREANDUM, column, deleted))
            //{
            //    return true;
            //}
            //if (AdjustForValueUnit(NETMEASURE, NETMEASUREUM, NETMEASUREANDUM, column, deleted))
            //{
            //    return true;
            //}
            return false;
        }

        private bool AdjustForValueUnit(string valueColumn, string unitColumn, string valueUnitColumn, string column, bool deleted)
        {
            if (!string.IsNullOrWhiteSpace(column))
            {
                if (column.Equals(valueUnitColumn))
                {
                    if (deleted)
                    {
                        _columnAvailable.Remove(valueColumn);
                        _columnAvailable.Remove(unitColumn);
                    }
                    else
                    {
                        _columnAvailable.Add(valueColumn);
                        _columnAvailable.Add(unitColumn);
                        SortAvailableColumns();
                    }
                    return true;
                }
                else if (column.Equals(valueColumn) || column.Equals(unitColumn))
                {
                    if (deleted)
                    {
                        _columnAvailable.Remove(valueUnitColumn);
                    }
                    else
                    {
                        if (_columnAvailable.Contains(valueColumn) && _columnAvailable.Contains(unitColumn) && !_columnAvailable.Contains(valueUnitColumn))
                        {
                            _columnAvailable.Add(valueUnitColumn);
                            SortAvailableColumns();
                        }
                    }
                    return true;
                }
            }
            return false;
        }
    }
}
