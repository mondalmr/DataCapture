﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class OCRPostInfo : NotifyInfo
    {
        public OCRPostInfo()
        {
        }

        public OCRPostInfo(IOCRPostRule rule)
        {
            Rule = rule;
        }

        bool _skipInMenu;
        public bool SkipInMenu
        {
            get
            {
                return _skipInMenu;
            }
            set
            {
                _skipInMenu = value;
                RaisePropertyChanged("SkipInMenu");
            }
        }

        bool _userRule;
        public bool UserRule
        {
            get
            {
                return _userRule;
            }
            set
            {
                _userRule = value;
                RaisePropertyChanged("UserRule");
            }
        }

        bool _isChecked;
        public bool IsChecked
        {
            get
            {
                return _isChecked;
            }
            set
            {
                _isChecked = value;
                RaisePropertyChanged("IsChecked");
            }
        }

        IOCRPostRule _rule;
        public IOCRPostRule Rule
        {
            get
            {
                return _rule;
            }
            set
            {
                _rule = value;
                RaisePropertyChanged("Rule");
                RaisePropertyChanged("Description");
            }
        }

        public string Description
        {
            get
            {
                if (Rule != null)
                {
                    return Rule.Description;
                }
                return "";
            }
        }
    }
}
