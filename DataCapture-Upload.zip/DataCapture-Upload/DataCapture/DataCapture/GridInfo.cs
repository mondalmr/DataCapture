﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataCapture.DTO;

namespace DataCapture
{
    public class GridInfo : UndoRedoModel
    {
        //static MainWindow _Capture;        

        const int STRING = 0;
        const int INT = 1;
        const int DECIMAL = 2;

        public void CopyFrom(GridInfo pi, UndoRedoCollection actions = null)
        {
            if (pi != null)
            {
                var add = false;
                if (actions == null)
                {
                    actions = new UndoRedoCollection();
                    add = true;
                }

                CopyFieldValues(pi, actions);

                if (add)
                {
                    UndoRedoManager.Current.AddUndoAction(actions);
                }
            }
        }

        public GridInfo()
        {
            AddRelatedPropertes(GridInfoFields.CertificateAmt, GridInfoFields.PackageCountError, GridInfoFields.PackageCountHasError);
            AddRelatedPropertes(GridInfoFields.CertificateNo, GridInfoFields.PackageTypeError, GridInfoFields.PackageTypeHasError);

            AddRelatedPropertes(GridInfoFields.PrescribedRate, GridInfoFields.PackageWeightError, GridInfoFields.PackageWeightHasError);
            AddRelatedPropertes(GridInfoFields.Nature, GridInfoFields.PackageWeightUMError, GridInfoFields.PackageWeightUMHasError);
            AddRelatedPropertes(GridInfoFields.IntCol3, GridInfoFields.PackageNetWeightError, GridInfoFields.PackageNetWeightHasError);
            AddRelatedPropertes(GridInfoFields.FromDate, GridInfoFields.PackageNetWeightUMError, GridInfoFields.PackageNetWeightUMHasError);

            AddRelatedPropertes(GridInfoFields.IntCol4, GridInfoFields.PackageMeasureError, GridInfoFields.PackageMeasureHasError);
            AddRelatedPropertes(GridInfoFields.ToDate, GridInfoFields.PackageMeasureUMError, GridInfoFields.PackageMeasureUMHasError);
            //AddRelatedPropertes(GridInfoFields.PackageNetMeasure, GridInfoFields.PackageNetMeasureError, GridInfoFields.PackageNetMeasureHasError);
            //AddRelatedPropertes(GridInfoFields.PackageNetMeasureUM, GridInfoFields.PackageNetMeasureUMError, GridInfoFields.PackageNetMeasureUMHasError);
            
            AddRelatedPropertes(GridInfoFields.SeqNo, GridInfoFields.PackageSeqNoError, GridInfoFields.PackageSeqNoHasError);            

            ClearValues(true);
        }

        public void ClearValues(bool skipUndoRedo = false)
        {
            var actions = new UndoRedoCollection();
            
            SetPropertyValue(GridInfoFields.CertificateAmt, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.IntCol4, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.ToDate, string.Empty, true, actions);
            //SetPropertyValue(GridInfoFields.PackageNetMeasure, string.Empty, true, actions);
            //SetPropertyValue(GridInfoFields.PackageNetMeasureUM, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.IntCol3, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.FromDate, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.CertificateNo, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PrescribedRate, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.Nature, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.SeqNo, string.Empty, true, actions);

            SetPropertyValue(GridInfoFields.PCTPackageCount, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageMeasure, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageMeasureUM, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageNetMeasure, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageNetMeasureUM, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageNetWeight, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageNetWeightUM, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageType, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageWeight, string.Empty, true, actions);
            SetPropertyValue(GridInfoFields.PCTPackageWeightUM, string.Empty, true, actions);

            if (!skipUndoRedo)
            {
                UndoRedoManager.Current.AddUndoAction(actions);
            }
        }

        public bool IsEmpty
        {
            get
            {                
                if (!string.IsNullOrWhiteSpace(CertificateAmt))
                {
                    return false;
                }
                if (!string.IsNullOrWhiteSpace(CertificateNo))
                {
                    return false;
                }
                if (!string.IsNullOrWhiteSpace(PrescribedRate))
                {
                    return false;
                }
                if (!string.IsNullOrWhiteSpace(FromDate))
                {
                    return false;
                }
                //if (!string.IsNullOrWhiteSpace(IntCol3))
                //{
                //    return false;
                //}
                if (!string.IsNullOrWhiteSpace(ToDate))
                {
                    return false;
                }
                //if (!string.IsNullOrWhiteSpace(IntCol4))
                //{
                //    return false;
                //}
                if (!string.IsNullOrWhiteSpace(Nature))
                {
                    return false;
                }
                //if (!string.IsNullOrWhiteSpace(PackageNetMeasure))
                //{
                //    return false;
                //}
                //if (!string.IsNullOrWhiteSpace(PackageNetMeasureUM))
                //{
                //    return false;
                //}
                if (!string.IsNullOrWhiteSpace(SeqNo))
                {
                    return false;
                }
                return true;
            }
        }
             
        public bool HasError
        {
            get
            {
                var hasError = false;
                if (PackageCountHasError)
                {
                    hasError = true;
                }

                if (PackageTypeHasError)
                {
                    hasError = true;
                }

                if (PackageWeightHasError)
                {
                    hasError = true;
                }

                if (PackageWeightUMHasError)
                {
                    hasError = true;
                }

                if (PackageNetWeightHasError)
                {
                    hasError = false;
                }

                if (PackageNetWeightUMHasError)
                {
                    hasError = true;
                }

                if (PackageMeasureHasError)
                {
                    hasError = true;
                }

                if (PackageMeasureUMHasError)
                {
                    hasError = true;
                }

                //if (PackageNetMeasureHasError)
                //{
                //    hasError = true;
                //}

                //if (PackageNetMeasureUMHasError)
                //{
                //    hasError = true;
                //}

                
                return hasError;
            }
        }

        private string GetPropertyError(string value, int maxLength, int dataType, UnitType? unitType = null)
        {
            var err = string.Empty;
            if (!string.IsNullOrWhiteSpace(value))
            {
                switch (dataType)
                {
                    case INT:
                        int intValue = 0;
                        if (Int32.TryParse(value, out intValue))
                        {
                            if (intValue < 0)
                            {
                                err = "Value cannot be less than 0.";
                            }
                        }
                        else
                        {
                            err = "Invalid Number. Please enter a valid Integer Value (no decimal places).";
                        }
                        break;

                    case DECIMAL:
                        decimal decValue = 0;
                        if (Decimal.TryParse(value, out decValue))
                        {
                            if (decValue < 0)
                            {
                                err = "Value cannot be less than 0.";
                            }
                        }
                        else
                        {
                            err = "Invalid Number. Please enter a valid Numeric Value (decimals allowed).";
                        }
                        break;
                }
                if (string.IsNullOrWhiteSpace(err))
                {
                    if (maxLength > 0 && value.Length > maxLength)
                    {
                        err = "Length of value is " + value.Length + ". It cannot be more than " + maxLength + " characters.";
                    }
                }                
            }
            return err;
        }
        
        #region Package Count and Type
        public string CertificateAmt
        {
            get
            {
                return GetPropertyValue(GridInfoFields.CertificateAmt);
            }
            set
            {
                SetPropertyValue(GridInfoFields.CertificateAmt, value.ToSingleLine(), true);
            }
        }

        public bool PackageCountHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageCountError);
            }
        }

        public string PackageCountError
        {
            get
            {
                if (string.IsNullOrWhiteSpace(CertificateAmt))
                {
                    return "Value Required.";
                }
                return GetPropertyError(CertificateAmt, 7, DECIMAL);
            }
        }

        public string CertificateNo
        {
            get
            {
                return GetPropertyValue(GridInfoFields.CertificateNo);
            }
            set
            {
                SetPropertyValue(GridInfoFields.CertificateNo, value.ToSingleLine(), true);
            }
        }
        public bool PackageTypeHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageTypeError);
            }
        }

        public string PackageTypeError
        {
            get
            {
                //if (string.IsNullOrWhiteSpace(CertificateNo))
                //{
                //    return "Value Required.";
                //}
                return GetPropertyError(CertificateNo, 4, STRING, null);
            }
        }
        #endregion

        #region PackageSeqNo
        public string SeqNo
        {
            get
            {
                return GetPropertyValue(GridInfoFields.SeqNo);
            }
            set
            {
                SetPropertyValue(GridInfoFields.SeqNo, value.ToSingleLine(), true);
            }
        }

        public bool PackageSeqNoHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageSeqNoError);
            }
        }

        public string PackageSeqNoError
        {
            get
            {
                if (string.IsNullOrWhiteSpace(SeqNo))
                {
                    return "Value Required.";
                }
                return GetPropertyError(SeqNo, 3, INT);
            }
        }
        #endregion

        #region Package Weight and UM
        public string PrescribedRate
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PrescribedRate);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PrescribedRate, value.ToSingleLine(), true);
            }
        }

        public bool PackageWeightHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageWeightError);
            }
        }

        public string PackageWeightError
        {
            get
            {
                return GetPropertyError(PrescribedRate, 0, DECIMAL);
            }
        }


        public string Nature
        {
            get
            {
                return GetPropertyValue(GridInfoFields.Nature);
            }
            set
            {
                SetPropertyValue(GridInfoFields.Nature, value.ToSingleLine(), true);
            }
        }

        public bool PackageWeightUMHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageWeightUMError);
            }
        }

        public string PackageWeightUMError
        {
            get
            {
                return GetPropertyError(Nature, 2, STRING, null);
            }
        }
        #endregion

        #region Package Measure and UM
        public string IntCol4
        {
            get
            {
                return GetPropertyValue(GridInfoFields.IntCol4);
            }
            set
            {
                SetPropertyValue(GridInfoFields.IntCol4, value.ToSingleLine(), true);
            }
        }

        public bool PackageMeasureHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageMeasureError);
            }
        }

        public string PackageMeasureError
        {
            get
            {
                return GetPropertyError(IntCol4, 0, INT);
            }
        }

        public string ToDate
        {
            get
            {
                return GetPropertyValue(GridInfoFields.ToDate);
            }
            set
            {
                SetPropertyValue(GridInfoFields.ToDate, value.ToSingleLine(), true);
            }
        }

        public bool PackageMeasureUMHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageMeasureUMError);
            }
        }

        public string PackageMeasureUMError
        {
            get
            {
                return GetPropertyError(ToDate, 2, STRING, null);
            }
        }
        #endregion

        #region Package Net Weight and UM
        public string IntCol3
        {
            get
            {
                return GetPropertyValue(GridInfoFields.IntCol3);
            }
            set
            {
                SetPropertyValue(GridInfoFields.IntCol3, value.ToSingleLine(), true);
            }
        }

        public bool PackageNetWeightHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageNetWeightError);
            }
        }

        public string PackageNetWeightError
        {
            get
            {
                return GetPropertyError(IntCol3, 0, DECIMAL);
            }
        }

        public string FromDate
        {
            get
            {
                return GetPropertyValue(GridInfoFields.FromDate);
            }
            set
            {
                SetPropertyValue(GridInfoFields.FromDate, value.ToSingleLine(), true);
            }
        }

        public bool PackageNetWeightUMHasError
        {
            get
            {
                return !string.IsNullOrWhiteSpace(PackageNetWeightUMError);
            }
        }

        public string PackageNetWeightUMError
        {
            get
            {
                return GetPropertyError(FromDate, 2, STRING, null);
            }
        }
        #endregion     
        

        public string PCTPackageCount
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageCount);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageCount, value, true);
            }
        }

        public string PCTPackageType
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageType);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageType, value, true);
            }
        }

        public string PCTPackageWeight
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageWeight);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageWeight, value, true);
            }
        }

        public string PCTPackageWeightUM
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageWeightUM);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageWeightUM, value, true);
            }
        }

        public string PCTPackageMeasure
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageMeasure);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageMeasure, value, true);
            }
        }

        public string PCTPackageMeasureUM
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageMeasureUM);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageMeasureUM, value, true);
            }
        }

        public string PCTPackageNetWeight
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageNetWeight);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageNetWeight, value, true);
            }
        }

        public string PCTPackageNetWeightUM
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageNetWeightUM);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageNetWeightUM, value, true);
            }
        }

        public string PCTPackageNetMeasure
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageNetMeasure);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageNetMeasure, value, true);
            }
        }

        public string PCTPackageNetMeasureUM
        {
            get
            {
                return GetPropertyValue(GridInfoFields.PCTPackageNetMeasureUM);
            }
            set
            {
                SetPropertyValue(GridInfoFields.PCTPackageNetMeasureUM, value, true);
            }
        }

        //public string PCTPackageEqpNo
        //{
        //    get
        //    {
        //        return GetPropertyValue(PackageInfoFields.PCTPackageEqpNo);
        //    }
        //    set
        //    {
        //        SetPropertyValue(PackageInfoFields.PCTPackageEqpNo, value, true);
        //    }
        //}
    }
}
