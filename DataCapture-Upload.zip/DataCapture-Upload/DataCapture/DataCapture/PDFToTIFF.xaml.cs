﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for PDFToTIFF.xaml
    /// </summary>
    public partial class PDFToTIFF : Window
    {
        public PDFToTIFF()
        {
            InitializeComponent();
        }

        private void FileOpen_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Multiselect = false;
            dlg.Filter = "Adobe Acrobat PDF (*.pdf)|*.pdf";
            if (dlg.ShowDialog(this) == true)
            {
                PDFPath.Text = dlg.FileName;
            }

        }

        private void FileSave_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog();
            dlg.OverwritePrompt = true;
            dlg.Filter = "TIFF Image (*.tif)|*.tif";
            if (!string.IsNullOrWhiteSpace(TIFFPath.Text))
            {
                dlg.FileName = TIFFPath.Text;
            }
            else if (!string.IsNullOrWhiteSpace(PDFPath.Text))
            {
                dlg.FileName = System.IO.Path.GetFileNameWithoutExtension(PDFPath.Text) + ".tif";
            }
            if (dlg.ShowDialog(this) == true)
            {
                
                TIFFPath.Text = dlg.FileName;
            }
        }

        private void BExport_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Validate()))
            {
                TBMessage.Text = "Exporting, please wait....";
            }
        }

        private void BExport_Click(object sender, RoutedEventArgs e)
        {
            var msg = Validate();
            if (!string.IsNullOrWhiteSpace(msg))
            {
                MessageBox.Show(msg);
                return;
            }
            var pdf = new PDFSIReader(null);
            pdf.ExportToTIFF(PDFPath.Text, TIFFPath.Text);
            DialogResult = true;
            Close();
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private string Validate()
        {
            if (string.IsNullOrWhiteSpace(PDFPath.Text))
            {
                return "Please specify source PDF Path.";
            }
            if (string.IsNullOrWhiteSpace(TIFFPath.Text))
            {
                return "Please specify target TIFF Path.";
            }
            return null;
        }
    }
}
