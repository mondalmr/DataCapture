﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for Automate.xaml
    /// </summary>
    public partial class Automate : Window
    {
        MainWindow _mainWindow;
        DataCaptureInfo dc;

        public Automate(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            dc = new DataCaptureInfo();
            this.DataContext = dc;
        }

        private void btnSelectSourceFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Multiselect = false;

            dlg.Filter = "Adobe Acrobat PDF | *.pdf| Microsoft Excel | *.xlsx; *.xls| Microsoft Word | *.docx; *.doc; *.rtf";

            if (dlg.ShowDialog() == true)
            {
                tbSourceFile.Text = dlg.FileName;                
            }
        }

        private void btnSelectSourceTemplate_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.Multiselect = false;

            dlg.Filter = "Template (*.dct)|*.dct";

            if (dlg.ShowDialog() == true)
            {
                tbSourceTemplate.Text = dlg.FileName;                
            }
        }

        private void btnProcess_Click(object sender, RoutedEventArgs e)
        {            
            var fileName = tbSourceFile.Text;
            var _reader = _mainWindow.GetSIReader(fileName);
            var DCELMENTS = new DataCaptureElement[]{
                new DataCaptureElement(DataCaptureElementType.ChallanNo, "Challan No",  Colors.LightGray, null),
                new DataCaptureElement(DataCaptureElementType.SectionCode, "Section Code", Colors.Gray, null),
                new DataCaptureElement(DataCaptureElementType.TAN, "TAN", Colors.Orange, null),
                new DataCaptureElement(DataCaptureElementType.AssessmentYear, "AssessmentYear", Colors.AliceBlue, null),
                new DataCaptureElement(DataCaptureElementType.TDS, "TDS", Colors.Blue, null),
                new DataCaptureElement(DataCaptureElementType.Surcharge, "Surcharge", Colors.Tomato, null),
                new DataCaptureElement(DataCaptureElementType.EducationCess, "EducationCess", Colors.Cyan, null),
                new DataCaptureElement(DataCaptureElementType.Interest, "Interest", Colors.DarkGoldenrod, null),
                new DataCaptureElement(DataCaptureElementType.Fee, "Fee", Colors.DarkGreen, null),
                new DataCaptureElement(DataCaptureElementType.Others, "Others", Colors.DarkKhaki, null),
                new DataCaptureElement(DataCaptureElementType.TotalTax, "TotalTax", Colors.DarkRed, null),
                new DataCaptureElement(DataCaptureElementType.BranchCode, "BranchCode", Colors.DarkViolet, null),
                new DataCaptureElement(DataCaptureElementType.BankName, "BankName", Colors.Gainsboro, null),
                new DataCaptureElement(DataCaptureElementType.DepositDate, "DepositDate", Colors.HotPink, null),
                new DataCaptureElement(DataCaptureElementType.MinorHead, "MinorHead", Colors.LavenderBlush, null),
                new DataCaptureElement(DataCaptureElementType.Remarks, "Remarks", Colors.LightSalmon, null),


                new DataCaptureElement(DataCaptureElementType.MultilineElement1, "MultilineElement1", Colors.Red, null),
                new DataCaptureElement(DataCaptureElementType.TextAreaElement1, "TextAreaElement1", Colors.Navy, null),
                new DataCaptureElement(DataCaptureElementType.CertificateAmt, "IntCol1", Colors.DarkCyan, null),
                new DataCaptureElement(DataCaptureElementType.CertificateNo, "CertificateNo", Colors.DarkSlateGray, null),
                new DataCaptureElement(DataCaptureElementType.PrescribedRate, "PrescribedRate", Colors.Blue, null),
                new DataCaptureElement(DataCaptureElementType.Nature, "Nature", Colors.Fuchsia, null),
                //new DataCaptureElement(DataCaptureElementType.IntCol3, "IntCol3", Colors.LightCoral, null),
                new DataCaptureElement(DataCaptureElementType.FromDate, "FromDate", Colors.RosyBrown, null),
                new DataCaptureElement(DataCaptureElementType.ToDate, "ToDate", Colors.CornflowerBlue, null),
                //new DataCaptureElement(DataCaptureElementType.StringCol4, "StringCol4", Colors.Plum, null),
                new DataCaptureElement(DataCaptureElementType.PackageGrid, "Package Grid", Colors.YellowGreen, null)
            };
            var template = XmlUtils.LoadFile<DCTemplate>(tbSourceTemplate.Text);
            dc = new DataCaptureInfo();
            XmlUtils.ReadFromTemplate(_mainWindow, template, DCELMENTS, dc, true);
            DataTable packages = new DataTable();

            if (_reader == null)
            {
                MessageBox.Show("Sorry! The Input file type is not supported.");
                return;
            }            

            int pages = 0;
            _reader.FilePath = fileName;
            if (!string.IsNullOrWhiteSpace(_reader.ErrorMessage))            
                MessageBox.Show(_reader.ErrorMessage);            
            else            
                pages = _reader.PageCount;
            

            for (int i = 1; i <= pages; i++)
            {
                _reader.RenderPage(i, null, _mainWindow, "0", 0,true);                
                var templateInThisPage = template.TemplateElements.Where(x => x.PageNo == i);

                foreach (var element in DCELMENTS)
                {
                    var currentTemplate = templateInThisPage.FirstOrDefault(m => m.ElementType == element.DCElementType);
                    if (currentTemplate != null && currentTemplate.Height > 0 && currentTemplate.Width > 0 && currentTemplate.ElementType.ToString() != "PackageGrid")
                    {
                        var highlightRegion = new HighlightRegion(currentTemplate.Left, currentTemplate.Top, currentTemplate.Width, currentTemplate.Height);
                        var text = _mainWindow.TextWithinZone(highlightRegion, null, true);

                        if(!string.IsNullOrEmpty(text))
                        {
                            if(currentTemplate.ElementType == DataCaptureElementType.MultilineElement1)
                            {
                                //var value = text.Replace("\r\n", "^");
                                //var lines = text.Split('^');

                                dc.MultilineElement1.Apply(text,100,null);
                            }                            
                            dc.SetPropertyValue(currentTemplate.ElementType.ToString(), text, false);
                        }
                    }
                    else if(currentTemplate != null && currentTemplate.Height > 0 && currentTemplate.Width > 0 && currentTemplate.ElementType.ToString() == "PackageGrid")
                    {
                        FrameworkElement rect = new FrameworkElement();
                        rect = element.GetRectangle(i);
                        var packageGrid = rect as Grid;

                        if (packageGrid != null)
                        {                            
                            List<GridColumnContent> columnList = new List<GridColumnContent>();
                            var regions = packageGrid.GetGridRects(columnList);
                            if (regions != null && regions.Length > 0)
                            {
                                int rc = regions.GetLength(0);
                                int cc = regions.GetLength(1);
                                string[,] texts = new string[rc, cc];
                                double[,] pcts = new double[rc, cc];
                                for (int r = 0; r < rc; r++)
                                {
                                    for (int c = 0; c < cc; c++)
                                    {                                        
                                        texts[r, c] = _mainWindow.TextWithinZone(regions[r, c], null, true);                                        
                                    }
                                }
                                var popup = new PackageViewer();
                                popup.Owner = this;
                                popup.SetData(texts, pcts, columnList);
                                popup.ParseTable();                                

                                foreach (DataRow row in popup.mParsedTable.Rows)
                                {
                                    if (row != null)
                                    {                                        
                                        var pkg = dc.NewPackage();
                                        foreach (DataColumn column in popup.mParsedTable.Columns)
                                        {
                                            if (column != null && !string.IsNullOrWhiteSpace(column.ColumnName) && !column.ColumnName.StartsWith("PCT_") && row[column] != null && row[column] != DBNull.Value)
                                            {
                                                var text = row[column].ToString();
                                                var pct = "";
                                                if (row["PCT_" + column.ColumnName] is double)                                                
                                                    pct = "" + (double)row["PCT_" + column.ColumnName] + "";                                                

                                                if (!string.IsNullOrWhiteSpace(text))
                                                {
                                                    switch (column.ColumnName)
                                                    {
                                                        case Grid.CertificateAmt:
                                                            pkg.SetPropertyValue(GridInfoFields.CertificateAmt, text, false);                                                            
                                                            break;
                                                        case Grid.CertificateNo:
                                                            pkg.SetPropertyValue(GridInfoFields.CertificateNo, text, false);                                                            
                                                            break;
                                                        case Grid.PrescribedRate:
                                                            pkg.SetPropertyValue(GridInfoFields.PrescribedRate, text, false);                                                            
                                                            break;
                                                        case Grid.Nature:
                                                            pkg.SetPropertyValue(GridInfoFields.Nature, text, false);                                                            
                                                            break;
                                                        case Grid.INTCOL3:
                                                            pkg.SetPropertyValue(GridInfoFields.IntCol3, text, false);                                                            
                                                            break;
                                                        case Grid.FromDate:
                                                            pkg.SetPropertyValue(GridInfoFields.FromDate, text, false);                                                            
                                                            break;
                                                        case Grid.INTCOL4:
                                                            pkg.SetPropertyValue(GridInfoFields.IntCol4, text, false);                                                            
                                                            break;
                                                        case Grid.ToDate:
                                                            pkg.SetPropertyValue(GridInfoFields.ToDate, text, false);                                                            
                                                            break;                                                            
                                                    }
                                                }
                                            }
                                        }

                                        dc.PackageList.Add(pkg);
                                    }
                                }

                                packages = popup.mParsedTable;
                            }
                        }
                    }
                }
            }
            
            automatePackage.ItemsSource = packages.DefaultView;

            tbChallanNo.Text = dc.ChallanNo;
            tbSectionCode.Text = dc.SectionCode;
            tbAssessmentYear.Text = dc.AssessmentYear;
            tbTAN.Text = dc.TAN;
            tbTDS.Text = dc.TDS;
            tbSurcharge.Text = dc.Surcharge;
            tbEducationCess.Text = dc.EducationCess;
            tbInterest.Text = dc.Interest;
            tbFee.Text = dc.Fee;
            tbOthers.Text = dc.Others;
            tbTotalTax.Text = dc.TotalTax;
            tbBranchCode.Text = dc.BranchCode;
            tbBankName.Text = dc.BankName;
            tbDepositDate.Text = dc.DepositDate;
            tbMinorHead.Text = dc.MinorHead;
            tbRemarks.Text = dc.Remarks;

            tbarea.Text = dc.TextAreaElement1;
            tbMultiline.Text = "";// $"{dc.MultilineElement1.Line1}{Environment.NewLine}{dc.MultilineElement1.Line2}{Environment.NewLine}{dc.MultilineElement1.Line3}{Environment.NewLine}{dc.MultilineElement1.Line4}{Environment.NewLine}{dc.MultilineElement1.Line5}{Environment.NewLine}{dc.MultilineElement1.Line6}";
        }

        private void automatePackage_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            var dgColumn = e.Column;
            if (dgColumn != null)
            {
                var name = e.PropertyName;
                if (!string.IsNullOrEmpty(name))
                {
                    if (name.StartsWith("PCT_"))
                    {                        
                        dgColumn.Visibility = Visibility.Hidden;
                    }
                }
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var fileName = tbSourceFile.Text;
            //(new DbUtility()).SaveInDatabase(dc, fileName);
        }
    }
}
