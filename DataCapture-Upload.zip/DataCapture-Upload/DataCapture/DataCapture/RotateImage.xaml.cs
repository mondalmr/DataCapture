﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for RotateImage.xaml
    /// </summary>
    public partial class RotateImage : Window
    {
        float ImageRotation = 0;
        double ImageScaleWidth;
        double ImageScaleHeight;
        System.Drawing.Bitmap BitmapImage;

        public RotateImage()
        {
            InitializeComponent();
        }

        public float Rotation
        {
            get
            {
                return ImageRotation;
            }
            set
            {
                ImageRotation = value;
                UpdateDegreesInTB();
            }
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            DragMove();
        }

        private void UpdateDegreesInTB()
        {
            TDegrees.Text = "" + string.Format("{0:f2}", Math.Round(ImageRotation, 2));
        }

        private void RotateMainImage(float diff)
        {
            if (MainWindow != null)
            {
                ImageRotation += diff;
                UpdateDegreesInTB();
                if (BitmapImage != null)
                {
                    var rotatedImage = ImageUtils.RotateImageSansClipping(BitmapImage, (float)ImageRotation);
                    SetImage(rotatedImage);
                }
                else
                {
                    MainWindow.RotateMainImage(ImageRotation);
                }
            }
        }

        private void BRotateLeft_Click(object sender, RoutedEventArgs e)
        {
            RotateMainImage(-0.1f);
        }

        private void BRotateRight_Click(object sender, RoutedEventArgs e)
        {
            RotateMainImage(0.1f);
        }

        private void BDone_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void BRevert_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        public MainWindow MainWindow
        {
            get
            {
                return Owner as MainWindow;
            }
        }

        public void SetImage4Rotation(System.Drawing.Bitmap image, double scaleWidth, double scaleHeight)
        {
            AllowsTransparency = false;
            Background = Brushes.White;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            WindowStyle = WindowStyle.ThreeDBorderWindow;
            BitmapImage = image;
            ImageScaleWidth = scaleWidth;
            ImageScaleHeight = scaleHeight;
            SetImage(BitmapImage);
        }

        private void SetImage(System.Drawing.Bitmap bitmap)
        {
            var image = bitmap;
            bool dispose = false;
            if (ImageScaleWidth > 0 && ImageScaleHeight > 0)
            {
                dispose = true;
                image = ImageUtils.ResizeImage(image, ImageScaleWidth, ImageScaleHeight, true);
            }
            var imageWPF = image.ToWPFImageSource();
            if (dispose)
            {
                image.Dispose();
                GC.Collect();
            }
            Image imageBox = ImageBox;
            var bmpImage = imageBox.Source as BitmapImage;
            if (bmpImage != null && bmpImage.StreamSource != null)
            {
                bmpImage.StreamSource.Close();
            }
            
            imageBox.Source = imageWPF;
            imageBox.Width = imageWPF.Width;
            imageBox.Height = imageWPF.Height;
            imageBox.Stretch = Stretch.Fill;

            if (imageWPF.Width > (Width - 5))
            {
                Width = Math.Min(imageWPF.Width + 5, 1000);
            }

            if (imageWPF.Height > (Height - 30))
            {
                Height = Math.Min(imageWPF.Height + 30, 800);
            }
        }
    }
}
