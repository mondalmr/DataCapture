﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for PackageGridColumnEditor.xaml
    /// </summary>
    public partial class GridColumnEditor : Window
    {
        public GridColumnEditor()
        {
            _removeOnExit = false;
            InitializeComponent();
        }

        bool _removeOnExit;

        internal bool RemoveOnExit
        {
            get
            {
                return _removeOnExit;
            }
        }

        private ListBox FindParentListBox(ListBoxItem listBoxItem)
        {
            ListBox listBoxSource = null;
            DependencyObject dep = listBoxItem;
            while (dep != null)
            {
                dep = VisualTreeHelper.GetParent(dep);
                if (dep is ListBox)
                {
                    listBoxSource = (ListBox)dep;
                    break;
                }
            }
            return listBoxSource;
        }

        public void SetupListBox(params GridColumnContent[] contents)
        {
            if (LColumnList != null && contents != null && contents.Length > 0)
            {
                for (int i=0;i<contents.Length;i++)
                {
                    var lbi = new ListBoxItem();
                    lbi.Content = "Column " + (i + 1);
                    lbi.Tag = contents[i];
                    LColumnList.Items.Add(lbi);
                }
                TColumnList.Visibility = Visibility.Visible;
                LColumnList.Visibility = Visibility.Visible;
                BRemoveContentInfo.Visibility = Visibility.Collapsed;
                LColumnList.SelectedIndex = 0;
            }
        }

        private void DropListBoxItem(ListBox listBoxTarget, ListBoxItem listBoxItem)
        {
            var packageTracker = DataContext as GridColumnContent;
            if (packageTracker != null)
            {
                if (listBoxTarget != null && listBoxItem != null)
                {
                    if (listBoxTarget == AvailableElements)
                    {
                        var idx = -1;
                        if (ColumnElements.ItemContainerGenerator != null)
                        {
                            idx = ColumnElements.ItemContainerGenerator.IndexFromContainer(listBoxItem);
                        }
                        packageTracker.RemoveColumnElement(idx);
                    }
                    else if (listBoxTarget == ColumnElements)
                    {
                        ListBox listBoxSource = FindParentListBox(listBoxItem);
                        if (listBoxSource == ColumnElements)
                        {

                        }
                        else
                        {
                            packageTracker.AddColumnElement(listBoxItem.Content as string);
                        }
                    }
                }
            }
        }

        private void ListBox_Drop(object sender, DragEventArgs e)
        {
            var listBoxTarget = sender as ListBox;
            var listBoxItem = e.Data.GetData(typeof(ListBoxItem)) as ListBoxItem;
            DropListBoxItem(listBoxTarget, listBoxItem);
        }

        private void ListBoxItem_Drop(object sender, DragEventArgs e)
        {
            if (ColumnElements.ItemContainerGenerator != null && e != null && e.Data != null && e.Data.GetDataPresent(typeof(ListBoxItem)))
            {
                var packageTracker = DataContext as GridColumnContent;
                if (packageTracker != null)
                {
                    var listBoxItemTarget = sender as ListBoxItem;
                    var listBoxItemSource = e.Data.GetData(typeof(ListBoxItem)) as ListBoxItem;
                    if (listBoxItemTarget != null && listBoxItemSource != null)
                    {
                        var fromIdx = ColumnElements.ItemContainerGenerator.IndexFromContainer(listBoxItemSource);
                        var toIdx = ColumnElements.ItemContainerGenerator.IndexFromContainer(listBoxItemTarget);
                        packageTracker.MoveColumnElement(fromIdx, toIdx);
                    }
                }
            }
        }

        private void ListBoxItem_PreviewMouseLeftButtonDownEvent(object sender, MouseButtonEventArgs e)
        {
            if (sender is ListBoxItem && e.ClickCount == 1)
            {
                ListBoxItem listBoxItem = sender as ListBoxItem;
                DragDrop.DoDragDrop(listBoxItem, listBoxItem, DragDropEffects.Move);
                listBoxItem.IsSelected = true;
            }
        }

        private void RemoveContentInfo_Click(object sender, RoutedEventArgs e)
        {
            _removeOnExit = true;
            Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void TBNumberOnly_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            int value = -1;

            if (Int32.TryParse(tb.Text, out value) == false)
            {
                TextChange tc = e.Changes.ElementAt<TextChange>(0);
                tb.Text = tb.Text.Remove(tc.Offset, tc.AddedLength);
            }
        }

        private void ListBoxItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ListBoxItem listBoxItem = sender as ListBoxItem;
            if (listBoxItem != null)
            {
                var listBox =  FindParentListBox(listBoxItem);
                ListBox listBoxTarget = null;
                if (listBox == AvailableElements)
                {
                    listBoxTarget = ColumnElements;
                }
                else if (listBox == ColumnElements)
                {
                    listBoxTarget = AvailableElements;
                }
                if (listBoxTarget != null)
                {
                    DropListBoxItem(listBoxTarget, listBoxItem);
                }
            }
        }

        private void LColumnList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var lb = sender as ListBox;
            if (lb != null)
            {
                var lbi = lb.SelectedItem as ListBoxItem;
                if (lbi != null)
                {
                    var pgcc = lbi.Tag as GridColumnContent;
                    DataContext = pgcc;
                }
            }
        }
    }
}
