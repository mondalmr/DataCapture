﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public interface IUndoRedo
    {
        bool HasUndoRedoInfo
        {
            get;
        }

        void Undo();

        void Redo();

    }
}
