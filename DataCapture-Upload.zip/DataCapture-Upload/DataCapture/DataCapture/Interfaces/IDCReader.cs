﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace DataCapture
{
    public interface IDCReader
    {
        string Description
        {
            get;
        }

        string[] SupportedExtensions
        {
            get;
        }

        string FilePath
        {
            get;
            set;
        }

        int PageCount
        {
            get;
        }

        string ErrorMessage
        {
            get;
        }

        void RenderPage(int pageNo, Canvas canvas, MainWindow window, string unskewImages, int imageColor, bool automate = false);
    }
}
