﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class MultilineInfo : UndoRedoModel
    {
        public void CopyFrom(MultilineInfo multilineInfo, UndoRedoCollection actions = null)
        {
            if (multilineInfo != null)
            {
                var add = false;
                if (actions == null)
                {
                    actions = new UndoRedoCollection();
                    add = true;
                }
                CopyFieldValues(multilineInfo, actions);
                if (add)
                {
                    UndoRedoManager.Current.AddUndoAction(actions);
                }
            }
        }

        public MultilineInfo()
            : base()
        {
            ClearValues(true);
        }

        public void ClearValues(bool skipUndoRedo = false)
        {
            var actions = new UndoRedoCollection();
            Clear(actions);
            if (!skipUndoRedo)
            {
                UndoRedoManager.Current.AddUndoAction(actions);
            }
        }


        public void Clear(UndoRedoCollection actions)
        {
            var add = false;
            if (actions == null)
            {
                actions = new UndoRedoCollection();
            }
            
            //SetPropertyValue(AddressInfoFields.PCT, "", true, actions);
            SetPropertyValue(MultiInfoFields.Line1, "", true, actions);
            SetPropertyValue(MultiInfoFields.Line2, "", true, actions);
            SetPropertyValue(MultiInfoFields.Line3, "", true, actions);
            SetPropertyValue(MultiInfoFields.Line4, "", true, actions);
            SetPropertyValue(MultiInfoFields.Line5, "", true, actions);
            SetPropertyValue(MultiInfoFields.Line6, "", true, actions);
            
            if (add)
            {
                UndoRedoManager.Current.AddUndoAction(actions);
            }
        }

        //public string PCT
        //{
        //    get
        //    {
        //        return GetPropertyValue(MultiInfoFields.PCT);
        //    }
        //    set
        //    {
        //        SetPropertyValue(MultiInfoFields.PCT, value, true);
        //    }
        //}

        public string Line1
        {
            get
            {
                return GetPropertyValue(MultiInfoFields.Line1);
            }
            set
            {
                SetPropertyValue(MultiInfoFields.Line1, value.ToSingleLine(), true);
            }
        }   

        public string Line2
        {
            get
            {
                return GetPropertyValue(MultiInfoFields.Line2);
            }
            set
            {
                SetPropertyValue(MultiInfoFields.Line2, value.ToSingleLine(), true);
            }
        }
        

        public string Line3
        {
            get
            {
                return GetPropertyValue(MultiInfoFields.Line3);
            }
            set
            {
                SetPropertyValue(MultiInfoFields.Line3, value.ToSingleLine(), true);
            }
        }

        public string Line4
        {
            get
            {
                return GetPropertyValue(MultiInfoFields.Line4);
            }
            set
            {
                SetPropertyValue(MultiInfoFields.Line4, value.ToSingleLine(), true);
            }
        }

        public string Line5
        {
            get
            {
                return GetPropertyValue(MultiInfoFields.Line5);
            }
            set
            {
                SetPropertyValue(MultiInfoFields.Line5, value.ToSingleLine(), true);
            }
        }
        
        public string Line6
        {
            get
            {
                return GetPropertyValue(MultiInfoFields.Line6);
            }
            set
            {
                SetPropertyValue(MultiInfoFields.Line6, value.ToSingleLine(), true);
            }
        }

        public string Value
        {
            get
            {
                string nl = Environment.NewLine;
                string value = "".PrefixValue(Line6)
                                .PrefixValue(Line5)
                                .PrefixValue(Line4)
                                .PrefixValue(Line3)
                                .PrefixValue(Line2)
                                .PrefixValue(Line1);
                return value;
            }
        }

        public string Apply(string value, double accuracy, UndoRedoCollection actions)
        {
            string pct = " " + accuracy + "% ";
            string message = "";
            if (!string.IsNullOrEmpty(value))
            {
                //SetPropertyValue(MultiInfoFields.PCT, pct, true, actions);
                var moreLines = false;
                int idx = 0;
                int len = 49;
                int templength = 0;
                var siCapture = App.Current.MainWindow as MainWindow;
                if (siCapture != null)
                {
                    len = 0;
                }
                string overflow = "";
                string[] data = value.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).ToArray();

                templength = len;

                for (int i = 0; i < data.Length; i++)
                {
                    if (idx == 0) len = 175;
                    else len = templength;

                    if (!string.IsNullOrWhiteSpace(overflow))
                    {
                        data[i] = overflow + " " + data[i];
                        overflow = "";
                    }
                    if (!string.IsNullOrWhiteSpace(data[i]))
                    {
                        data[i] = data[i].TrimEnd();
                        if (len > 0 && data[i].Length > len)
                        {
                            if (message.Length > 0)
                            {
                                message = message + ", ";
                            }
                            message = message + (i + 1);
                            if (len > 0)
                            {
                                overflow = data[i].Substring(len);
                                data[i] = data[i].Substring(0, len);
                            }
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(data[i]))
                    {
                        if (idx == 0)
                        {
                            SetPropertyValue(MultiInfoFields.Line1, data[i], true, actions);                            
                        }
                        else if (idx == 1)
                        {
                            SetPropertyValue(MultiInfoFields.Line2, data[i], true, actions);
                        }
                        else if (idx == 2)
                        {
                            SetPropertyValue(MultiInfoFields.Line3, data[i], true, actions);
                        }
                        else if (idx == 3)
                        {
                            SetPropertyValue(MultiInfoFields.Line4, data[i], true, actions);
                        }
                        else if (idx == 4)
                        {
                            SetPropertyValue(MultiInfoFields.Line5, data[i], true, actions);
                        }
                        else if (idx == 5)
                        {
                            if (accuracy > 0) SetPropertyValue(MultiInfoFields.Line6, data[i].Replace("¶", ""), true, actions);
                        }

                        idx++;
                        if (idx > 5)
                        {                            
                            if (!string.IsNullOrWhiteSpace(overflow) || data.Length > (idx))
                            {
                                moreLines = true;
                                break;
                            }
                        }
                    }
                }                
                if (moreLines)
                {
                    message = message + " Details can have only  upto 6 lines. Additional lines are discarded.";
                }
                message = message.Trim();
            }
            return message;
        }
    }
}
