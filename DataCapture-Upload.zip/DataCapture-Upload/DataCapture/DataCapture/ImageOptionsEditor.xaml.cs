﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for ImageOptionsEditor.xaml
    /// </summary>
    public partial class ImageOptionsEditor : Window
    {
        public ImageOptionsEditor()
        {
            InitializeComponent();
        }

        private void TBDoubleOnly_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null)
            {
                double value = -1;

                if (Double.TryParse(tb.Text, out value) == false)
                {
                    TextChange tc = e.Changes.ElementAt<TextChange>(0);
                    tb.Text = tb.Text.Remove(tc.Offset, tc.AddedLength);
                }
            }
        }

        private void TBIntOnly_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null)
            {
                int value = -1;

                if (Int32.TryParse(tb.Text, out value) == false)
                {
                    TextChange tc = e.Changes.ElementAt<TextChange>(0);
                    tb.Text = tb.Text.Remove(tc.Offset, tc.AddedLength);
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender == BCancel)
            {
                DialogResult = false;
                Close();
                return;
            }
            var capture = Owner as MainWindow;
            if (capture != null && DataContext is ImageOptions)
            {
                capture.ImageOptions = (ImageOptions)DataContext;
                capture.RenderCurrentPage();
            }
            TBMessage.Text = "";
            if (sender == BApplyClose)
            {
                DialogResult = true;
                Close();
            }
        }

        private void Button_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
                TBMessage.Text = "Applying, please wait ...";
        }

    }
}
