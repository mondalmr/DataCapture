﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for AdjustBoxes.xaml
    /// </summary>
    public partial class AdjustBoxes : Window
    {
        public AdjustBoxes()
        {
            InitializeComponent();
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            DragMove();
        }

        private void BDone_Click(object sender, RoutedEventArgs e)
        {
            if (SICapture != null)
            {
                SICapture.AdjustElementsOver();
            }
            Close();
        }

        public MainWindow SICapture
        {
            get;
            set;
        }

        private void BMove_Click(object sender, RoutedEventArgs e)
        {
            AdjustXY(sender);
        }

        private void AdjustXY(object sender)
        {
            if (SICapture != null)
            {
                double jump = 1;
                double x = 0;
                double y = 0;
                if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
                {
                    jump = 10;
                }
                if (sender == BLeft)
                {
                    x = (double)jump * -1;
                    if ((MinLeft + x) > 0)
                    {
                        MinLeft += x;
                        MaxRight += x;
                    }
                    else
                    {
                        x = 0;
                    }
                }
                if (sender == BRight)
                {
                    x = jump;
                    if ((MaxRight + x) < CanvasWidth)
                    {
                        MinLeft += x;
                        MaxRight += x;
                    }
                    else
                    {
                        x = 0;
                    }
                }
                if (sender == BUp)
                {
                    y = (double)jump * -1;
                    if ((MinTop + y) > 0)
                    {
                        MinTop += y;
                        MaxBottom += y;
                    }
                    else
                    {
                        y = 0;
                    }
                }
                if (sender == BDown)
                {
                    y = jump;
                    if ((MaxBottom + y) < CanvasHeight)
                    {
                        MinTop += y;
                        MaxBottom += y;
                    }
                    else
                    {
                        y = 0;
                    }
                }
                if (x != 0 || y != 0)
                {
                    SICapture.AdjustElementsXY(x, y);
                }
            }
        }

        public double MinLeft
        {
            get;
            set;
        }

        public double MinTop
        {
            get;
            set;
        }

        public double MaxRight
        {
            get;
            set;
        }

        public double MaxBottom
        {
            get;
            set;
        }

        public double CanvasHeight
        {
            get;
            set;
        }

        public double CanvasWidth
        {
            get;
            set;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            object button = null;
            switch (e.Key)
            {
                case Key.Left:
                    button = BLeft;
                    break;

                case Key.Right:
                    button = BRight;
                    break;

                case Key.Up:
                    button = BUp;
                    break;

                case Key.Down:
                    button = BDown;
                    break;
            }
            if (button != null)
            {
                AdjustXY(button);
            }
        }
    }
}
