﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using DataCapture.DTO;

namespace DataCapture
{
    public static class CommonExtensions
    {
        public static bool Between(this double value, double from, double to, bool inclusive = true)
        {
            if (inclusive)
            {
                return value >= from && value <= to;
            }
            else
            {
                return value > from && value < to;
            }
        }

        public static HighlightRegion ToHighlightRegion(this Rect rect)
        {
            if (rect == null)
            {
                return new HighlightRegion();
            }
            return new HighlightRegion(rect);
        }

        public static bool PropertyExists(this object target, string propertyname)
        {
            MemberInfo[] mi = target.GetType().GetMember(propertyname);
            if (mi != null && mi.Length > 0)
            {
                return (mi.Where(i => i.MemberType == MemberTypes.Property).Count() > 0);
            }
            return false;
        }

        public static SortedDictionary<XYCo, PDFTextRect> TextRectsWithinZone(this IEnumerable<PDFTextRect> allTexts, double left, double top, double width, double height, double insetWidth, double insetHeight, bool allowPartial)
        {
            if (allTexts != null)
            {
                var texts = new SortedDictionary<XYCo, PDFTextRect>();
                foreach (var text in allTexts)
                {
                    var within = false;
                    var xy = new Point(text.Left, text.Top);
                    var xy2 = new Point(text.Right, text.Bottom);
                    if (!double.IsNaN(xy.X) && !double.IsNaN(xy.Y))
                    {
                        within = IsWithin(xy, xy2, left, top, width, height, allowPartial);
                        if (within && insetWidth > 0 && insetHeight > 0)
                        {
                            var insetLeft = left + width - insetWidth;
                            var insetPartial = !allowPartial; // reversing allowpartial for inset checking
                            var withinInset = IsWithin(xy, xy2, insetLeft, top, insetWidth, insetHeight, insetPartial);
                            if (withinInset)
                            {
                                within = false;
                            }
                        }
                        if (within)
                        {
                            try
                            {
                                texts.Add(new XYCo() { X = xy.X, Y = xy.Y }, text);
                            }
                            catch (Exception e)
                            {
                            }
                        }
                    }
                }
                return texts;
            }
            return null;
        }

        public static SortedDictionary<XYCo, T> ElementsWithinZone<T>(this Canvas canvas, double left, double top, double width, double height, double insetWidth, double insetHeight, bool allowPartial, List<T> elements = null) where T : FrameworkElement
        {
            SortedDictionary<XYCo, T> tbs = new SortedDictionary<XYCo, T>();
            if (canvas != null)
            {
                if (elements == null)
                {
                    elements = new List<T>();
                }
                foreach (FrameworkElement element in canvas.Children)
                {
                    if (element is T)
                    {
                        var within = false;
                        var xy = element.GetXY();
                        var xy2 = new Point(xy.X + element.ActualWidth, xy.Y + element.ActualHeight);
                        if (!double.IsNaN(xy.X) && !double.IsNaN(xy.Y))
                        {
                            within = IsWithin(xy, xy2, left, top, width, height, allowPartial);
                            if (within && insetWidth > 0 && insetHeight > 0)
                            {
                                var insetLeft = left + width - insetWidth;
                                var insetPartial = !allowPartial; // reversing allowpartial for inset checking
                                var withinInset = IsWithin(xy, xy2, insetLeft, top, insetWidth, insetHeight, insetPartial);
                                if (withinInset)
                                {
                                    within = false;
                                }
                            }
                            if (within)
                            {
                                elements.Add((T)element);
                                try
                                {
                                    tbs.Add(new XYCo() { X = xy.X, Y = xy.Y }, (T)element);
                                }
                                catch (Exception e)
                                {
                                    //MessageBox.Show(e.Message);
                                }
                            }
                        }
                    }
                }
            }
            return tbs;
        }

        public static bool IsWithin(Point xy, Point xy2, double left, double top, double width, double height, bool allowPartial)
        {
            var within = false;
            if (!double.IsNaN(xy.X) && !double.IsNaN(xy.Y))
            {
                var right = left + width;
                var bottom = top + height;
                var startX = (xy.X >= left && xy.X <= right);
                var endX = (xy2.X >= left && xy2.X <= right);
                var startY = (xy.Y >= top && xy.Y <= bottom);
                var endY = (xy2.Y >= top && xy2.Y <= bottom);
                if (allowPartial)
                {
                    if ((startX && startY) || (endX && endY))
                    {
                        within = true;
                    }
                }
                else
                {
                    if ((startX && startY) && (endX && endY))
                    {
                        within = true;
                    }
                }
            }
            return within;
        }

        public static Point GetXY(this FrameworkElement element)
        {
            Point xy = new Point(double.NaN, double.NaN);
            xy.X = Canvas.GetLeft(element);
            if (double.IsNaN(xy.X))
            {
                xy.X = Canvas.GetRight(element);
                if (!double.IsNaN(xy.X))
                {
                    xy.X = xy.X - element.ActualWidth;
                }
            }
            xy.Y = Canvas.GetTop(element);
            if (double.IsNaN(xy.Y))
            {
                xy.Y = Canvas.GetBottom(element);
                if (!double.IsNaN(xy.Y))
                {
                    xy.Y = xy.Y - element.ActualHeight;
                }
            }
            return xy;
        }

        public static Rect GetRect(this FrameworkElement element)
        {
            double left = Canvas.GetLeft(element);
            if (double.IsNaN(left))
            {
                left = Canvas.GetRight(element);
                if (!double.IsNaN(left))
                {
                    left = left - element.ActualWidth;
                }
            }
            double top = Canvas.GetTop(element);
            if (double.IsNaN(top))
            {
                top = Canvas.GetBottom(element);
                if (!double.IsNaN(top))
                {
                    top = top - element.ActualHeight;
                }
            }
            Rect rect = new Rect(left, top, element.ActualWidth, element.ActualHeight);
            return rect;
        }

        public static string Nvl(this string text, string nullValue = "", bool upperCase = true)
        {
            if (text == null)
            {
                return nullValue;
            }
            if (upperCase)
            {
                return text.ToUpperInvariant();
            }
            return text;
        }

        public static string ToSingleLine(this string text, string nullValue = "", bool trimmed = true, bool upperCase = true)
        {
            text = text.Nvl(nullValue, upperCase);
            text = text.Replace(Environment.NewLine, " ");
            if (trimmed)
            {
                text = text.Trim();
            }
            return text;
        }

        public static string FormatMultiLine(this string text, string nullValue = "", bool collapseEmptyLines = true, bool trimmed = true)
        {
            text = text.Nvl(nullValue);
            if (trimmed)
            {
                text = text.Trim();
            }
            string[] lines = text.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
            if (lines != null && lines.Length > 0)
            {
                StringBuilder sb = new StringBuilder();
                string trimmedLine;
                string line = null;
                bool emptyLine = false;
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i] != null)
                    {
                        line = null;
                        trimmedLine = lines[i].Trim();
                        if (trimmed)
                        {
                            lines[i] = trimmedLine;
                        }
                        line = lines[i];
                        if (collapseEmptyLines)
                        {
                            if (trimmedLine.Length == 0)
                            {
                                if (emptyLine)
                                {
                                    line = null;
                                }
                                emptyLine = true;
                            }
                            else
                            {
                                emptyLine = false;
                            }
                        }
                        if (line != null)
                        {
                            if (sb.Length > 0)
                            {
                                sb.AppendLine("");
                            }
                            sb.Append(line);
                        }
                    }
                }
                text = sb.ToString();
            }
            return text;
        }

        public static string InsertText(this string value, string currentValue, int cursorAt, bool acceptsNewLine)
        {
            if (string.IsNullOrEmpty(value))
            {
                return currentValue;
            }
            else if (!string.IsNullOrEmpty(currentValue))
            {
                string prefix = "";
                string suffix = "";
                string nl = Environment.NewLine;
                if (cursorAt == -1)
                {
                    return currentValue + value;
                }
                else if (!acceptsNewLine || !value.Contains(nl))
                {
                    if (cursorAt == 0)
                    {
                        suffix = currentValue;
                    }
                    else if (currentValue.Length > cursorAt)
                    {
                        prefix = currentValue.Substring(0, cursorAt);
                        suffix = currentValue.Substring(cursorAt);
                        return prefix + value + suffix;
                    }
                }
                else
                {
                    int idx = cursorAt;
                    int previousNL = currentValue.LastIndexOf(nl, cursorAt);
                    if (previousNL == -1)
                    {
                        suffix = currentValue;
                    }
                    else
                    {
                        previousNL++;
                        idx = cursorAt - previousNL;
                        prefix = currentValue.Substring(0, previousNL);
                        suffix = currentValue.Substring(previousNL);
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.Append(prefix);
                    int maxLength = 0;
                    string[] insertlines = value.Split(new string[] { nl }, StringSplitOptions.None);
                    string[] lines = suffix.Split(new string[] { nl }, StringSplitOptions.None);
                    int maxLines = 0;
                    if (lines != null && lines.Length > maxLines)
                    {
                        maxLines = lines.Length;
                    }
                    if (insertlines != null)
                    {
                        if (insertlines.Length > maxLines)
                        {
                            maxLines = insertlines.Length;
                        }
                        for (int i = 0; i < insertlines.Length; i++)
                        {
                            if (insertlines[i] != null && insertlines[i].Length > maxLength)
                            {
                                maxLength = insertlines[i].Length;
                            }
                        }
                    }
                    if (maxLines > 0)
                    {
                        string currLine = "";
                        for (int i = 0; i < maxLines; i++)
                        {
                            currLine = "";
                            if (lines.Length > i && lines[i] != null)
                            {
                                currLine = lines[i];
                            }
                            if (insertlines.Length > i)
                            {
                                string currInsertLine = "";
                                if (insertlines[i] != null)
                                {
                                    currInsertLine = insertlines[i];
                                }
                                currInsertLine = currInsertLine.PadRight(maxLength, ' ');
                                if (currLine.Length < idx)
                                {
                                    sb.Append(currLine.PadRight(idx, ' '));
                                    sb.Append(currInsertLine);
                                }
                                else
                                {
                                    sb.Append(currLine.Substring(0, idx));
                                    sb.Append(currInsertLine);
                                    sb.Append(currLine.Substring(idx));
                                }
                            }
                            else
                            {
                                sb.Append(currLine);
                            }
                            sb.AppendLine();
                        }

                    }
                    return sb.ToString();
                }
            }
            return value;
        }

        public static DataCaptureElement FindBLElementByType(this DataCaptureElement[] blElements, DataCaptureElementType blElementType)
        {
            if (blElements != null)
            {
                foreach (DataCaptureElement blElement in blElements)
                {
                    if (blElement != null && blElement.DCElementType == blElementType)
                    {
                        return blElement;
                    }
                }
            }
            return null;
        }


        public static string PrefixValue(this string value, string field)
        {
            string nl = Environment.NewLine;
            if (!string.IsNullOrEmpty(value))
            {
                value = nl + value;
            }
            if (!string.IsNullOrEmpty(field))
            {
                value = field + value;
            }
            return value;
        }

        public static void SetPositionInToolTip(this FrameworkElement element)
        {
            if (element != null)
            {
                var left = Canvas.GetLeft(element);
                var top = Canvas.GetTop(element);
                var width = element.ActualWidth;
                var height = element.ActualHeight;
                if (width == 0 && element.Width != Double.NaN)
                {
                    width = element.Width;
                }
                if (height == 0 && element.Height != Double.NaN)
                {
                    height = element.Height;
                }
                StringBuilder sbTip = new StringBuilder();
                sbTip = sbTip.AppendLine("Left\t" + Math.Round(left, 3));
                sbTip = sbTip.AppendLine("Top\t" + Math.Round(top, 3));
                sbTip = sbTip.AppendLine("Width\t" + Math.Round(width, 3));
                sbTip = sbTip.AppendLine("Height\t" + Math.Round(height, 3));
                sbTip = sbTip.AppendLine("Right\t" + Math.Round(left + width, 3));
                sbTip = sbTip.AppendLine("Bottom\t" + Math.Round(top + height, 3));

                var capture = Window.GetWindow(element) as MainWindow;
                if (capture != null)
                {
                    element.SetBinding(ToolTipService.IsEnabledProperty, new Binding("EnableToolTip") { Source = capture });
                }
                element.ToolTip = sbTip.ToString();
            }
        }

        public static ContextMenu GetContextMenu(this MenuItem menuItem)
        {
            var ctx = menuItem.Parent as ContextMenu;
            if (ctx == null)
            {
                if (menuItem.Parent is MenuItem)
                {
                    ctx = ((MenuItem)menuItem.Parent).GetContextMenu();
                }
            }
            return ctx;
        }

        public static bool ValidateText(this TextBox tb)
        {
            bool isValid = true;
            if (tb != null)
            {

                var binding = tb.GetBindingExpression(TextBox.TextProperty);
                if (binding != null)
                {
                    binding.UpdateSource();
                    isValid = !binding.HasValidationError;
                    //AS15024:Begin
                    if (tb.Text != null)
                    {
                        if (tb.Text.Contains('¶'))
                        {
                            isValid = false;
                            var validationError = new ValidationError(new ExceptionValidationRule(), binding);
                            validationError.ErrorContent = "Contains Special Character.Please replace";
                            Validation.MarkInvalid(binding, validationError);
                        }
                    }
                    //AS15024:End
         
                }
            }
            return isValid;
        }            


        public static string[] SplitToLines(this string text, int len, int lineCount, ref string message)
        {
            List<string> texts = new List<string>();
            var moreLines = false;
            int idx = 0;
            string overflow = "";
            string[] data = text.Split(new string[] { Environment.NewLine, "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).ToArray();
            for (int i = 0; i < data.Length; i++)
            {
                if (!string.IsNullOrWhiteSpace(overflow))
                {
                    data[i] = overflow + " " + data[i];
                    overflow = "";
                }
                if (!string.IsNullOrWhiteSpace(data[i]))
                {
                    data[i] = data[i].TrimEnd();
                    if (data[i].Length > len)
                    {
                        if (message.Length > 0)
                        {
                            message = message + ", ";
                        }
                        message = message + (i + 1);
                        overflow = data[i].Substring(len).Trim();
                        data[i] = data[i].Substring(0, len);
                    }
                }
                if (!string.IsNullOrWhiteSpace(data[i]))
                {
                    texts.Add(data[i]);
                    if (texts.Count() >= lineCount)
                    {
                        break;
                    }
                }
            }
            return texts.ToArray();
        }

        /// <summary>
        /// Looks up in unit list's units collection for code matching type. 
        /// Ignores mapped units. 
        /// </summary>
        /// <param name="unitList"></param>
        /// <param name="unitType"></param>
        /// <param name="unitCode"></param>
        /// <returns></returns>
        public static bool LookupAndValidateUnits(this UnitList unitList, UnitType unitType, string unitCode)
        {
            if (unitList == null)
            {
                return true;
            }
            if (unitList.Units == null)
            {
                return false;
            }
            if (string.IsNullOrWhiteSpace(unitCode))
            {
                return true;
            }
            var unit = unitList.Units.Where(p => p.UnitType == unitType && p.IsMappedValue == false && p.UnitCode.Equals(unitCode, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (unit != null)
            {
                return true;
            }
            return false;
        }

        public static string IndentText(this string text, int length)
        {
            string indentedText = "";
            if (!string.IsNullOrWhiteSpace(text))
            {
                var texts = text.Split(new string[] { Environment.NewLine, "\n", "\r" }, StringSplitOptions.None);
                if (texts != null && texts.Length > 0)
                {
                    var sb = new StringBuilder();
                    var indent = new string(' ', length);
                    foreach (var line in texts)
                    {
                        sb.Append(indent);
                        sb.Append(line);
                        sb.AppendLine();
                    }
                    indentedText = sb.ToString();
                }
            }
            return indentedText;
        }

        public static void LogException(this Exception exc)
        {
            try
            {
                var mainWindow = Application.Current.MainWindow as MainWindow;
                if (mainWindow != null)
                {
                    var logFolder = mainWindow.GetLogSubFolder();
                    if (string.IsNullOrWhiteSpace(logFolder))
                    {
                        return;
                    }
                    var now = DateTime.Now;
                    var today = now.Date;
                    var logPath = Path.Combine(logFolder, "DataCapture_" + String.Format("{0:00}", today.Day) + ".log");
                    var exists = File.Exists(logPath);
                    if (exists)
                    {
                        var fi = new FileInfo(logPath);
                        if (!fi.LastWriteTime.Date.Equals(today))
                        {
                            exists = false;
                            fi.Delete();
                        }
                    }
                    if (!exists)
                    {
                        var sb = new StringBuilder();
                        sb.Append("User Name: ");
                        sb.Append(Environment.UserDomainName);
                        sb.Append("\\\\");
                        sb.Append(Environment.UserName);
                        sb.AppendLine();

                        sb.Append("Machine: ");
                        sb.Append(Environment.MachineName);
                        sb.AppendLine();

                        sb.Append("Date: ");
                        sb.Append(today.ToShortDateString());
                        sb.AppendLine();

                        sb.Append("Instance: ");
                        sb.Append(mainWindow.CurrentInstance);
                        sb.AppendLine();
                        sb.AppendLine("======================================================================");

                        File.WriteAllText(logPath, sb.ToString());
                    }

                    var msg = exc.Message + Environment.NewLine + exc.StackTrace;
                    msg = Environment.NewLine + now.ToString("HH:mm:ss") + "  Exception Details" + Environment.NewLine + msg.IndentText(10);
                    File.AppendAllText(logPath, msg);
                }
            }
            catch
            {
            }
        }

        public static UnitInfo FindUnit(this IEnumerable<UnitInfo> unitInfos, string value)
        {
            UnitInfo unitInfo = null;
            if (unitInfos != null)
            {
                unitInfo = unitInfos.Where(p => p.UnitCode.Equals(value) && p.IsMappedValue == false).FirstOrDefault();
                if (unitInfo == null)
                {
                    unitInfo = unitInfos.Where(p => p.MappedValue != null && p.MappedValue.Equals(value, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                    if (unitInfo == null)
                    {
                        unitInfo = unitInfos.Where(p => p.AltCode != null && p.IsMappedValue == false && p.AltCode.Equals(value, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                    }
                    if (unitInfo == null)
                    {
                        unitInfo = unitInfos.Where(p => p.DescriptionCompare(value) > 0 && p.IsMappedValue == false).FirstOrDefault();
                    }
                }
            }
            return unitInfo;
        }

        public static UnitInfo FindUnit(this UnitList unitList, UnitType unitType, string value)
        {
            UnitInfo unitInfo = null;
            if (unitList != null && unitList.Units != null && !string.IsNullOrWhiteSpace(value))
            {
                var ums = unitList.Units.Where(p => p.UnitType == unitType);
                if (ums != null)
                {
                    unitInfo = ums.FindUnit(value);
                }
            }
            return unitInfo;
        }

        public static string MappedCode(this UnitList unitList, UnitType unitType, string value)
        {
            if (unitList != null)
            {
                var unitInfo = unitList.FindUnit(unitType, value);
                if (unitInfo != null)
                {
                    value = unitInfo.UnitCode;
                }
            }
            return value;
        }

        public static iTextSharp.text.Rectangle GetTextRect(this iTextSharp.text.pdf.parser.TextRenderInfo renderInfo)
        {
            var fontSize = renderInfo.GetFontSize();
            var baseLine = renderInfo.GetBaseline();
            var ascentLine = renderInfo.GetAscentLine();
            var startPointB = baseLine.GetStartPoint();
            var endPointB = baseLine.GetEndPoint();
            var startPointA = ascentLine.GetStartPoint();
            var endPointA = ascentLine.GetEndPoint();
            var left = float.IsNaN(startPointB[iTextSharp.text.pdf.parser.Vector.I1]) ? startPointA[iTextSharp.text.pdf.parser.Vector.I1] : startPointB[iTextSharp.text.pdf.parser.Vector.I1];
            var bottom = float.IsNaN(startPointB[iTextSharp.text.pdf.parser.Vector.I2]) ? startPointA[iTextSharp.text.pdf.parser.Vector.I2] : startPointB[iTextSharp.text.pdf.parser.Vector.I2];
            var right = float.IsNaN(endPointA[iTextSharp.text.pdf.parser.Vector.I1]) ? endPointB[iTextSharp.text.pdf.parser.Vector.I1] :endPointA[iTextSharp.text.pdf.parser.Vector.I1] ;
            var top = float.IsNaN(endPointA[iTextSharp.text.pdf.parser.Vector.I2]) ? endPointB[iTextSharp.text.pdf.parser.Vector.I2] + fontSize : endPointA[iTextSharp.text.pdf.parser.Vector.I2];
            var textRect = new iTextSharp.text.Rectangle(left, bottom, right, top);
            return textRect;
        }

        public static Rect ToRect(this iTextSharp.text.Rectangle textRect, double pageHeight)
        {
            double newleft = textRect.Left;
            double newtop = pageHeight - textRect.Top;
            return new Rect(newleft + (textRect.Width > 0 ? 0 : textRect.Width), newtop + (textRect.Height > 0 ? 0 : textRect.Height), Math.Abs(textRect.Width), Math.Abs(textRect.Height));
        }

        public static PDFTextRect ToPDFTextRect(this iTextSharp.text.pdf.parser.TextRenderInfo renderInfo, bool isBelow1_4, iTextSharp.text.Rectangle pageRect, double pageHeight, string alternateFont, double adjustedFontSize, System.Drawing.Color stroke, System.Drawing.Color fill, TextRenderingMode textMode)
        {
            var textRect = renderInfo.GetTextRect();
            if (pageRect.Rotation == 90 || pageRect.Rotation == 270)
            {
                textRect = new iTextSharp.text.Rectangle(textRect.Bottom, pageRect.Height - textRect.Left, textRect.Top, pageRect.Height - textRect.Right);
            }
            var rect = textRect.ToRect(pageHeight);
            var text = renderInfo.GetText();
            var xsize = renderInfo.GetFontSize();
            var fontSize = Math.Ceiling(textRect.Height) + 2;
            if (!isBelow1_4 && xsize > 1)
            {
                fontSize = xsize;
            }
            var isBold = renderInfo.GetTextRenderMode() == PDFSIReader.FillThenStrokeText;
            var fontName = "";
            var font = renderInfo.GetFont();
            if (font != null)
            {
                if (textRect.Width < 0)
                {
                    fontSize = Math.Abs(textRect.Width);
                }
                //fontSize = Math.Abs(textRect.Width);
                fontName = font.PostscriptFontName;
                if (string.IsNullOrWhiteSpace(fontName))
                {
                    if (font.FullFontName != null && font.FullFontName.Length > 0 && font.FullFontName[0].Length > 3 && !string.IsNullOrWhiteSpace(font.FullFontName[0][3]))
                    {
                        fontName = font.FullFontName[0][3];
                    }
                }
                if (!string.IsNullOrWhiteSpace(fontName))
                {
                    if (!isBold)
                    {
                        isBold = fontName.ToUpper().Contains("BOLD");
                    }
                    if (adjustedFontSize > 1)
                    {
                        fontSize = adjustedFontSize;
                    }
                }
                fontName = AdjustedFontName(fontName);
            }
            var pdfTextRect = new PDFTextRect(text, rect.Left, rect.Top, rect.Width, rect.Height);
            pdfTextRect.Stroke = stroke;
            pdfTextRect.Fill = fill;
            pdfTextRect.TextMode = textMode;
            if (!string.IsNullOrWhiteSpace(fontName))
            {
                pdfTextRect.FontFamily = fontName;
            }
            else if (!string.IsNullOrWhiteSpace(alternateFont))
            {
                pdfTextRect.FontFamily = alternateFont;
                pdfTextRect.AlternateFont = true;
            }
            if (textRect.Width < 0) // Set Rotation to 270 if renderInfo width is less than 0
            {
                pdfTextRect.TextRotation = 270;
            }
            pdfTextRect.FontSize = fontSize;
            pdfTextRect.IsBold = isBold;
            return pdfTextRect;
        }

        public static float GetFontSize(this iTextSharp.text.pdf.parser.TextRenderInfo renderInfo)
        {
            float size = 0;
            var field = renderInfo.GetType().GetField("gs", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var gs = (iTextSharp.text.pdf.parser.GraphicsState)field.GetValue(renderInfo);
            size = gs.FontSize;
            return size;
        }

        public static string AdjustedFontName(string fontName)
        {
            if (!string.IsNullOrWhiteSpace(fontName))
            {
                // Adjust for font subsetting
                if (fontName.Length > 7 && fontName.Substring(6, 1).Equals("+"))
                {
                    fontName = fontName.Substring(7);
                }

                // Add space around new 
                var idxNew = fontName.IndexOf("new", StringComparison.InvariantCultureIgnoreCase);
                if (idxNew > 0)
                {
                    fontName = fontName.Substring(0, idxNew).Trim() + " New " + fontName.Substring(idxNew + 3).Trim();
                }
                //foreach (string font in FontMappingInfo.Keys)
                //{
                //    if (fontName.Replace(" ", "").Contains(font))
                //    {
                //        return FontMappingInfo[font];
                //    }
                //}

                // verify if font exists in system
                var sysFonts = System.Windows.Media.Fonts.SystemFontFamilies;
                if (sysFonts != null)
                {
                    string diffName = null;
                    foreach (var font in sysFonts)
                    {
                        if (font != null && font.Source != null)
                        {
                            if (fontName.Equals(font.Source))
                            {
                                return font.Source;
                            }
                            if (fontName.Replace(" ", "").Equals(font.Source.Replace(" ", "")))
                            {
                                return font.Source;
                            }
                            if (fontName.Contains(font.Source))
                            {
                                diffName = font.Source;
                            }
                        }
                    }
                    if (diffName != null)
                    {
                        return diffName;
                    }
                }
            }
            return "";
        }

        public static IEnumerable<PDFTextRect> GetCharacterTextRects(this iTextSharp.text.pdf.parser.TextRenderInfo renderInfo, string altText, bool isBelow1_4, iTextSharp.text.Rectangle pageRect, double pageHeight, string alternateFont, double adjustedFontSize, System.Drawing.Color stroke, System.Drawing.Color fill, TextRenderingMode textMode)
        {
            var charRects = new List<PDFTextRect>();
            if (renderInfo != null)
            {
                var textRect = renderInfo.ToPDFTextRect(isBelow1_4, pageRect, pageHeight, alternateFont, adjustedFontSize, stroke, fill, textMode);
                var font = renderInfo.GetFont();
                var text = renderInfo.GetText();
                if (string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(altText))
                {
                    text = altText;
                }
                if (!string.IsNullOrEmpty(text))
                {
                    var chars = text.ToCharArray();
                    if (chars != null)
                    {
                        var x = textRect.Left;
                        if (textRect.TextRotation == 90 || textRect.TextRotation == 270)
                        {
                            x = textRect.Top;
                            if (textRect.TextRotation == 270)
                            {
                                chars = chars.Reverse().ToArray();
                            }
                        }
                        for (int i = 0; i < chars.Length; i++)
                        {

                            var str = "" + chars[i];
                            var copy = textRect.Copy();
                            copy.Text = str;
                            copy.FullText = text;
                            if (textRect.TextRotation == 90 || textRect.TextRotation == 270)
                            {
                                copy.Top = x;
                            }
                            else
                            {
                                copy.Left = x;
                            }
                            copy.Width = font.GetWidthPoint(str, (float)copy.FontSize);
                            if (" ".Equals(str))
                            {
                                if (font.GetWidthPoint("A", (float)copy.FontSize) == 0)
                                {
                                    copy.Width = 0;
                                }
                            }
                            if (copy.Width == 0 && copy.FontSize > 1)
                            {
                                var size = str.StringSize(copy.FontFamily, copy.IsBold, copy.FontSize);
                                copy.Width = size.Width;
                            }
                            charRects.Add(copy);
                            if (textRect.TextRotation == 270)
                            {
                                x += copy.Width;
                            }
                            else
                            {
                                x += copy.Width;
                            }
                        }
                    }
                }
            }
            return charRects;
        }

        //internal static Dictionary<string, string> FontMappingInfo = new Dictionary<string, string>{
        //    {"CourierNew","Courier New"},
        //    {"Courier","Courier New"},
        //    {"TimesNewRoman","Times New Roman"},
        //    {"Verdana","Verdana"},
        //    {"ArialNarrow","Arial Narrow"},
        //    {"Arial","Arial"},
        //    {"Helvetica","Arial"},
        //    {"AngsanaNew","Angsana New"},
        //    {"Cambria","Cambria"}
        //};

    }
}