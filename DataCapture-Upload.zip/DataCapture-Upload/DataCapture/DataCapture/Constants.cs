﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public static class Constants
    {
        public const string DESKEWNONE = "0";
        public const string DESKEWREGULAR = "1";
        public const string DESKEWBEFOREOCR = "2";
        public const string DESKEWCUSTOM = "3";


        //public const string LOCAL = "LOCAL";
        //public const string DEV = "DEV";
        //public const string SQA = "SQA";
        //public const string UAT = "UAT";
        //public const string PRD = "PRD";
        //public const string UNKNOWN = "UNKNOWN";

        //public const string DATAENCRYPTIONKEY = "BLCAPTUREKEY";
    }
}
