﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public enum TextRenderingMode
    {
        Fill,
        Stroke,
        FillThenStroke,
        NoFillNoStroke,
        FillAndClip,
        StrokeAndClip
    }
}
