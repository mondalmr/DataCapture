namespace DataCapture.DbContext
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using DataCapture.DbContext.Entity;

    public partial class DataCaptureDbContext : DbContext
    {
        public DataCaptureDbContext()
            : base("name=DataCaptureDBConnString")
        {
        }

        public virtual DbSet<tblChallanMaster> tblChallanMasters { get; set; }
        public virtual DbSet<tblVendorCerificateDetail> tblVendorCerificateDetails { get; set; }
        public virtual DbSet<tblVendorMaster> tblVendorMasters { get; set; }

        public virtual DbSet<tblStageChallanDetails> tblStageChallanDetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<tblVendorCerificateDetail>()
                .Property(e => e.Rate)
                .HasPrecision(5, 2);

            modelBuilder.Entity<tblVendorMaster>()
                .Property(e => e.IsEngagedinCallCentre)
                .IsUnicode(false);
        }
    }
}
