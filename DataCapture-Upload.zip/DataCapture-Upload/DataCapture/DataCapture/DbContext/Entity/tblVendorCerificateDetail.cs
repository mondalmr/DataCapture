namespace DataCapture.DbContext.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblVendorCerificateDetails")]
    public partial class tblVendorCerificateDetail
    {
        [Key]
        public Guid VendorCertificateID { get; set; }

        public Guid? VendorID { get; set; }

        [StringLength(50)]
        public string VendorIdERP { get; set; }

        [StringLength(50)]
        public string VendorSiteId { get; set; }

        public DateTime? WHCertStartDate { get; set; }

        public DateTime? WHCertEndDate { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? CertificateAmount { get; set; }

        [StringLength(50)]
        public string Form15G15HApplicable { get; set; }

        public bool? Form15G15HAvailable { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? Rate { get; set; }

        [StringLength(255)]
        public string AcknowledgementFormNo15CA { get; set; }

        [StringLength(50)]
        public string Nature { get; set; }

        [StringLength(50)]
        public string CertificateNo { get; set; }

        [StringLength(50)]
        public string NonOrLowerDeductionReason { get; set; }

        public Guid? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public bool? IsActive { get; set; }

        public bool? IsDeleted { get; set; }

        [StringLength(20)]
        public string FinancialYear { get; set; }

        public DateTime? DateoffurnishingTaxDeduction { get; set; }
    }
}
