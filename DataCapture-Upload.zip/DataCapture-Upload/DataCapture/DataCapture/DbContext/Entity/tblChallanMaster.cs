namespace DataCapture.DbContext.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblChallanMaster")]
    public partial class tblChallanMaster
    {
        [Key]
        public Guid ChallanID { get; set; }

        [Required]
        [StringLength(50)]
        public string ChallanIdentificationNo { get; set; }

        public int ChallanSerialNo { get; set; }

        [Required]
        [StringLength(50)]
        public string BankBSRCode { get; set; }

        [StringLength(50)]
        public string BankName { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ChallanDepositDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ChallanClearingDate { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? Amount { get; set; }

        public Guid? TDSSectionID { get; set; }

        public Guid? TDSSectionCodeReporting { get; set; }

        [StringLength(50)]
        public string Corporate_NonCorporate { get; set; }

        [StringLength(10)]
        public string AssesmentYear { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? Surcharge { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? EductaionCess { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? Interest { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? FeeSeeNote5 { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? TDS { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? Others { get; set; }

        public bool? WhetherTDSDepositedbyBookEntry { get; set; }

        [StringLength(50)]
        public string MinorHeadofChallanAnnexure7 { get; set; }

        [StringLength(50)]
        public string TANOfDeductor { get; set; }

        [StringLength(50)]
        public string TypeofPayment { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? InterestAllocated { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? OtherAmtAllocated { get; set; }

        [StringLength(1)]
        public string NILChallanIndicator { get; set; }

        [StringLength(200)]
        public string Remarks { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? BalanceChallanAmount { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? BalanceInterestAmount { get; set; }

        public Guid? LegalEntityID { get; set; }

        public Guid? DivisionID { get; set; }

        public bool? Allocate { get; set; }

        [StringLength(50)]
        public string ChallanStatus { get; set; }

        public Guid? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
