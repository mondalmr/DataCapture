namespace DataCapture.DbContext.Entity
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.ComponentModel.DataAnnotations;

    [Table("tblStageChallanDetails")]
    public partial class tblStageChallanDetails
    {
        [Key]
        [Column("Challan Serial No# / DDO Sequence Number in the Book Adjustment")]
        public string ChallanSerialNo { get; set; }

        [Column("Corporate/Non-Corporate")]
        public string CorpNonCopr { get; set; }

        [Column("Type of Payment")]
        public string TypeofPayment { get; set; }

        [Column("Nature of Payment")]
        public string NatureofPayment { get; set; }

        [Column("TAN of deductor")]
        public string TANofdeductor { get; set; }

        [Column("Assessment Year")]
        public string AssessmentYear { get; set; }

        public decimal? TDS { get; set; }

        public decimal? Surcharge_ { get; set; }

        [Column("Education Cess_")]
        public decimal? EducationCess_ { get; set; }

        public decimal? Interest { get; set; }

        [Column("Fee (See Note 5)")]
        public decimal? Fee { get; set; }

        public string Others { get; set; }

        [Column("Total Tax Deposited")]
        public decimal? TotalTaxDeposited { get; set; }

        [Column("Whether TDS Deposited by Book Entry")]
        public string WhetherTDSDepositedbyBookEntry { get; set; }

        [Column("Bank-Branch Code/ Form 24G Receipt Number")]
        public string BankBranchCode { get; set; }

        [Column("Date on Which Tax Deposited (dd/mm/yyyy)")]
        public string DateonWhichTaxDeposited { get; set; }

        [Column("Minor Head of Challan(Annexure 7)")]
        public string MinorHead { get; set; }

        [Column("Interest  Allocated")]
        public string InterestAllocated { get; set; }

        [Column("Other Amt Allocated")]
        public decimal? OtherAmtAllocated { get; set; }

        [Column("NIL Challan Indicator")]
        public string NILChallanIndicator { get; set; }

        public string Remarks { get; set; }

        [Column("Bank Name")]
        public string BankName { get; set; }

        public string SectionCode { get; set; }        
    }
}
