namespace DataCapture.DbContext.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblVendorMaster")]
    public partial class tblVendorMaster
    {
        [Key]
        public Guid VendorID { get; set; }

        [StringLength(50)]
        public string VendorIdERP { get; set; }

        [Required]
        [StringLength(50)]
        public string VendorCode { get; set; }

        [Required]
        [StringLength(500)]
        public string VendorName { get; set; }

        [StringLength(255)]
        public string VendorMiddleName { get; set; }

        [StringLength(255)]
        public string VendorLastName { get; set; }

        [StringLength(50)]
        public string VendorSiteId { get; set; }

        [StringLength(20)]
        public string PAN { get; set; }

        [StringLength(20)]
        public string TAN { get; set; }

        [StringLength(200)]
        public string AssesseeType { get; set; }

        [StringLength(20)]
        public string Corporate_NonCorporate { get; set; }

        [StringLength(10)]
        public string Resident_NonResident { get; set; }

        [StringLength(50)]
        public string AccountNo { get; set; }

        [StringLength(50)]
        public string CompanyCode { get; set; }

        public bool? CoveredByNotification21_2012 { get; set; }

        public Guid? PayeeStatusID { get; set; }

        [StringLength(50)]
        public string PayeeStatus { get; set; }

        public Guid? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public bool? IsActive { get; set; }

        public bool? IsDeleted { get; set; }

        [StringLength(500)]
        public string Address1 { get; set; }

        [StringLength(500)]
        public string Address2 { get; set; }

        [StringLength(10)]
        public string PinCode { get; set; }

        [StringLength(150)]
        public string State { get; set; }

        [StringLength(255)]
        public string DeducteeCode { get; set; }

        [StringLength(255)]
        public string CommentforExempt { get; set; }

        public bool EngagedinCallCentre { get; set; }

        [Required]
        [StringLength(10)]
        public string IsEngagedinCallCentre { get; set; }

        [StringLength(255)]
        public string TANForNonDomesticVendors { get; set; }

        [StringLength(255)]
        public string VendorEmailId { get; set; }

        [StringLength(25)]
        public string VendorContactNumber { get; set; }

        public Guid? LegalEntityID { get; set; }

        public Guid? DivisionID { get; set; }
    }
}
