﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class OCRPostAlphabetRule : IOCRPostRule
    {
        public string Description
        {
            get
            {
                return "Convert certain numbers to alphabets";
            }
        }

        public string Apply(string text)
        {
            var words = text.ToWords();
            if (words == null)
            {
                return text;
            }
            else
            {
                for (int i = 0; i < words.Length; i++)
                {
                    if (words[i] != null && words[i].Length > 1)
                    {
                        words[i] = words[i].Replace('1', 'l');
                        words[i] = words[i].Replace('0', 'O');
                        words[i] = words[i].Replace('2', 'Z');
                        words[i] = words[i].Replace('6', 'G');
                    }
                }
            }
            return string.Join("", words);
        }
    }
}
