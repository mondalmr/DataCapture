﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class OCRPostTask : NotifyInfo
    {
        public OCRPostTask()
        {
            _rules = new ObservableCollection<OCRPostInfo>();
            _userRules = new ObservableCollection<OCRPostInfo>();
            SetupRules();
        }

        string _original;
        public string Original
        {
            get
            {
                return _original;
            }
            set
            {
                _original = value;
                RaisePropertyChanged("Original");
            }
        }

        string _fixed;
        public string Fixed
        {
            get
            {
                return _fixed;
            }
            set
            {
                _fixed = value;
                RaisePropertyChanged("Fixed");
            }
        }

        ObservableCollection<OCRPostInfo> _rules;
        public ObservableCollection<OCRPostInfo> Rules
        {
            get
            {
                return _rules;
            }
        }

        ObservableCollection<OCRPostInfo> _userRules;
        public ObservableCollection<OCRPostInfo> UserRules
        {
            get
            {
                return _userRules;
            }
        }


        private void SetupRules()
        {
            var rules = Rules;
            if (rules != null)
            {
                var allrules = OCRPostUtils.GetRules();
                if (allrules != null)
                {
                    foreach (var rule in allrules)
                    {
                        if (rule != null)
                        {
                            rules.Add(rule);
                        }
                    }
                }
            }

            var userRules = _userRules;
            if (userRules != null)
            {
                var allrules = OCRPostUtils.GetUserRules();
                if (allrules != null)
                {
                    foreach (var rule in allrules)
                    {
                        if (rule != null)
                        {
                            userRules.Add(rule);
                        }
                    }
                }
            }
        }
    }
}
