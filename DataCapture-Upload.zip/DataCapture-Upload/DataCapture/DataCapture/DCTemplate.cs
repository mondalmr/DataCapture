﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    [Serializable]
    public class DCTemplate
    {
        public DCTemplate()
        {
        }

        public DCTemplateElement[] TemplateElements
        {
            get;
            set;
        }

        public string DefaultPkgCode
        {
            get;
            set;
        }

        public string DefaultGWUM
        {
            get;
            set;
        }

        public string DefaultNWUM
        {
            get;
            set;
        }

        public string DefaultGMUM
        {
            get;
            set;
        }

        public string DefaultNMUM
        {
            get;
            set;
        }

        public string WordCuts
        {
            get;
            set;
        }

        public ReplaceInfo[] Replacements
        {
            get;
            set;
        }

        public string OCRSize
        {
            get;
            set;
        }

    }
}
