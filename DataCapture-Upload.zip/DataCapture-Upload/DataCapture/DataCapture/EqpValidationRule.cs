﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
//using DataCapture.Client;
using System.Text.RegularExpressions;

namespace DataCapture
{
    public class ContainerValidationRule : ValidationRule
    {
        public ContainerValidationRule()
        {
        }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var text = "";
            Regex RgxUrl = new Regex("[^A-Za-z0-9]");
            bool blnContainsSpecialCharacters;
            if (value != null)
            {
                text = value.ToString();
            }

            if (!string.IsNullOrWhiteSpace(text))
            {
                string[] old = text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                List<string> oldlist = old.ToList();
                List<string> invalidLenList = new List<string>();
                List<string> invalidList = new List<string>();

                foreach (string eqp in oldlist)
                {
                    if (eqp.Length > 11)//eqp.Length > 12. Checked against 11 chars 11/07/2014 MARC Ticket IN14070347886
                    {
                        invalidLenList.Add(eqp);
                    }

                    blnContainsSpecialCharacters = RgxUrl.IsMatch(eqp);

                    if (blnContainsSpecialCharacters)
                    {
                        invalidList.Add(eqp);
                    }
                }

                if (invalidLenList.Count > 0)
                {
                    return new ValidationResult(false, "Following Containers have length more than 11: " + string.Join(Environment.NewLine, invalidLenList.ToArray()));
                }
                if (invalidList.Count > 0)
                {
                    return new ValidationResult(false, "Following Container No contains Special Characters: " + string.Join(Environment.NewLine, invalidList.ToArray()));
                }
            }

            return new ValidationResult(true, null);
        }
    }

    public class SealNoValidationRule : ValidationRule
    {
        public SealNoValidationRule()
        {
        }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var text = "";

            if (value != null)
            {
                text = value.ToString();
            }

            if (!string.IsNullOrWhiteSpace(text))
            {
                string[] old = text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                List<string> oldlist = old.ToList();
                List<string> invalidListMaxSeals = new List<string>();
                List<string> invalidList = new List<string>();

                foreach (string seals in oldlist)
                {
                    string[] multSeals = seals.Split(new string[] { "^" }, StringSplitOptions.RemoveEmptyEntries);
                    int sealCounter = 0;

                    foreach (string seal in multSeals)
                    {
                        sealCounter++;

                        if (seal.Length > 35)
                        {
                            invalidList.Add(seal);
                        }
                    }

                    if (sealCounter > 5)
                    {
                        invalidListMaxSeals.Add(seals);
                    }
                }

                if (invalidListMaxSeals.Count > 0)
                {
                    return new ValidationResult(false, "Following Seal No.(s) Collection have more than 3 Seal Nos.: " + string.Join(Environment.NewLine, invalidListMaxSeals.ToArray()));
                }

                if (invalidList.Count > 0)
                {
                    return new ValidationResult(false, "Following Seal No.(s) have length more than 10: " + string.Join(Environment.NewLine, invalidList.ToArray()));
                }
            }

            return new ValidationResult(true, null);
        }
    }

    public class ContainerSealNoValidationRule : ValidationRule
    {
        public ContainerSealNoValidationRule()
        {
        }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            return new ValidationResult(true, null);
        }
    }
}
