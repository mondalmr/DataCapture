﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            var message = "The application terminated unexpectedly.";
            try
            {
                var pwd = Environment.CurrentDirectory;
                var mainWindow = MainWindow as MainWindow;
                if (mainWindow != null && !string.IsNullOrWhiteSpace(mainWindow.WorkingPath))
                {
                    pwd = mainWindow.WorkingPath;
                }
                var filePath = Path.Combine(pwd, "DataCapture.log");
                File.WriteAllText(filePath, e.Exception.Message + Environment.NewLine + e.Exception.StackTrace);
                message = "";//$"{ message } A detailed error log has been created with details. The file is available at { filePath} ";
                //Log the Exception in Database
            }
            catch(Exception ex)
            {
            }
            MessageBox.Show(message);
            Shutdown();
        }
    }
}
