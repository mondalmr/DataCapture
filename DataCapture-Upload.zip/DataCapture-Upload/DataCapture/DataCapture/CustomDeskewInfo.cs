﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class CustomDeskewInfo
    {
        public const int APPLYACTION = 0;
        public const int ANALYSISACTION = 1;
        public const int ANALYSISWITHDESKEWACTION = 2;

        public int MarginLeft
        {
            get;
            set;
        }

        public int MarginRight
        {
            get;
            set;
        }

        public int MarginTop
        {
            get;
            set;
        }

        public int MarginBottom
        {
            get;
            set;
        }

        public int Width
        {
            get;
            set;
        }

        public int Height
        {
            get;
            set;
        }

        public int Action
        {
            get;
            set;
        }

        public CustomDeskewInfo Scaled(double xFactor, double yFactor)
        {
            var deskewInfo = new CustomDeskewInfo();
            deskewInfo.MarginLeft = (int)((double)MarginLeft * xFactor);
            deskewInfo.MarginTop = (int)((double)MarginTop * yFactor);
            deskewInfo.MarginRight = (int)((double)MarginRight * xFactor);
            deskewInfo.MarginBottom = (int)((double)MarginBottom * yFactor);
            deskewInfo.Width = (int)((double)Width * xFactor);
            deskewInfo.Height = (int)((double)Height * yFactor);
            deskewInfo.Action = Action;
            return deskewInfo;
        }
    }
}
