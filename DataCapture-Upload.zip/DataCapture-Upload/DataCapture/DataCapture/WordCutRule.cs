﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    public class WordCutRule : IOCRPostRule
    {
        public string Description
        {
            get;
            set;
        }

        public string Text
        {
            get;
            set;
        }

        public string Apply(string text)
        {
            return Text;
        }
    }
}
