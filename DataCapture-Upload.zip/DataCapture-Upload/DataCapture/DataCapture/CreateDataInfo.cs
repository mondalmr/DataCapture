﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataCapture.DTO;

namespace DataCapture
{
    public class CreateDataInfo : NotifyInfo
    {

        UnitInfo[] _PackageUMs;
        UnitInfo[] _WeightUMs;
        UnitInfo[] _MeasureUMs;

        public CreateDataInfo()
        {
            _PackageUMs = null;
            _WeightUMs = null;
            _MeasureUMs = null;

            PackageUnits = new ObservableCollection<ValueSubstitution>();
            WeightUnits = new ObservableCollection<ValueSubstitution>();
            MeasureUnits = new ObservableCollection<ValueSubstitution>();
        }

        public UnitInfo[] PackageUMs
        {
            get
            {
                return _PackageUMs;
            }
        }

        public UnitInfo[] WeightUMs
        {
            get
            {
                return _WeightUMs;
            }
        }

        public UnitInfo[] MeasureUMs
        {
            get
            {
                return _MeasureUMs;
            }
        }

        public ObservableCollection<ValueSubstitution> PackageUnits
        {
            get;
            private set;
        }

        public ObservableCollection<ValueSubstitution> WeightUnits
        {
            get;
            private set;
        }

        public ObservableCollection<ValueSubstitution> MeasureUnits
        {
            get;
            private set;
        }

        internal void SetupUMs(IEnumerable<UnitInfo> ums)
        {
            _PackageUMs = ums.Where(p => p.UnitType == UnitType.PackageType).OrderBy(p=>p.Description).ToArray();
            _WeightUMs = ums.Where(p => p.UnitType == UnitType.Weight).OrderBy(p => p.Description).ToArray();
            _MeasureUMs = ums.Where(p => p.UnitType == UnitType.Measure).OrderBy(p => p.Description).ToArray();

            RaisePropertyChanged("PackageUMs");
            RaisePropertyChanged("WeightUMs");
            RaisePropertyChanged("MeasureUMs");
        }

        internal void UpdateValues(IEnumerable<GridInfo> packages)
        {
            PackageUnits.Clear();
            WeightUnits.Clear();
            MeasureUnits.Clear();
            if (packages != null)
            {
                foreach (var pkg in packages)
                {
                    if (pkg != null)
                    {
                        AddMappedValue(pkg.CertificateNo, PackageUnits, PackageUMs);

                        AddMappedValue(pkg.Nature, WeightUnits, WeightUMs);
                        AddMappedValue(pkg.FromDate, WeightUnits, WeightUMs);

                        AddMappedValue(pkg.ToDate, MeasureUnits, MeasureUMs);
                        //AddMappedValue(pkg.PackageNetMeasureUM, MeasureUnits, MeasureUMs);
                    }
                }
            }
        }

        private bool AddMappedValue(string value, ObservableCollection<ValueSubstitution> units, UnitInfo[] ums)
        {
            if (units.Count(p => p.Value.Equals(value)) == 0)
            {
                UnitInfo correctUnit = null;
                if (!string.IsNullOrWhiteSpace(value) && ums != null)
                {
                    correctUnit = ums.FindUnit(value);
                }
                units.Add(new ValueSubstitution(value, correctUnit, this));
                return true;
            }
            return false;
        }

        internal void UpdatePackages(IEnumerable<GridInfo> gridRows)
        {
            if (gridRows != null)
            {
                UndoRedoCollection actions = new UndoRedoCollection();
                string value = "";
                foreach (var gridRow in gridRows)
                {
                    if (gridRow != null)
                    {
                        value = GetMappedValue(gridRow.CertificateNo, UnitType.PackageType, PackageUnits);
                        gridRow.SetPropertyValue(GridInfoFields.CertificateNo, value, true, actions);

                        value = GetMappedValue(gridRow.Nature, UnitType.Weight, WeightUnits);
                        gridRow.SetPropertyValue(GridInfoFields.Nature, value, true, actions);

                        value = GetMappedValue(gridRow.FromDate, UnitType.Weight, WeightUnits);
                        gridRow.SetPropertyValue(GridInfoFields.FromDate, value, true, actions);

                        value = GetMappedValue(gridRow.ToDate, UnitType.Measure, MeasureUnits);
                        gridRow.SetPropertyValue(GridInfoFields.ToDate, value, true, actions);                       
                    }
                }
                UndoRedoManager.Current.AddUndoAction(actions);
            }
        }


        private string GetMappedValue(string currentValue, UnitType unitType, ObservableCollection<ValueSubstitution> units)
        {
            if (units != null)
            {
                var mappedUnit = units.Where(p => p.Value.Equals(currentValue)).Select(p => p.MappedUnit).FirstOrDefault();
                if (mappedUnit != null && !string.IsNullOrWhiteSpace(mappedUnit.UnitCode))
                {
                    currentValue = mappedUnit.UnitCode;
                }
            }
            return currentValue;
        }
    }
}
