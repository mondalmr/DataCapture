﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCapture
{
    [Serializable]
    public class WorkFile
    {
        public WorkFile()
        {
        }

        public DCTemplate SITemplate
        {
            get;
            set;
        }

        public DataCaptureInfo BLInfo
        {
            get;
            set;
        }

        /// <summary>
        /// Path of the SI File
        /// </summary>
        public string SIPath
        {
            get;
            set;
        }

        /// <summary>
        /// Contents of SI file stored as base 64 string
        /// </summary>
        public string SIData
        {
            get;
            set;
        }

        public ImageAction[] ImageActions
        {
            get;
            set;
        }
    }
}
