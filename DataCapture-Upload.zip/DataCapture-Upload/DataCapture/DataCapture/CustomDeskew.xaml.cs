﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataCapture
{
    /// <summary>
    /// Interaction logic for CustomDeskew.xaml
    /// </summary>
    public partial class CustomDeskew : Window
    {
        public CustomDeskew()
        {
            InitializeComponent();
        }

        public void SetTBValues(CustomDeskewInfo deskewInfo)
        {
            if (deskewInfo != null)
            {
                TBLeft.Text = "" + deskewInfo.MarginLeft;
                TBTop.Text = "" + deskewInfo.MarginTop;
                TBRight.Text = "" + deskewInfo.MarginRight;
                TBBottom.Text = "" + deskewInfo.MarginBottom;
                TBWidth.Text = "" + deskewInfo.Width;
                TBHeight.Text = "" + deskewInfo.Height;
                CBAction.SelectedIndex = deskewInfo.Action;
            }
        }

        private int GetTBValue(TextBox tb)
        {
            int value = 0;
            if (!string.IsNullOrWhiteSpace(tb.Text))
            {
                if (!Int32.TryParse(tb.Text, out value))
                {
                    value = 0;
                }
            }
            return value;
        }

        private void BOk_Click(object sender, RoutedEventArgs e)
        {
            var capture = Owner as MainWindow;
            if (capture != null)
            {
                var deskewInfo = new CustomDeskewInfo();
                deskewInfo.MarginLeft = GetTBValue(TBLeft);
                deskewInfo.MarginTop = GetTBValue(TBTop);
                deskewInfo.MarginRight = GetTBValue(TBRight);
                deskewInfo.MarginBottom = GetTBValue(TBBottom);
                deskewInfo.Width = GetTBValue(TBWidth);
                deskewInfo.Height = GetTBValue(TBHeight);
                deskewInfo.Action = CBAction.SelectedIndex;

                capture.DeskewInfo = deskewInfo;
            }
            DialogResult = true;
            Close();
        }

        private void TBNumberOnly_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null)
            {
                int value = -1;

                if (Int32.TryParse(tb.Text, out value) == false)
                {
                    TextChange tc = e.Changes.ElementAt<TextChange>(0);
                    tb.Text = tb.Text.Remove(tc.Offset, tc.AddedLength);
                }
            }

        }
    }
}
